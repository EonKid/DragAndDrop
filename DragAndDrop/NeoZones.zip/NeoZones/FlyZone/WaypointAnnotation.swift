//
//  WaypointAnnotation.swift
//  FlyZone
//
//  Created by Dhruv Singh on 20/01/17.
//  Copyright © 2017 toxsl. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class WaypointAnnotation: NSObject , MKAnnotation{
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var info: String
    var isSelected: Bool
    init(title: String, coordinate: CLLocationCoordinate2D, info: String,isSelected:Bool) {
        self.title = title
        self.coordinate = coordinate
        self.info = info
        self.isSelected = isSelected
    }
}
