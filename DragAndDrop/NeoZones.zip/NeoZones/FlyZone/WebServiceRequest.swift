//
//  WebServiceRequest.swift
//  FlyZone
//  Created by Dhruv Singh on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Alamofire

class WebServiceRequest: NSObject {

    //MARK:- POST NORMAL DATA
    class func postNormalData(_ parameters: Dictionary<String, AnyObject>? = nil, url urlStr: String, success: @escaping (_ responseDict: NSMutableDictionary) -> Void, failure: @escaping (_ error: NSError) -> Void) {
          KAppDelegate.showActivityIndicator()
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
        request(urlStr, method: .post, parameters: parameters, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
        .responseJSON { response in
                do
                {
                    if response.result.value != nil{
                        self.printResponse( responseDictionary: response.result.value as! NSDictionary)
                    }
                    if(response.response?.statusCode == 200)
                    {
                        KAppDelegate.hideActivityIndicator()
                        if let JSON = response.result.value as? NSDictionary{
                            debugPrint("Time line :",response.timeline.latency)
                             success(JSON .mutableCopy() as! NSMutableDictionary)
                        }else{
                           proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                        }
                    }
                    else {
                        if  response.response?.statusCode == 400
                        {
                            displayStatusCodeAlert("bad url")
                        }
                        else if response.response?.statusCode == 401
                        {
                            displayStatusCodeAlert("unauthorized")
                        }
                        else if response.response?.statusCode == 404
                        {
                            displayStatusCodeAlert("file not found")
                        }
                        else if response.response?.statusCode ==  500
                        {
                            let myHTMLString = NSString(data: response.data!, encoding:String.Encoding.utf8.rawValue)
                            print("HTML string: \(myHTMLString as! String)")
                            proxy.sharedProxy().HtmlDisplayStatusAlert(myHTMLString as! String)
                        }
                        else if response.response?.statusCode == 408
                        {
                             failure(response.result.error as! NSError)
                        }
                        else if (response.result.error as NSError?)?.code == -1001
                        {
                            failure(response.result.error as! NSError)
                        }
                        else if (response.result.error as NSError?)?.code == -1009
                        {
                            failure(response.result.error as! NSError)
                        }
                    }
                }
                catch let error as NSError
                {
                    KAppDelegate.hideActivityIndicator()
                    failure(error)
                    NSLog("EXCEPTION : %@", error.description)
                }
            }
        }
        else
        {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    //MARK: - PRINT RESPONSE
    class  func printResponse(responseDictionary:NSDictionary)  {
        var jsonString : NSString = ""
        do
        {
            let Json = try JSONSerialization.data(withJSONObject:responseDictionary, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: Json, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
            debugPrint("Response:",jsonString)
        }
        catch let error as NSError
        {
            debugPrint(error.description)
        }
    }
    
    
    
    //MARK:- GET DATA
    class func getData(url urlStr: String, success: @escaping (_ responseDict: NSMutableDictionary) -> Void, failure: @escaping (_ error: NSError) -> Void) {
        let reachability = Reachability()
        if  reachability?.isReachable  == true{
                KAppDelegate.showActivityIndicator()
                     request(urlStr, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:nil)
                    .responseJSON { response in
                        KAppDelegate.hideActivityIndicator()
                        if response.result.value != nil{
                        self.printResponse( responseDictionary: response.result.value as! NSDictionary)
                        }
                        KAppDelegate.hideActivityIndicator()
                        if response.result.value != nil {
                            if(response.response?.statusCode == 200)
                            {
                                if let JSON = response.result.value as? NSDictionary{
                                     debugPrint("Time line :",response.timeline.latency)
                                 success(JSON .mutableCopy() as! NSMutableDictionary)
                                }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                                }
                            }
                           else  {
                                
                                if  response.response?.statusCode == 400
                                {
                                    displayStatusCodeAlert("bad url")
                                }
                                else if response.response?.statusCode == 401
                                {
                                    displayStatusCodeAlert("unauthorized")
                                }
                                else if response.response?.statusCode == 404
                                {
                                    displayStatusCodeAlert("file not found")
                                }
                                else if response.response?.statusCode ==  500
                                {
                                    let myHTMLString = NSString(data: response.data!, encoding:String.Encoding.utf8.rawValue)
                                    proxy.sharedProxy().HtmlDisplayStatusAlert(myHTMLString as! String)
                                    debugPrint("HTML String: \(myHTMLString as! String)")
                                }
                                else if response.response?.statusCode == 408
                                {
                                   failure(response.result.error as! NSError)
                                    
                                }
                                else if (response.result.error as NSError?)?.code == -1001
                                {
                                    failure(response.result.error as! NSError)
                                }
                                else if (response.result.error as NSError?)?.code == -1009
                                {
                                     failure(response.result.error as! NSError)
                                }
                                
                            }
                        }
                }
            } else {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().openSettingApp()
        }
    }
    
  class  func displayStatusCodeAlert(_ userMessage: String)
    {
        UIView.hr_setToastThemeColor(color: appColor)
        KAppDelegate.window!.makeToast(message: userMessage)
    }
    
}
