//
//  MKPolygon+GSPolygonIntersections.h
//  GSPolygonIntersections
//  Created by Dhruv Narayan Singh on 11/21/16.
//  Copyright (c) 2016 . All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MKPolygon (GSPolygonIntersections){
    
}
+(MKPolygon *)polygon:(MKPolygon *)poly1 intersectedWithSecondPolygon:(MKPolygon *)poly2;


@end
