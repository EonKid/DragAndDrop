//
//  SignupVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 27/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Alamofire

class SignupVC: UIViewController, WebServiceDelegate {
    
    //MARK:- VARIABLE
    //MARK: - IBOUTLET
    @IBOutlet weak var viewSetupName: UIView!
    @IBOutlet weak var viewSetupPwd: UIView!
    
    @IBOutlet weak var viewSetupEmail: UIView!
    @IBOutlet weak var viewSetupConfirmPwd: UIView!
    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var txtFldConfirmPass: UITextField!
    
    //MARK: - VIEWCONTROLLER LIFECYCLE
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.layerUISetup()
        
        
        
    }
    func layerUISetup() {
        viewSetupEmail.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        viewSetupEmail.layer.borderWidth = 1
        viewSetupPwd.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        viewSetupPwd.layer.borderWidth = 1
        viewSetupName.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        viewSetupName.layer.borderWidth = 1
        viewSetupConfirmPwd.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        viewSetupConfirmPwd.layer.borderWidth = 1
        
    }
    
    
    //MARK; - ACTION
    @IBAction func btnDoneAction(_ sender: AnyObject) {
        var name = String()
        self.view.endEditing(true)
        let whitespaceSet = CharacterSet.whitespaces
        
        if txtFldName.text != "" {
            name = txtFldName.text!.trimmingCharacters(in: whitespaceSet)
        }
        
        
        
        if name.isEmpty
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Name")
            txtFldName.text = ""
        }
            
        else if txtFldEmail.text!.trimmingCharacters(in: whitespaceSet).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email")
        }
            
        else if proxy.sharedProxy().isValidEmail(txtFldEmail.text!) == false
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email.")
        }
        else if txtFldPassword.text!.trimmingCharacters(in: whitespaceSet).isEmpty {
            txtFldPassword.text = ""
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
        }
        else if txtFldConfirmPass.text!.trimmingCharacters(in: whitespaceSet).isEmpty {
            txtFldConfirmPass.text = ""
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Confirm Password")
        }
        else if txtFldPassword.text! != txtFldConfirmPass.text!
        {
            proxy.sharedProxy().displayStatusCodeAlert("Password does not match")
        }
        else
        {
            self.view.endEditing(true)
            var strDeviceToken = String()
            
            if (UserDefaults.standard.object(forKey: "device_token")) != nil
            {
                
                strDeviceToken = UserDefaults.standard.object(forKey: "device_token") as! String
            }else{
                
                strDeviceToken = "54561256456121"
            }
            
            
            let RegisterUrl = "\(KServerUrl)"+"\(KSignUp)"
            let uniqueID = UIDevice.current.identifierForVendor!.uuidString
            let param = [
                "User[full_name]":"\(name)",
                "User[email]":"\(txtFldEmail.text!)",
                "User[password]":"\(txtFldPassword.text!)",
                "User[confirm_password]":"\(txtFldConfirmPass.text!)",
                "User[device_token]": strDeviceToken,
                "User[device_type]": "1",
                "User[type_id]":"1",
                "User[uid]":uniqueID
            ]
            
            KAppDelegate.showActivityIndicator()
            
            let reachability = Reachability()
            if  reachability?.isReachable  == true

            {
                
                
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                
                request(RegisterUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])

                    .responseJSON { response in
                        do
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            if(response.response?.statusCode == 200)
                            {
                                if let JSON = response.result.value as? NSDictionary{
                                    self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                                }else{
                                    proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                                }
                            }
                            else
                            {
                                delegateObject = self
                                proxy.sharedProxy().stautsHandler(RegisterUrl , parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: NSError(domain: "", code: (response.response!.statusCode), userInfo: nil))
                            }
                            
                        }
                        catch let error as NSError
                        {
                            NSLog("EXCEPTION %@",error.description)
                            
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
            else
            {
                KAppDelegate.hideActivityIndicator()
                
                proxy.sharedProxy().openSettingApp()
            }
        }
    }
    
    
    // MARK:- Webservice Method
    
    func serviceResponse(_ JSON:NSMutableDictionary)
    {
        KAppDelegate.hideActivityIndicator()
        
        if (JSON["action"]! as AnyObject).isEqual("signup") && (JSON["controller"]! as AnyObject).isEqual("user")
        {
            if (JSON["status"]! as AnyObject).isEqual("OK")
            {
                let dictTemp = JSON["detail"] as! NSDictionary
                
                //                proxy.sharedProxy().displayStatusCodeAlert("Registration Successful")
                //                self.navigationController?.popViewControllerAnimated(true)
                let authcode = JSON["auth_code"] as! String
                UserDefaults.standard.set(authcode, forKey: "auth_code")
                UserDefaults.standard.synchronize()
                let userId = dictTemp["id"] as! Int
                let userName = dictTemp["full_name"] as! String
                let userEmail = dictTemp["email"] as! String
                UserDefaults.standard.set(userId, forKey: "id")
                UserDefaults.standard.set(userName, forKey: "full_name")
                UserDefaults.standard.set(userEmail, forKey: "email")
                UserDefaults.standard.synchronize()
                KAppDelegate.gotoMainMenu()
                
            }
            else
            {
                let errorMessage = JSON["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
        }
    }
    
    func retryMethod(_ paramsDic: Dictionary<String, AnyObject>, withServiceUrl: NSString, error: NSError?)
    {
        let retryURL = "\(withServiceUrl)"
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true
            
        {
            
            if(paramsDic.count>0){
                
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .post, parameters: paramsDic, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = response.result.value as! NSDictionary
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                                
                            }
                            else
                            {
                                delegateObject = self
                                KAppDelegate.hideActivityIndicator()
                                
                                proxy.sharedProxy().stautsHandler(retryURL, parameter:paramsDic, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            NSLog("EXCEPTION : %@", error.description)
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
            else
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                
                request(retryURL, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = response.result.value as! NSDictionary
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                            else
                            {
                                delegateObject = self
                                KAppDelegate.hideActivityIndicator()
                                
                                proxy.sharedProxy().stautsHandler(retryURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            NSLog("EXCEPTION : %@", error.description)
                            
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }

    
    
    @IBAction func btnLogin(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnBack(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
