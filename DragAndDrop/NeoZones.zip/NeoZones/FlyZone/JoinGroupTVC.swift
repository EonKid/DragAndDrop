//
//  JoinGroupTVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 29/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class JoinGroupTVC: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnJoin: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
