//
//  MyAccountVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 16/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class MyAccountVC: UIViewController {

    //MARK:- VARIABLE
    
     //MARK:- IBOUTLET
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var vwName: UIView!
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var vwEmail: UIView!
   
    //MARK:- ACTION
    
    @IBAction func btnPrssDrawer(_ sender: AnyObject) {
        KAppDelegate.openDrawerAction()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        if (UserDefaults.standard.object(forKey: "full_name")) != nil
        {
            
            lblName.text = UserDefaults.standard.object(forKey: "full_name") as? String
            
        }else{
        
            vwName.isHidden = true
        }
        
        if (UserDefaults.standard.object(forKey: "email")) != nil
        {
            
            lblEmail.text = UserDefaults.standard.object(forKey: "email") as? String
            
        }else{
        
            vwEmail.isHidden = true
            proxy.sharedProxy().displayStatusCodeAlert("Please Login to see your account")
        }

       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
