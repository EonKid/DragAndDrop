//
//  AboutVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 01/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class AboutVC: UIViewController {
    
    @IBOutlet weak var imgAboutApp: UIImageView!
    @IBAction func btnPrssDrawer(_ sender: AnyObject) {
        
        KAppDelegate.openDrawerAction()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
          }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
