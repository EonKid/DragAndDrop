//
//  JoinGroupVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 28/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Alamofire

class JoinGroupVC: UIViewController,UITableViewDelegate, UITableViewDataSource,UISearchControllerDelegate,UISearchBarDelegate, WebServiceDelegate,directConnectionDelegate {
    
    //MARK;- VARIABLES
    var arrGroupList = NSMutableArray()
    var locationArray = NSMutableArray()
    var arrSearchByEvent = NSMutableArray()
    var arrSearchByLoc = NSMutableArray()
    var hitURL = String()

    //MARK:- IBOUTLET
    @IBOutlet weak var tblVw: UITableView!
    @IBOutlet weak var searchBarEvent: UISearchBar!
    @IBOutlet weak var searchBarLocation: UISearchBar!
    
    @IBOutlet weak var tblVwLocations: UITableView!
    //MARK:- VIEWCONTROLLER LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblVwLocations.isHidden = true
        tblVwLocations.delegate = self
        tblVwLocations.dataSource = self
        tblVwLocations.backgroundColor = UIColor.clear

        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        self.getGroupList()
    }
    //MARK:- API HIT
    func getGroupList()  {
        
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kGroupList)" + "?auth_code=\(authCode)"
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    let arrTemp = responseDict["list"] as! NSArray
                    self.arrGroupList.removeAllObjects()
                    for i in 0 ..< arrTemp.count{
                        var dict = NSDictionary()
                        dict = arrTemp[i] as! NSDictionary
                        let groupModal = GroupList()
                        groupModal.id = Int32(((dict["id"] as! NSNumber).intValue))
                        groupModal.type_id = Int32(((dict["type_id"] as! NSNumber).intValue))
                        groupModal.name = dict["name"] as! String
                        groupModal.type = dict["type"] as! String
                        groupModal.create_time = dict["create_time"] as! String
                        groupModal.create_user_name = dict["create_user_name"] as! String
                        groupModal.create_user_id = Int32(((dict["create_user_id"] as! NSNumber).intValue))
                        groupModal.is_followed = Int32((dict["is_followed"] as! NSString) as String)!
                        self.arrGroupList.add(groupModal)
                    }
                    if self.arrGroupList.count > 0{
                         self.tblVw.reloadSections([0], with: .fade)
                    }
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
            }) { (error) in
               
                if error.localizedDescription.characters.count > 0{
                let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.getGroupList()
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
               
            }
            
        }
    }
    
    
    
    
    func joinGroupApi(_ groupModal: GroupList,index: Int)  {
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kJoinGroup)" + "\(groupModal.id)"
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    proxy.sharedProxy().displayStatusCodeAlert("Group joined successfully")
                    
                    let eventListVC = self.storyboard?.instantiateViewController(withIdentifier: "EventListOnLineVC") as! EventListOnLineVC
                    groupModal.is_followed = 1
                    eventListVC.groupModal = groupModal
                    self.navigationController?.pushViewController(eventListVC, animated: true)
                    
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
                
            }) { (error) in
               
                if error.localizedDescription.characters.count > 0{
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.joinGroupApi(groupModal, index: index)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }
    
    //MARK: - SearchBar Methods

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar){
        searchBar.text = ""
        
        if searchBar == searchBarLocation  {
            tblVwLocations.isHidden = false
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        
        if searchBar == searchBarEvent {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                self.search_Event(searchBar.text!)
            }
        }else{
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                self.search_API(searchBar.text!)
            }
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        searchBar.showsCancelButton = true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.showsCancelButton = false
        searchBar.resignFirstResponder()
        if searchBar == searchBarEvent {
            getGroupList()
        }else {
            tblVwLocations.isHidden = true
            getGroupList()
        }
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        searchBar.text = ""
        searchBar.showsCancelButton = false
        searchBar.resignFirstResponder()
        tblVwLocations.isHidden = true
    }

    func search_Event(_ searchText:String) {
       
        let param = [
            "Event[name]": searchText
        ]
        
        
        let searchUrl = "\(KServerUrl)"+"\(kGroupSearch)"
        
        KAppDelegate.showActivityIndicator()
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
            let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
//            Alamofire.request(.POST, searchUrl, parameters:param, headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                 request(searchUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do
                    {
                        KAppDelegate.hideActivityIndicator()
                        if(response.response?.statusCode == 200)
                        {
                            if let JSON = response.result.value as? NSDictionary{
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }

                        }
                        else
                        {
                            delegateObject = self
                            proxy.sharedProxy().stautsHandler(searchUrl , parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: NSError(domain: "", code: (response.response!.statusCode), userInfo: nil))
                        }
                        
                    }
                    catch let error as NSError
                    {
                        NSLog("EXCEPTION %@",error.description)
                        
                        KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().displayStatusCodeAlert(error.description)
                    }
            }
        }
        else
        {
            KAppDelegate.hideActivityIndicator()
            
            proxy.sharedProxy().openSettingApp()
        }
        
        
    }
    
    // MARK:- Webservice Method
    
    func serviceResponse(_ JSON:NSMutableDictionary)
    {
        KAppDelegate.hideActivityIndicator()
        
        if (JSON["action"]! as AnyObject).isEqual("search") && (JSON["controller"]! as AnyObject).isEqual("group")
        {
            if (JSON["status"]! as AnyObject).isEqual("OK")
            {
                
                    let arrTemp = JSON["list"] as! NSArray
                    self.arrGroupList.removeAllObjects()
                    for i in 0 ..< arrTemp.count{
                        var dict = NSDictionary()
                        dict = arrTemp[i] as! NSDictionary
                        let groupModal = GroupList()
                        groupModal.id = Int32(((dict["id"] as! NSNumber).intValue))
                        groupModal.type_id = Int32(((dict["type_id"] as! NSNumber).intValue))
                        groupModal.name = dict["name"] as! String
                        groupModal.type = dict["type"] as! String
                        groupModal.create_time = dict["create_time"] as! String
                        groupModal.create_user_name = dict["create_user_name"] as! String
                        groupModal.create_user_id = Int32(((dict["create_user_id"] as! NSNumber).intValue))
                        groupModal.is_followed = Int32(dict["is_followed"] as! String)!
                        self.arrGroupList.add(groupModal)
                    }
                        self.tblVw.reloadData()
                
            }
            else
            {
                let errorMessage = JSON["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
        }
    }

    func retryMethod(_ paramsDic: Dictionary<String, AnyObject>, withServiceUrl: NSString, error: NSError?)
    {
        let retryURL = "\(withServiceUrl)"
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true
            
        {
            
            if(paramsDic.count>0){
                
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .post, parameters: paramsDic, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = response.result.value as! NSDictionary
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                                
                            }
                            else
                            {
                                delegateObject = self
                                KAppDelegate.hideActivityIndicator()
                                
                                proxy.sharedProxy().stautsHandler(retryURL, parameter:paramsDic, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            NSLog("EXCEPTION : %@", error.description)
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
            else
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                
                request(retryURL, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = response.result.value as! NSDictionary
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                            else
                            {
                                delegateObject = self
                                KAppDelegate.hideActivityIndicator()
                                
                                proxy.sharedProxy().stautsHandler(retryURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            NSLog("EXCEPTION : %@", error.description)
                            
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }

    func search_API(_ searchText:String){
        let trimmedText = searchText.replacingOccurrences(of: " ", with: "%20")
        let apiAddress = "\(googleBaseURL)"+"place/textsearch/json?query="
        
        let searchAddress = apiAddress + trimmedText + apiKey
        hitURL =  "SearchPlace"
        NSLog("searchAdd %@", searchAddress)
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
             request(searchAddress, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:nil)
                .responseJSON { response in
                    do {
                        if(response.response?.statusCode == 200) {
                            if let JSON = response.result.value as? NSDictionary{
                                 self.serviceResponsePlace(JSON .mutableCopy() as! NSMutableDictionary)
                                
                            }else{
                                
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }
                            
                          
                        }else {
                            proxy.sharedProxy().stautsHandler(searchAddress, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                        }
                    } catch let error as NSError {
                        proxy.sharedProxy().displayStatusCodeAlert(error.description)
                    }
            }
        }else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponsePlace(_ JSON:NSMutableDictionary) {
        if(hitURL ==  "SearchPlace") {
            if (JSON["status"]! as AnyObject).isEqual("OK")
            {
                let resultsArray = JSON["results"] as! NSArray
              //  NSLog("Address %@", resultsArray)
                self.locationArray.removeAllObjects()
                for i in 0 ..< resultsArray.count {
                    var dict = NSDictionary()
                    dict = resultsArray[i] as! NSDictionary
                    let locationDict = NSMutableDictionary()
                    let formatted_address = dict.object(forKey: "formatted_address") as! String
                    let sub_Address = dict.object(forKey: "name") as! String
                    locationDict.setValue(formatted_address, forKey: "sub_Address" )
                    locationDict.setValue(sub_Address, forKey: "name" )
                    let strlat = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lat") as! NSNumber
                    let strlong = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lng") as! NSNumber
                       locationDict.setValue(strlat, forKey: "lat")
                       locationDict.setValue(strlong, forKey: "lng")
                    self.locationArray.add(locationDict)
                }
                let delay = 0.1 * Double(NSEC_PER_SEC)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                    if self.locationArray.count > 0 {
                        self.tblVwLocations.reloadData()
                    }
                    self.hitURL =  ""
                }
            }
            else
            {
                let errorMessage = JSON["status"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
        }
    }

    //MARK:- TABLEVIWE DATA SOURCE AND DELEGATE
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblVw {
            return arrGroupList.count
        }else if tableView == tblVwLocations {
            return locationArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tblVw {
            return 115
        }else {
            return 60
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        if tableView == tblVw {
            let cell = tblVw.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! JoinGroupTVC
            var modalObject  = GroupList()
            modalObject = arrGroupList[(indexPath as NSIndexPath).row] as! GroupList
            // create_user_id
            
            cell.btnJoin.layer.borderColor = UIColor(red: 64.0/255, green: 160.0/255, blue: 215.0/255, alpha: 1).cgColor
            cell.lblName.text = modalObject.name
            cell.btnJoin.layer.borderWidth = 1
            cell.btnJoin.tag = (indexPath as NSIndexPath).row
            if modalObject.is_followed == 0 {
                let userId  = UserDefaults.standard.object(forKey: "id") as! Int
                if modalObject.create_user_id ==  Int32(userId){
                    cell.btnJoin.setTitle("My Group", for: UIControlState())
                    cell.btnJoin.addTarget(self, action: #selector(JoinGroupVC.joinGroupTemp(_:)), for: UIControlEvents.touchUpInside)
                    
                }else{
                    cell.btnJoin.addTarget(self, action: #selector(JoinGroupVC.joinGroup(_:)), for: UIControlEvents.touchUpInside)
                    cell.btnJoin.setTitle("Join Group", for: UIControlState())
                }
            }else{
                
                cell.btnJoin.setTitle("Joined", for: UIControlState())
                cell.btnJoin.isUserInteractionEnabled = false
            }
            
            return cell

        }else if tableView == tblVwLocations{
            cell = UITableViewCell(style: UITableViewCellStyle.value1, reuseIdentifier: "Cell")
            cell.textLabel?.textColor = UIColor.black
            cell.textLabel?.text = (locationArray.object(at: indexPath.row) as! NSDictionary).object(forKey: "name") as? String
            cell.textLabel?.numberOfLines = 20
            let btn = UIButton(frame: CGRect(x: 0, y: 0, width: tblVwLocations.frame.width , height: 60))
            btn.tag = (indexPath as NSIndexPath).row
            btn.addTarget(self, action: #selector(JoinGroupVC.tblBtnAction(_:)), for: .touchUpInside)
            cell.contentView.addSubview(btn)
            return cell
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tblVw {
            if arrGroupList.count > 0 {
                var modalObject = GroupList()
                modalObject = arrGroupList[(indexPath as NSIndexPath).row] as! GroupList
                let eventListVC = storyboard?.instantiateViewController(withIdentifier: "EventListOnLineVC") as! EventListOnLineVC
                eventListVC.groupModal = modalObject
                self.navigationController?.pushViewController(eventListVC, animated: true)
            }
          
        }
    }
    func tblBtnAction(_ sender: AnyObject ){
        let dict = locationArray[sender.tag] as! NSDictionary
        let lat = dict["lat"] as! Double
        let long = dict["lng"] as! Double
        tblVwLocations.isHidden = true
        searchByLoc(lat, lng: long)
    }
    
    func searchByLoc(_ lat:Double, lng:Double) {
        let param = [
            "Event[lat]": "\(lat)",
            "Event[longt]": "\(lng)"
        ]
        
        let searchUrl = "\(KServerUrl)"+"\(kGroupSearch)"
        KAppDelegate.showActivityIndicator()
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
            let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
            
//            Alamofire.request(.POST, searchUrl, parameters:param, headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
            request(searchUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])

                .responseJSON { response in
                    do
                    {
                        KAppDelegate.hideActivityIndicator()
                        if(response.response?.statusCode == 200)
                        {
                             if let JSON = response.result.value as? NSDictionary{
                            self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                        }
                        else
                        {
                            delegateObject = self
                            proxy.sharedProxy().stautsHandler(searchUrl , parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: NSError(domain: "", code: (response.response!.statusCode), userInfo: nil))
                        }
                    }
                    catch let error as NSError
                    {
                        NSLog("EXCEPTION %@",error.description)
                        KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().displayStatusCodeAlert(error.description)
                    }
            }
        }
        else
        {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }

    //MARK:- ACTION
    func joinGroup(_ sender: UIButton)  {
        var modalObject = GroupList()
        modalObject = arrGroupList[sender.tag] as! GroupList
        joinGroupApi(modalObject,index: sender.tag)
        
    }
    func joinGroupTemp(_ sender: UIButton)  {
        var modalObject = GroupList()
        modalObject = arrGroupList[sender.tag] as! GroupList
        let eventListVC = self.storyboard?.instantiateViewController(withIdentifier: "EventListOnLineVC") as! EventListOnLineVC
        eventListVC.groupModal = modalObject
        self.navigationController?.pushViewController(eventListVC, animated: true)
        
    }
    
    
    
    //MARK:- DELEGATE
    func directConnectionDone(_ dictEventInfo:NSDictionary)
    {
        let eventModal = EventListOnline()
        eventModal.id = Int32(((dictEventInfo["id"] as! NSNumber).intValue))
        eventModal.group_id = Int32(((dictEventInfo["group_id"] as! NSNumber).intValue))
        eventModal.name = dictEventInfo["name"] as! String
        eventModal.group_name = dictEventInfo["group_name"] as! String
        eventModal.create_time = dictEventInfo["create_time"] as! String
        eventModal.from_date = dictEventInfo["from_date"] as! String
        eventModal.to_date = dictEventInfo["to_date"] as! String
        eventModal.create_user_id = Int32(((dictEventInfo["create_user_id"] as! NSNumber).intValue))
        eventModal.create_user_name = dictEventInfo["create_user_name"] as! String
        let mainVc = self.storyboard!.instantiateViewController(withIdentifier: "CreateZoneOnlineVC") as! CreateZoneOnlineVC
        mainVc.modalEventListOnline = eventModal
        self.navigationController?.pushViewController(mainVc, animated: true)
    }
    
    @IBAction func btnDirctConection(_ sender: AnyObject) {
        if (UserDefaults.standard.object(forKey: "auth_code")) != nil
        {
            
            let dirctVc = storyboard?.instantiateViewController(withIdentifier: "DirectConnectionVC") as! DirectConnectionVC
            protocolDirectConnection = self
            dirctVc.modalTransitionStyle = .crossDissolve
            dirctVc.modalPresentationStyle = .overCurrentContext
            self.providesPresentationContextTransitionStyle = true
            self.present(dirctVc, animated: true, completion: nil)
           
        }else{
        proxy.sharedProxy().displayStatusCodeAlert("Please Login to continue for Direct Connection ")
        }
       
    }
    
    @IBAction func btnMainMenu(_ sender: AnyObject) {
        KAppDelegate.gotoMainMenu()
        
    }
    
    @IBAction func btnBack(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
