//
//  LoginVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 27/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Alamofire

class LoginVC: UIViewController, WebServiceDelegate {
    
    //MARK:- Variables
    var strEmail = String()
    var emailField = UITextField()
    //MARK:- IBOutlets
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var btnRememberOutlet: UIButton!
    @IBOutlet weak var btnEnterWithoutLogin: UIButton!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var viewSetupEmail: UIView!
    @IBOutlet weak var viewSetupPwd: UIView!
    
    //MARK:- ViewController Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        self.layerUISetup()
    }
    
    
    
    func layerUISetup() {
      
        if (UserDefaults.standard.object(forKey: kEmail)) != nil
        {
            txtFldEmail.text = UserDefaults.standard.object(forKey: kEmail) as? String
            btnRememberOutlet.isSelected = true
        }
        
        if (UserDefaults.standard.object(forKey: kPassword)) != nil
        {
            txtFldPassword.text = UserDefaults.standard.object(forKey: kPassword) as? String
            btnRememberOutlet.isSelected = true
        }
        
        viewSetupEmail.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        viewSetupEmail.layer.borderWidth = 1
        viewSetupPwd.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        viewSetupPwd.layer.borderWidth = 1
        btnLogin.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        btnLogin.layer.borderWidth = 1
        btnRememberOutlet.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        btnRememberOutlet.layer.borderWidth = 1
        btnEnterWithoutLogin.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        btnEnterWithoutLogin.layer.borderWidth = 1
        
    }
    //MARK:- Login action
    
    @IBAction func btnRememberPrssPassword(_ sender: AnyObject) {
        if btnRememberOutlet.isSelected == true {
            btnRememberOutlet.isSelected = false
            UserDefaults.standard.set("", forKey: kEmail)
            UserDefaults.standard.set("", forKey: kPassword)
            
        }else{
            btnRememberOutlet.isSelected = true
            if txtFldEmail.text?.trimmingCharacters(in: CharacterSet.whitespaces).characters.count != 0 {
                UserDefaults.standard.set(txtFldEmail.text, forKey: kEmail)
            }
            if txtFldEmail.text?.trimmingCharacters(in: CharacterSet.whitespaces).characters.count != 0 {
                UserDefaults.standard.set(txtFldPassword.text, forKey: kPassword)
            }
        }
        
    }
    
   
    
    @IBAction func btnForgotAction(_ sender: AnyObject) {
        
        
        let alertController = UIAlertController(title: "Forget Password!", message: "Please enter your email to recover account.", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
        }
        alertController.addAction(cancelAction)
        
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
            
            self.forgetPassword(self.emailField.text!)
        }
        
        
        alertController.addTextField {
            (txtEmail) -> Void in
            txtEmail.placeholder = "Enter your email"
            txtEmail.keyboardType = .emailAddress
            self.emailField = txtEmail
            
        }
        
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion:nil)
        
    }
    
    
    
    @IBAction func btnLogin(_ sender: AnyObject) {
        
        self.view.endEditing(true)
        if txtFldEmail.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email")
        }
        else if proxy.sharedProxy().isValidEmail(txtFldEmail.text!) == false
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email.")
        }
        else if txtFldPassword.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
        }
        else
        {
           let uniqueID = UIDevice.current.identifierForVendor!.uuidString
            var strDeviceToken = String()
            if (UserDefaults.standard.object(forKey: "device_token")) != nil
            {
                strDeviceToken = UserDefaults.standard.object(forKey: "device_token") as! String
            }else{
                strDeviceToken = "54561256456121"
            }
            let LoginUrl = "\(KServerUrl)"+"\(KLoginUser)"
            let param = [
                "LoginForm[username]":"\(txtFldEmail.text!)",
                "LoginForm[password]":"\(txtFldPassword.text!)",
                "LoginForm[device_token]":strDeviceToken,
                "LoginForm[device_type]":"1",
                "LoginForm[uid]" : uniqueID,
                "LoginForm[type_id]" : "1"
            ]
            debugPrint("Param:",param)
            signIn(LoginUrl, postParam: param as Dictionary<String, AnyObject>)
        }
    }
    
    @IBAction func btnPrssEnterOfflineMode(_ sender: AnyObject) {
        KAppDelegate.gotoMainMenu()
       
    }
    
    @IBAction func btnSignup(_ sender: AnyObject) {
        let signupVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
        self.navigationController?.pushViewController(signupVc, animated: true)
    }
    
    //MARK:- WEBSERVICE HANDLING
    func signIn(_ url: String,postParam: Dictionary<String, AnyObject>)  {
        WebServiceRequest.postNormalData(postParam, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK")
            {
                let authcode = responseDict["auth_code"] as! String
                UserDefaults.standard.set(authcode, forKey: "auth_code")
                let detailDict = responseDict["detail"] as! NSDictionary
                let userId = detailDict["id"] as! Int
                let userName = detailDict["full_name"] as! String
                let userEmail = detailDict["email"] as! String
                UserDefaults.standard.set(userId, forKey: "id")
                UserDefaults.standard.set(userName, forKey: "full_name")
                UserDefaults.standard.set(userEmail, forKey: "email")
                UserDefaults.standard.synchronize()
                KAppDelegate.gotoMainMenu()
            }
            else
            {
                KAppDelegate.hideActivityIndicator()
                let errorMessage = responseDict["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
            }, failure: { (error) in
                KAppDelegate.hideActivityIndicator()
                if error.localizedDescription.characters.count > 0{
                
                    let alertController = UIAlertController(title: "Error", message: "\(error.localizedDescription)", preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.signIn(url, postParam: postParam)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
        })
    }
    
    
    func forgetPassword(_ strEmail: String)  {
        self.view.endEditing(true)
        if strEmail.isEmpty
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email")
            
        }else{
            let LoginUrl = "\(KServerUrl)"+"\(kRecoverPassword)"
            let param = [
                "User[email]": strEmail
            ]
            WebServiceRequest.postNormalData(param as Dictionary<String, AnyObject>?, url: LoginUrl, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK"){
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["message"]!))
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
                
                }, failure: { (error) in
                    let errorMessage = "\(error.localizedDescription)"
                   
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.forgetPassword(strEmail)
                        }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                        }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
            })
        }
    }
    
    
    func serviceResponse(_ JSON:NSMutableDictionary)
    {
        
    }
    
    
    func retryMethod(_ paramsDic: Dictionary<String, AnyObject>, withServiceUrl: NSString, error: NSError?)
    {
        let retryURL = "\(withServiceUrl)"
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true
            
        {
            
            if(paramsDic.count>0){
                
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .post, parameters: paramsDic, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = response.result.value as! NSDictionary
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                            else
                            {
                                delegateObject = self
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(retryURL, parameter:paramsDic, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            NSLog("EXCEPTION : %@", error.description)
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
            else
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                
                request(retryURL, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = response.result.value as! NSDictionary
                                self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                            else
                            {
                                delegateObject = self
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(retryURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            KAppDelegate.hideActivityIndicator()
                            
                            NSLog("EXCEPTION : %@", error.description)
                            
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
        
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
