//
//  GridAnnotationStart.swift
//  FlyZone
//
//  Created by Dhruv Singh on 22/02/17.
//  Copyright © 2017 toxsl. All rights reserved.
//

import UIKit
import MapKit
class GridAnnotationStart: NSObject ,MKAnnotation{
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var info: String
    var index: String
    
    init(title: String, coordinate: CLLocationCoordinate2D, info: String,index: String) {
        self.title = title
        self.coordinate = coordinate
        self.info = info
        self.index = index
    }

}
