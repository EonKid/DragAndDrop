//
//  ZonePlannerOnlineVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 28/07/16.
//  Copyright © 2016 toxsl. All rights reserved.


import UIKit

class ZonePlannerOnlineVC: UIViewController,setLocationDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
   
    
    //MARK:- ZONE PLANNER DELEGATE
    func setLocationOfEvent(_ dictEvent: NSDictionary){
        let eventModal = EventListOnline()
        eventModal.id = Int32(((dictEvent["id"] as! NSNumber).intValue))
        eventModal.group_id = Int32(((dictEvent["group_id"] as! NSNumber).intValue))
        eventModal.name = dictEvent["name"] as! String
        eventModal.group_name = dictEvent["group_name"] as! String
        eventModal.create_time = dictEvent["create_time"] as! String
        eventModal.from_date = dictEvent["from_date"] as! String
        eventModal.to_date = dictEvent["to_date"] as! String
        eventModal.create_user_id = Int32(((dictEvent["create_user_id"] as! NSNumber).intValue))
        eventModal.create_user_name = dictEvent["create_user_name"] as! String
        eventModal.zones = dictEvent["zones"] as! NSArray
        let mainVc = self.storyboard!.instantiateViewController(withIdentifier: "CreateZoneOnlineVC") as! CreateZoneOnlineVC
        mainVc.modalEventListOnline = eventModal
        self.navigationController?.pushViewController(mainVc, animated: true)
        
    }
    
    
    @IBAction func btnBack(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCreateGroup(_ sender: AnyObject) {
        let createGroupVC = storyboard?.instantiateViewController(withIdentifier: "SetLocationVC") as! SetLocationVC
        protocolObject = self
        createGroupVC.modalTransitionStyle = .crossDissolve
        createGroupVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createGroupVC, animated: true, completion: nil)
        
    }
    
    @IBAction func btnJoinGroup(_ sender: AnyObject) {
        let joinVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "JoinGroupVC") as! JoinGroupVC
        self.navigationController?.pushViewController(joinVc, animated: true)
    }
    @IBAction func btnMainMenu(_ sender: AnyObject) {
        KAppDelegate.gotoMainMenu()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
