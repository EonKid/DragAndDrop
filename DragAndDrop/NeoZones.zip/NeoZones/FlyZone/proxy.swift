//
//  proxy.swift
//  Flyzone
//
//  Created by Toxsl on 24/12/16.
//  Copyright © 2015 ToXSL Technologies Pvt. Ltd. All rights reserved.
//

import UIKit
import PKHUD
import MapKit
import Darwin

fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

var KAppDelegate = UIApplication.shared.delegate as! AppDelegate
let willRegisterApp = true
var shareInstance:proxy = proxy()
// MARK: - Additional Headers
let  KMode = "debug"
let  KAppName = "FlyZone"
let  KVersion =  "1.0"
let  kModel = UIDevice.current.model
let  kSystemVersion = UIDevice.current.systemVersion
let  kUserName = ""
let  usewrAgent = "\(KMode)"+"/"+"\(KAppName)" + "/" + kModel + "/" + kSystemVersion


// MARK: - Google API's USER
//var  KServerUrl = "http://web.toxsl.in/flyzone/api/"
//Chekc api herer: http://neodronics-zone.com/api/
var KServerUrl = "http://neodronics-zone.com/api/"
let KCheckUser = "\(KServerUrl)"+"user/check?auth_code="
let googleBaseURL = "https://maps.googleapis.com/maps/api/"
let apiKey = "&key=AIzaSyAfdfhSQVnevQg7rfl4E7kUiwCAQWlJ_XI"
let KSignUp = "user/signup"
let Klogout = "user/logout"
let KLoginUser = "user/login"
let kRecoverPassword = "user/recover"
let kCreateGroup = "group/add"
let kGroupList = "group/index"
let kAddEvent = "event/add?group_id="
let kGetEventByGroup = "event/get?group_id="
let kJoinGroup = "group/join?group_id="
let kCreateZone = "zone/add?event_id="
let kGetEventZone = "event/event?id="
let kGroupSearch = "group/search"
let kUpdateZone = "zone/update?id="
let kMyGroups = "group/my"
let kDeleteGroup = "group/delete?id="
let kDeleteEvent = "event/delete?id="
let kUpdateEventData = "event/update?id="
let kUpdateGroupData = "group/update?id="
let kDirectConnection = "event/connection"
let kDeleteZone = "event-zone/delete?id="
let kUpdateName = "event-zone/update?id="
let kZoneStatus = "event-zone/status?id="
let kpostDroneData = "phone/flyzone"
let kgetTrackerLocation = "phone/get-tracker?id="
let kLockedConfirmationZone = "event-zone/locked?zone_id="

// MARK: - USER DEFAULTS
let kEmail = "flyzone_email"
let kPassword = "flyzone_password"
var appColor = UIColor(red: 64/255, green: 160/255, blue: 215/255, alpha: 1)

// MARK: - Protocol

@objc protocol WebServiceDelegate
{
    func retryMethod(_ paramsDic:Dictionary<String,AnyObject>, withServiceUrl:NSString, error:NSError?)
}

var delegateObject: WebServiceDelegate?
class proxy: NSObject {
    
    // MARK: - Class Variables
    
    class func sharedProxy() -> proxy {
        shareInstance = proxy()
        return shareInstance
    }
    
    func checkStringIfNull(_ content: String) -> String {
        if ((content == "null")) || ((content == "(null)")) || ((content == "<null>")) || ((content == "nil")) || ((content == "")) || ((content == "<nil>")) || (content.characters.count == 0){
            return ""
        }
        else {
            return content
        }
    }
    
    
    func getRandomColor() -> UIColor{
        //Generate between 0 to 1
        let red:CGFloat = CGFloat(drand48())
        let green:CGFloat = CGFloat(drand48())
        let blue:CGFloat = CGFloat(drand48())
        
        return UIColor(red:red, green: green, blue: blue, alpha: 0.40)
    }
    
    func authNil () -> String
    {
        if(UserDefaults.standard.object(forKey: "auth_code") == nil){
            return ""
        }
        else{
            return String(describing: UserDefaults.standard.object(forKey: "auth_code") as AnyObject)
        }
    }
    
    func intersectionBetweenSegmentsCL(_ p0: CLLocationCoordinate2D,  p1: CLLocationCoordinate2D,  p2: CLLocationCoordinate2D,  p3: CLLocationCoordinate2D) -> Bool {
        var denominator = (p3.longitude - p2.longitude) * (p1.latitude - p0.latitude) - (p3.latitude - p2.latitude) * (p1.longitude - p0.longitude)
        var ua = (p3.latitude - p2.latitude) * (p0.longitude - p2.longitude) - (p3.longitude - p2.longitude) * (p0.latitude - p2.latitude)
        var ub = (p1.latitude - p0.latitude) * (p0.longitude - p2.longitude) - (p1.longitude - p0.longitude) * (p0.latitude - p2.latitude)
        
        if (denominator < 0) {
            ua = -ua; ub = -ub; denominator = -denominator
        }
        
        if ua >= 0.0 && ua <= denominator && ub >= 0.0 && ub <= denominator && denominator != 0 {
            print("INTERSECT")
           // return CLLocationCoordinate2D(latitude: p0.latitude + ua / denominator * (p1.latitude - p0.latitude), longitude: p0.longitude + ua / denominator * (p1.longitude - p0.longitude))
            return true
        }
        return false
    }
    
    //MARK: - DRAW POLYGON 
    func getPolygonFromDictionary(arrTemp:NSMutableArray,strTitle: String) -> MKPolygon {
        
        let arrDrawAreaCoordinate = NSMutableArray()
        var userLoc1 = CLLocationCoordinate2D()
        for i in 0 ..< arrTemp.count{
            var dict = NSDictionary()
            dict = arrTemp[i] as! NSDictionary
            let lat = dict["lat"] as! String
            let long = dict["longt"] as! String
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            userLoc1.latitude = Double(newLat)!
            userLoc1.longitude = Double(newLong)!
           let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
            arrDrawAreaCoordinate.add(loc)
        }
        
        let numberOfSteps: Int =  arrDrawAreaCoordinate.count
        var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
        let firstLocation =  arrDrawAreaCoordinate[0] as! CLLocation
        for index in 0 ..< numberOfSteps
        {
            let location: CLLocation =  arrDrawAreaCoordinate[index] as! CLLocation
            points.append(location.coordinate)
        }
        points.append(firstLocation.coordinate)
        let polygon = MKPolygon(coordinates: &points, count: points.count)
        polygon.title = strTitle
        polygon.subtitle = ""
        return polygon

    }
    
    //MARK:- CALCULATE HEADING TOWARDS A LOCATION 
    func getBearingBetweenTwoPoints1(point1 : CLLocationCoordinate2D, point2 : CLLocationCoordinate2D) -> Double {
        
        let lat1 = degreesToRadians(degrees: point1.latitude)
        let lon1 = degreesToRadians(degrees: point1.longitude)
        
        let lat2 = degreesToRadians(degrees: point2.latitude)
        let lon2 = degreesToRadians(degrees: point2.longitude)
        
        let dLon = lon2 - lon1
        
        let y = sin(dLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        let radiansBearing = atan2(y, x)
        
        return radiansToDegrees(radians: radiansBearing)
    }
    
    func degreesToRadians(degrees: Double) -> Double { return degrees * M_PI / 180.0 }
    func radiansToDegrees(radians: Double) -> Double { return radians * 180.0 / M_PI }

    
    //MARK:- SHORTEST DISTANCE BETWEEN DRONE AND OUTER EDGES
    func distanceFromPoint(p: CGPoint, toLineSegment l1: CGPoint, and l2: CGPoint) -> NSMutableDictionary {
        
        let A = p.x - l1.x
        let B = p.y - l1.y
        let C = l2.x - l1.x
        let D = l2.y - l1.y
        let dot = A * C + B * D
        let len_sq = C * C + D * D
        let param = dot / len_sq
        var xx, yy: CGFloat
        
        if param < 0 || (l1.x == l2.x && l1.y == l2.y) {
            xx = l1.x
            yy = l1.y
        } else if param > 1 {
            xx = l2.x
            yy = l2.y
        } else {
            xx = l1.x + param * C
            yy = l1.y + param * D
        }
        
        let dx = p.x - xx
        let dy = p.y - yy
        let minimum_distance = sqrt(dx * dx + dy * dy)
        
        let dictInfo = NSMutableDictionary()
        dictInfo.setObject(minimum_distance, forKey: "minimum_distance" as NSCopying)
        dictInfo.setObject(xx, forKey: "xPos" as NSCopying)
        dictInfo.setObject(yy, forKey: "yPos" as NSCopying)
        
        return dictInfo
    }
    
    //MARK: - LOCATION COORDINATES TO X-Y POSITION
    
    func convertLocationCoordinatesToXYPosition(_ locationCoordinatesOfEdges: CLLocationCoordinate2D, mapView: MKMapView) -> CGPoint  {
        let point = mapView.convert(locationCoordinatesOfEdges, toPointTo: mapView)
        return point
    }
    
    
    
    
    func getLocationFromDictionary(_ dictLocationInfo:NSMutableDictionary) -> CLLocationCoordinate2D {
        var zoneLoc = CLLocationCoordinate2D()
        let lat = dictLocationInfo["lat"] as! String
        let long = dictLocationInfo["longt"] as! String
        let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        zoneLoc.latitude = Double(newLat)!
        zoneLoc.longitude = Double(newLong)!
        return zoneLoc
    }
    
    //MARK:- GET CLLOCATIONCOORDINATE2D
    func getCllocationCoordinate2d(_ arrLatLongData: NSMutableArray) -> NSMutableArray {
        let arrAreaCoordinate = NSMutableArray()
        var userLoc1 = CLLocationCoordinate2D()
        for i in 0 ..< arrLatLongData.count{
            var dict = NSDictionary()
            dict = arrLatLongData[i] as! NSDictionary
            let lat = dict["lat"] as! String
            let long = dict["longt"] as! String
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            userLoc1.latitude = Double(newLat)!
            userLoc1.longitude = Double(newLong)!
           
            let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
            arrAreaCoordinate.add(loc)
        }
        
        return arrAreaCoordinate
    }
    
    func makeCoordinatePoints(_ arrDrawAreaCoordinate:NSMutableArray) -> [CLLocationCoordinate2D] {
        let numberOfSteps: Int =  arrDrawAreaCoordinate.count
        var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
       
        for index in 0 ..< numberOfSteps
        {
            let location: CLLocation =  arrDrawAreaCoordinate[index] as! CLLocation
            points.append(location.coordinate)
        }
        return points
    }
    
    //MARK:- Show alert
    
    func showAlert(_ title:String, message:String, buttonAction:String)  {
        let alert = UIAlertView()
        alert.title = title
        alert.message = message
        alert.addButton(withTitle: buttonAction)
        alert.show()
    }

    //MARK: - FIND THE CENTER COORDINATES BETWEEN TWO POINTS 
     func findCenterPoint(_ lo1: CLLocationCoordinate2D, loc2: CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        var center =  CLLocationCoordinate2D()
        let lon1: Double = lo1.longitude * .pi / 180
        let lon2: Double = loc2.longitude * .pi / 180
        let lat1: Double = lo1.latitude * .pi / 180
        let lat2: Double = loc2.latitude * .pi / 180
        let dLon: Double = lon2 - lon1
        let x: Double = cos(lat2) * cos(dLon)
        let y: Double = cos(lat2) * sin(dLon)
        let lat3: Double = atan2(sin(lat1) + sin(lat2), sqrt((cos(lat1) + x) * (cos(lat1) + x) + y * y))
        let lon3: Double = lon1 + atan2(y, cos(lat1) + x)
        center.latitude = lat3 * 180 / .pi
        center.longitude = lon3 * 180 / .pi
        return center
    }
    
    // MARK:- CHECK CONTAINS STRING
    func containsOnlyLetters(_ input: String) -> Bool {
        for chr in input.characters {
            if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") ) {
                return false
            }
        }
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789")
        if input.rangeOfCharacter(from: characterset.inverted) != nil {
            print("string contains special characters")
            return false
        }
        return true
    }
    
    //MARK:- DATES FUNCTIONS
    func getTimeString(_ strDate:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"//this your string date format
        let date = dateFormatter.date(from: strDate)
        dateFormatter.dateFormat = "dd.MM.yyyy"///this is you want to convert format
        let timeStamp = dateFormatter.string(from: date!)
        return timeStamp
    }
    
    func expiryDateCheckMethod(_ expiryDate: String)->Bool
    {
        let DateInFormat = DateFormatter()
        DateInFormat.timeZone = TimeZone(identifier: "UTC")
        DateInFormat.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let expiryDate = DateInFormat.date(from: expiryDate)
        
        let f:DateFormatter = DateFormatter()
        f.timeZone = TimeZone.autoupdatingCurrent
        f.dateFormat = "yyyy-MM-dd HH:mm:ss z"
        
        let now = f.string(from: Date())
        let currentDate = f.date(from: now)
        let offsetTime = TimeInterval(NSTimeZone.local.secondsFromGMT())
        let finalTime = currentDate!.addingTimeInterval(offsetTime)
        if finalTime.compare(expiryDate!) == ComparisonResult.orderedDescending
        {
            return false
        }
        else if currentDate!.compare(expiryDate!) == ComparisonResult.orderedAscending
        {
            return true
        }
        else{
            return true
        }
    }
    
    //MARK:- GET SHORTEST POINT BETWEEN LINE SEGMENT
    
    func findDistanceOfSegementLineToPoint(_ p:CLLocationCoordinate2D , start:CLLocationCoordinate2D, end:CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        
        let s0lat = Double(p.latitude).degreesToRadians
        let s0lng = Double(p.longitude).degreesToRadians
        let s1lat = Double(start.latitude).degreesToRadians
        let s1lng = Double(start.longitude).degreesToRadians
        let s2lat = Double(end.latitude).degreesToRadians
        let s2lng = Double(end.longitude).degreesToRadians
        let s2s1lat = s2lat - s1lat;
        let s2s1lng = s2lng - s1lng;
        let u = ((s0lat - s1lat) * s2s1lat + (s0lng - s1lng) * s2s1lng)
            / (s2s1lat * s2s1lat + s2s1lng * s2s1lng)
        if (u <= 0) {
            return start;
        }
        if (u >= 1) {
            return end;
        }

        return CLLocationCoordinate2D.init(latitude: start.latitude + (u * (end.latitude - start.latitude)), longitude: start.longitude + (u * (end.longitude - start.longitude)))
        
    }
    
    //MARK:- GET MAXIMUM DISTANCE FROM EDGE
    
    func getMaximumEdge(arrTemp: NSArray,droneLocationPoint:CGPoint,mapVw:MKMapView,droneLocationCoordinate:CLLocationCoordinate2D) -> Float {
        //IMPLEMENTING DISTANCE FROM EDGES
        //1.Draw lines and convert location to x-y coordinates
       
        let arrDroneLivePositionNearestEdges = NSMutableArray()
        if arrTemp.count > 0{
            for i in 0..<arrTemp.count {
                //GET LOCATION COORDINATES
                if i < arrTemp.count-1 {
                    let dronePosA = getLocationFromDictionary(arrTemp[i] as! NSMutableDictionary)
                    let dronePosB = getLocationFromDictionary(arrTemp[i+1] as! NSMutableDictionary)
                    let droneNearestEdgePoint = distanceFromPoint(p: droneLocationPoint, toLineSegment: convertLocationCoordinatesToXYPosition(dronePosA, mapView: mapVw), and: convertLocationCoordinatesToXYPosition(dronePosB, mapView: mapVw))
                    arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                    
                }else{
                    let dronePosA = getLocationFromDictionary(arrTemp[0] as! NSMutableDictionary)
                    let dronePosB = getLocationFromDictionary(arrTemp[arrTemp.count - 1] as! NSMutableDictionary)
                    let droneNearestEdgePoint = distanceFromPoint(p: droneLocationPoint, toLineSegment: convertLocationCoordinatesToXYPosition(dronePosA, mapView: mapVw), and: convertLocationCoordinatesToXYPosition(dronePosB, mapView: mapVw))
                    arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                }
            }
            
            
            
            var minimum_edge_distance = (arrDroneLivePositionNearestEdges[0] as! NSDictionary).object(forKey: "minimum_distance") as! CGFloat
            var indexPosition = 0
            
            //2.FIND Maximum COORDINATES DISTANCE EDGE
            for i in 0..<arrDroneLivePositionNearestEdges.count{
                let dictEdgeInfo = arrDroneLivePositionNearestEdges[i] as! NSDictionary
                let edge_distance = dictEdgeInfo.object(forKey: "minimum_distance") as! CGFloat
                if edge_distance >= minimum_edge_distance {
                    minimum_edge_distance = edge_distance
                    indexPosition = i
                }
            }
            
            //3.GET DISTANCE BETWEEN TWO LATITUDE AND LONGITUDE
            let xPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "xPos") as! CGFloat
            let yPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "yPos") as! CGFloat
            let droneNearestPointInCoordinateSytem = CGPoint(x: xPosition, y: yPosition)
            let locationCoordinate = mapVw.convert(droneNearestPointInCoordinateSytem,toCoordinateFrom: mapVw)
            let coordinate₀ = CLLocation(latitude: droneLocationCoordinate.latitude, longitude: droneLocationCoordinate.longitude)
            
            let coordinate₁ = CLLocation(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude)
            //  let isHeadingTowardsTheCoordinates = coordinate₀.bearingToLocationDegrees(destinationLocation: coordinate₁)
            //  proxy.sharedProxy().displayStatusCodeAlert("Heading towards the coordinates: \(isHeadingTowardsTheCoordinates)")
            let distanceInMeters = coordinate₀.distance(from: coordinate₁)
            return Float(distanceInMeters)
        }else{
        
            return 0.0
        }
    }
    
    
    //MARK: -  GET CENTER COOORDINATES OF POLYGON
    
    func getCenterCoord(_ LocationPoints: [CLLocationCoordinate2D]) -> CLLocationCoordinate2D{
        var x:Float = 0.0;
        var y:Float = 0.0;
        var z:Float = 0.0;
        for points in LocationPoints {
            let lat = GLKMathDegreesToRadians(Float(points.latitude));
            let long = GLKMathDegreesToRadians(Float(points.longitude));
            
            x += cos(lat) * cos(long);
            
            y += cos(lat) * sin(long);
            
            z += sin(lat);
        }
        x = x / Float(LocationPoints.count);
        y = y / Float(LocationPoints.count);
        z = z / Float(LocationPoints.count);
        let resultLong = atan2(y, x);
        let resultHyp = sqrt(x * x + y * y);
        let resultLat = atan2(z, resultHyp);
        let result = CLLocationCoordinate2D(latitude: CLLocationDegrees(GLKMathRadiansToDegrees(Float(resultLat))), longitude: CLLocationDegrees(GLKMathRadiansToDegrees(Float(resultLong))));
        return result;
    }


    //MARK: - GET INTERSECTION OF SEGMENT AND POLYGON
    func getIntersectionOfSegmentAndPolygon(arrLineSegments:NSMutableArray,arrPolygonCoordinates:NSMutableArray) -> NSMutableArray {
        let arrIntersectingPoints = NSMutableArray()
        let arrLines = NSMutableArray()
        for i in 0..<arrLineSegments.count{
            //Get segment points
            let dictSegmentPoints = arrLineSegments.object(at: i) as! NSMutableDictionary
            var p1 = CGPoint(x:0.0,y:0.0)
            var p2 = CGPoint(x:0.0,y:0.0)
            p1 = dictSegmentPoints.object(forKey: "point_p1") as! CGPoint
            p2 = dictSegmentPoints.object(forKey: "point_p2") as! CGPoint
           
            for j in 0..<arrPolygonCoordinates.count {
                //Get polygon points
                let dictPolygonPoints = arrPolygonCoordinates[j] as! NSMutableDictionary
                let polygon_p1 = dictPolygonPoints.object(forKey: "polygon_p1") as! CGPoint
                let polygon_p2 = dictPolygonPoints.object(forKey: "polygon_p2") as! CGPoint
                let dictIntersectionpoints = self.getIntersectionOfLines(line1: (a: p1, b: p2), line2: (a: polygon_p1, b: polygon_p2))
                let is_intersection_found = dictIntersectionpoints.object(forKey: "is_intersect") as! String
               
                if i%2 == 0 {
                    dictIntersectionpoints.setObject("1", forKey: "is_even" as NSCopying)
                }else{
                 dictIntersectionpoints.setObject("0", forKey: "is_even" as NSCopying)
                }
                
                if is_intersection_found == "1" {
                    dictIntersectionpoints.setObject("\(i)", forKey: "line_number" as NSCopying)
                    let dictLines = NSMutableDictionary()
                    dictLines.setObject("\(i)", forKey: "line_number" as NSCopying)
                    arrIntersectingPoints.add(dictIntersectionpoints)
                }
            }
        }
        
        
        return arrIntersectingPoints
    }
    
    //MARK: GET INTERSECTION OF TWO LINES
    func getIntersectionOfLines(line1: (a: CGPoint, b: CGPoint), line2: (a: CGPoint, b: CGPoint)) -> NSMutableDictionary {
        let distance = (line1.b.x - line1.a.x) * (line2.b.y - line2.a.y) - (line1.b.y - line1.a.y) * (line2.b.x - line2.a.x)
        if distance == 0 {
            print("error, parallel lines")
            let dict = NSMutableDictionary()
            dict.setObject("0", forKey: "is_intersect" as NSCopying)
            dict.setObject(CGPoint(x: 0.0, y: 0.0), forKey: "intersection_points" as NSCopying)
            return dict
        }
        
        let u = ((line2.a.x - line1.a.x) * (line2.b.y - line2.a.y) - (line2.a.y - line1.a.y) * (line2.b.x - line2.a.x)) / distance
        let v = ((line2.a.x - line1.a.x) * (line1.b.y - line1.a.y) - (line2.a.y - line1.a.y) * (line1.b.x - line1.a.x)) / distance
        
        if (u < 0.0 || u > 1.0) {
          //  print("error, intersection not inside line1")
            let dict = NSMutableDictionary()
            dict.setObject("0", forKey: "is_intersect" as NSCopying)
            dict.setObject(CGPoint(x: 0.0, y: 0.0), forKey: "intersection_points" as NSCopying)
            return dict
        }
        if (v < 0.0 || v > 1.0) {
          //  print("error, intersection not inside line2")
            let dict = NSMutableDictionary()
            dict.setObject("0", forKey: "is_intersect" as NSCopying)
            dict.setObject(CGPoint(x: 0.0, y: 0.0), forKey: "intersection_points" as NSCopying)
            return dict
        }
        
        print("Success intersection found")
        let dict = NSMutableDictionary()
        dict.setObject("1", forKey: "is_intersect" as NSCopying)
        dict.setObject(CGPoint(x: line1.a.x + u * (line1.b.x - line1.a.x),y: line1.a.y + u * (line1.b.y - line1.a.y)), forKey: "intersection_points" as NSCopying)
        return dict
    }
    
    func getIntersectionOfLinesForGettingBool(line1: (a: CGPoint, b: CGPoint), line2: (a: CGPoint, b: CGPoint)) -> Bool {
       var isIntersect = Bool()
        isIntersect = true
        let distance = (line1.b.x - line1.a.x) * (line2.b.y - line2.a.y) - (line1.b.y - line1.a.y) * (line2.b.x - line2.a.x)
       
        if distance == 0 {
            print("error, parallel lines")
            isIntersect = false
            return isIntersect
        }
        
        let u = ((line2.a.x - line1.a.x) * (line2.b.y - line2.a.y) - (line2.a.y - line1.a.y) * (line2.b.x - line2.a.x)) / distance
       
        let v = ((line2.a.x - line1.a.x) * (line1.b.y - line1.a.y) - (line2.a.y - line1.a.y) * (line1.b.x - line1.a.x)) / distance
        
        if (u < 0.0 || u > 1.0) {
            print("error, intersection not inside line1")
            isIntersect = false

            return isIntersect
        }
        
        if (v < 0.0 || v > 1.0) {
            print("error, intersection not inside line2")
            isIntersect = false

            return isIntersect
        }
        return isIntersect
    }
    
    //MARK: - GET SEGMENTS
    
    func getSegments(_ transformedView:UIView,numberOfDivisions:Int32,angle: Double) -> NSMutableArray{
        let arrSegments = NSMutableArray()
        let startingPoint = transformedView.frame.origin
        let eachVerticalStepSize = Float(transformedView.frame.size.height)/Float(numberOfDivisions)
        for i in 1..<numberOfDivisions{
        let point_p1 = CGPoint(x: startingPoint.x,y: CGFloat(Float(i) * eachVerticalStepSize))
        let point_p2 = CGPoint(x: CGFloat( transformedView.frame.size.width) ,y: CGFloat((Float(i) * eachVerticalStepSize) ))
            let dict =  NSMutableDictionary()
            if i%2 == 0 {
                dict.setObject("1", forKey: "is_even" as NSCopying)
            }else{
                 dict.setObject("0", forKey: "is_even" as NSCopying)
            }
            dict.setObject(point_p1, forKey: "point_p1" as NSCopying)
            dict.setObject(point_p2, forKey: "point_p2" as NSCopying)
            arrSegments.add(dict)
        }
        return arrSegments
    }
    
    func getSegmentsRotate(_ transformedView:UIView,numberOfDivisions:Int32,angle: Double,initialView:UIView) -> NSMutableArray{
        let arrSegments = NSMutableArray()
        let startingPoint = initialView.frame.origin
        let eachVerticalStepSize = Float(initialView.frame.size.height)/Float(numberOfDivisions)
        for i in 1..<numberOfDivisions{
            
        let point_p1 = CGPoint(x: startingPoint.x,y: CGFloat(Float(i) * eachVerticalStepSize))
        let point_p2 = CGPoint(x: CGFloat( initialView.frame.size.width) ,y: CGFloat((Float(i) * eachVerticalStepSize) ))
            
            let point_p1_transformed = initialView.convert(point_p1, to: transformedView)
            let point_p2_transformed = initialView.convert(point_p2, to: transformedView)
            
            let dict =  NSMutableDictionary()
            if i%2 == 0 {
                dict.setObject("1", forKey: "is_even" as NSCopying)
            }else{
                dict.setObject("0", forKey: "is_even" as NSCopying)
            }
            dict.setObject(point_p1_transformed, forKey: "point_p1" as NSCopying)
            dict.setObject(point_p2_transformed, forKey: "point_p2" as NSCopying)
            arrSegments.add(dict)
        }
        return arrSegments
    }

    
    // MARK: - Error Handling
    func stautsHandler(_ url:String, parameter:Dictionary<String,AnyObject>? = nil, response:HTTPURLResponse?, data:Data?, error:NSError?)
    {
        
        if  response?.statusCode == 400
        {
            displayStatusCodeAlert("bad url")
        }
        else if response?.statusCode == 401
        {
            displayStatusCodeAlert("unauthorized")
        }
        else if response?.statusCode == 404
        {
            displayStatusCodeAlert("file not found")
        }
        else if response?.statusCode ==  500
        {
            let myHTMLString = NSString(data: data!, encoding:String.Encoding.utf8.rawValue)
            HtmlDisplayStatusAlert(myHTMLString as! String)
            debugPrint("HTML string : \(myHTMLString as! String)")
            
        }
        else if response?.statusCode == 408
        {
            RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter, Response:response, data:data, Error:error)
        }
        else if error?.code == -1001
        {
            RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter, Response:response, data:data, Error:error)
        }
        else if error?.code == -1009
        {
            RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter, Response:response, data:data, Error:error)
        }
    }
    
    func displayStatusCodeAlert(_ userMessage: String)
    {
        UIView.hr_setToastThemeColor(color: appColor)
        KAppDelegate.window!.makeToast(message: userMessage)
    }
    
    //MARK: - Alert Native Dismiss
    func showAlert(_ title: String,message: String)  {
         var alertVc = UIAlertController()
        alertVc = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        UIApplication.shared.keyWindow?.rootViewController?.present(alertVc, animated: true, completion: {
            let delay = 2.0 * Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                alertVc.dismiss(animated: true, completion: nil)
            }
        })
    }
    
    
    
    // Html Display Alert
    
    func HtmlDisplayStatusAlert(_ userMessage: String)
    {
        var codeErrorAlert = UIAlertController()
        DispatchQueue.main.async
        {
            codeErrorAlert = UIAlertController(title: "", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
            codeErrorAlert.addAction(UIAlertAction(title: "Show", style: .default, handler: { action in
            }))
            UIApplication.shared.keyWindow?.rootViewController?.present(codeErrorAlert, animated: true, completion: nil)
        }
        
    }
    

    //#MARK: - Email Validations
    
    func isValidEmail(_ testStr:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let range = testStr.range(of: emailRegEx, options:.regularExpression)
        let result = range != nil ? true : false
        return result
    }
   
    func openSettingApp()
    {
        var settingAlert = UIAlertController()
        DispatchQueue.main.async
            {
                KAppDelegate.hideActivityIndicator()
                settingAlert = UIAlertController(title: "Connection Problem", message: "Please check your internet connection", preferredStyle: UIAlertControllerStyle.alert)
                let okAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
                settingAlert.addAction(okAction)
                
                let openSetting = UIAlertAction(title:"Setting", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                  UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
                })
                settingAlert.addAction(openSetting)
                UIApplication.shared.keyWindow?.rootViewController?.present(settingAlert, animated: true, completion: nil)
                
        }
    }
    
    
    func RequestTimeOutAlertMessage(_ alrtMessage:NSString, Url:String, Parameter:Dictionary<String, AnyObject>? = nil, Response: HTTPURLResponse? , data: Data? , Error:NSError?)
     {
        KAppDelegate.hideActivityIndicator()
        
        if (Parameter?.count) > 0
        {
            
            var timeOutAlert = UIAlertController()
            timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction = UIAlertAction(title:"Cancel", style:UIAlertActionStyle.default, handler: nil)
            timeOutAlert.addAction(okAction)
            
            let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                delegateObject!.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
            })
            
            timeOutAlert.addAction(retryAction)
            UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
        }
        else
        {
            
            var timeOutAlert = UIAlertController()
            timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: nil)
            timeOutAlert.addAction(okAction)
            let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                if(Parameter != nil){
                    delegateObject!.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
                }
                else{
                    delegateObject?.retryMethod([:], withServiceUrl:Url as NSString, error:Error)
                }
                
            })
            
            timeOutAlert.addAction(retryAction)
            
            UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
            
        }
    }
    
    func getAltitudeDictionary(arrTemp:NSArray) -> NSDictionary {
        
        var maximum_height = Int32()
        var minimum_height = Int32()
        let arrMinimum = NSMutableArray()
        let arrMaximum = NSMutableArray()
        maximum_height = 0
        minimum_height = 0
        
        //Maximum array Int32(((dict["max_alt"] as! NSNumber).intValue))
        for dict in arrTemp {
            let dictSome = dict as! NSDictionary
            let height = Int32(((dictSome["max_alt"] as! NSString).intValue))
            arrMaximum.add(NSNumber.init(value: height ))
        }
        
        //Minimum array
        for dict in arrTemp {
            let dictSome = dict as! NSDictionary
            let height = Int32(((dictSome["min_alt"] as! NSString).intValue))
            arrMinimum.add(NSNumber.init(value: height ))
        }
        
        //Find max
        if arrMaximum.count > 0 {
            let max = arrMaximum[0] as! NSNumber
            maximum_height = max.int32Value
            for i in 0 ..< arrMaximum.count{
                let max_num = arrMaximum[i] as! NSNumber
                if max_num.int32Value >= maximum_height {
                    maximum_height = max_num.int32Value
                    
                }
            }
        }
        
        //Find Minimum
        if arrMinimum.count > 0 {
            let maxVal = arrMinimum[0] as! NSNumber
            minimum_height = maxVal.int32Value
            for i in 0 ..< arrMinimum.count{
                let  minimum_num = arrMinimum[i] as! NSNumber
                if minimum_num.int32Value <= minimum_height {
                    minimum_height = minimum_num.int32Value
                }
            }
        }
        let converted_max_ht = Float(maximum_height)/3.2808
        let converted_min_ht = Float(minimum_height)/3.2808
        
        let dictInfo = NSMutableDictionary()
        dictInfo.setObject(converted_min_ht, forKey: "minimum_height" as NSCopying)
        dictInfo.setObject(converted_max_ht, forKey: "maximum_height" as NSCopying)
        
        return dictInfo
    }
    
    //MARK: - FIND THE DISTANCE BETWEEN THE TWO POINTS 
    func getDistanceInm(_ newLocation: CLLocation, from oldLocation: CLLocation) -> Float {
        var lat1: Float
        var lon1: Float
        var lat2: Float
        var lon2: Float
        lat1 = Float(newLocation.coordinate.latitude * .pi) / 180
        lon1 = Float(newLocation.coordinate.longitude * .pi) / 180
        lat2 = Float(oldLocation.coordinate.latitude * .pi) / 180
        lon2 = Float(oldLocation.coordinate.longitude * .pi) / 180
        let R: Float = 6371
        // km
        let dLat: Float = lat2 - lat1
        let dLon: Float = lon2 - lon1
        let a: Float = sin(dLat / 2) * sin(dLat / 2) + cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
        let c: Float = 2 * atan2(sqrt(a), sqrt(1 - a))
        let d: Float = R * c
        return d * 1000
    }
}
