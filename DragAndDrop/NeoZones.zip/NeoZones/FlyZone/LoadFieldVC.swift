//
//  LoadFieldVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 07/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class LoadFieldVC: UIViewController, UITableViewDelegate, UITableViewDataSource,setLocationDelegateOffline {

    //MARK:- VARIABLE
    var arrUserEvents = NSMutableArray()
    
    @IBOutlet weak var btnAddOutlet: UIButton!
    @IBOutlet weak var imgVwAdd: UIImageView!
    @IBOutlet weak var tblVwFields: UITableView!
    var strName = String()
    var nameField = UITextField()
   
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        arrUserEvents  = DBManager.sharedDatabase().getMessage("SELECT * FROM OfflineTBL order by id ASC")
        if arrUserEvents.count > 0  {
            tblVwFields.reloadData()
        }
    }
    
    @IBAction func btnBack(_ sender: AnyObject) {
     _ =   self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnAddFieldAction(_ sender: AnyObject) {
        let createZoneVC = storyboard?.instantiateViewController(withIdentifier: "CreateZonePopupVC") as! CreateZonePopupVC
        protocolObjectOfflineZone = self
        createZoneVC.modalTransitionStyle = .crossDissolve
        createZoneVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createZoneVC, animated: true, completion: nil)

    }
    
    func setLocationOfEventOffline(_ strName:String)
    {
        var arrTempEvents = DBManager.sharedDatabase().getMessage("SELECT * FROM OfflineTBL order by id ASC")
          let  strZone = "[]"
        if arrTempEvents.count > 0 {
            let modalObject = arrUserEvents.lastObject as! EventOffline
            let enteriesQuery = NSString(format: "INSERT INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",modalObject.id+1, strName,strZone)
            DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
            
        }else{
            let enteriesQuery = NSString(format: "INSERT INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",1, strName,strZone)
            DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
        }
        
       arrTempEvents  = DBManager.sharedDatabase().getMessage("SELECT * FROM OfflineTBL order by id ASC")
        if  arrTempEvents.count > 0 {
            arrUserEvents = arrTempEvents.mutableCopy() as! NSMutableArray
             tblVwFields.reloadData()
        }
        
       //let mainVc = KAppDelegate.StoryBoard.instantiateViewControllerWithIdentifier("CreateZoneVC") as! CreateZoneVC
//        self.navigationController?.pushViewController(mainVc, animated: true)
        
    }
    
    
    
    //MARK: - TableView Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrUserEvents.count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 88
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVwFields.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! LoadFieldTVC
        var modalObject = EventOffline()
        if arrUserEvents.count > 0 {
        modalObject = arrUserEvents[(indexPath as NSIndexPath).row] as! EventOffline
        cell.lblFieldName.text = modalObject.name
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let mainVc = self.storyboard!.instantiateViewController(withIdentifier: "CreateOfflineZoneVC") as! CreateOfflineZoneVC
       if arrUserEvents.count > 0 {
        let modalObject = arrUserEvents[(indexPath as NSIndexPath).row] as! EventOffline
        mainVc.zoneCreateModal = modalObject
        mainVc.zone_id = modalObject.id
        mainVc.zone_name = modalObject.name
        mainVc.zone_array = modalObject.zones
        }
        self.navigationController?.pushViewController(mainVc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
    }
    
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
          let modalObject = self.arrUserEvents[(indexPath as NSIndexPath).row] as! EventOffline
        
        let delete = UITableViewRowAction(style: .destructive, title: "                    ") { (action, indexPath) in
            let alertController = UIAlertController(title: "", message: "Are you sure to delete \(modalObject.name)?", preferredStyle: .alert)
            let deleteAction = UIAlertAction(title: "Delete", style: .default, handler: {
                action in
              
                
                let enteriesQuery = NSString(format: "DELETE FROM 'OfflineTBL' WHERE id=\(modalObject.id) " as NSString )
                DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
                proxy.sharedProxy().displayStatusCodeAlert("Zone Deleted successfully")
                self.arrUserEvents.removeObject(at: (indexPath as NSIndexPath).row)
                 self.tblVwFields.reloadData()
                }
                
            )
            let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                action in
                }
            )
            alertController.addAction(deleteAction)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
        }
        let edit = UITableViewRowAction(style: .normal, title: "                     ") { (action, indexPath) in
           
            let alertController = UIAlertController(title: "Edit Zone", message: "Please enter name of zone", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
            }
            alertController.addAction(cancelAction)
            
            let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
                
               // self.forgetPassword(self.nameField.text!)
                
                var jsonString : NSString = ""
                do
                {
                    let arrJson = try JSONSerialization.data(withJSONObject: modalObject.zones, options: JSONSerialization.WritingOptions.prettyPrinted)
                    let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
                    jsonString = string! as NSString
                }
                catch let error as NSError
                {
                    print(error.description)
                }
                
                let enteriesQuery = NSString(format: "INSERT OR REPLACE INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",modalObject.id, self.nameField.text!,jsonString)
                DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
                proxy.sharedProxy().displayStatusCodeAlert("Zone Updated successfully")

                 self.arrUserEvents  = DBManager.sharedDatabase().getMessage("SELECT * FROM OfflineTBL order by id ASC")
                    self.tblVwFields.reloadData()
            }
            
            
            alertController.addTextField {
                (txtEmail) -> Void in
                txtEmail.placeholder = "Enter zone name"
                txtEmail.keyboardType = .emailAddress
                self.nameField = txtEmail
                
            }
            
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion:nil)

            
            }
        
        delete.backgroundColor = UIColor(patternImage: UIImage(named:"group_del_slider")!)
        edit.backgroundColor = UIColor(patternImage: UIImage(named:"group_edit_slider")!)
        return [delete, edit]
    }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
