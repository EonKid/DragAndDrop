//
//  ThreeDViewController.h
//  FlyZone
//
//  Created by Dhruv Singh on 05/09/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Nuti/Nuti.h>
#import "FlyZone-Bridging-Header.h"

@interface ThreeDViewController : GLKViewController

#pragma mark VARIABLE
@property (nonatomic,strong) NTMapView* mapView;
@property NSString* vectorStyleName;
@property NTMBVectorTileDecoder* vectorTileDecoder;
@property NTVectorTileLayer* baseLayer;
@property NTTileDataSource* vectorTileDataSource;
@property (nonatomic) NSString *strTitle;
@property (nonatomic) NSArray *arrAllZones;
@property (nonatomic) NSArray *arrColors;
#pragma mark IBOutlet
@property (weak, nonatomic) IBOutlet UIView *vwNavigation;

-(long )findMaximumHeight:(NSArray *)arrZones;
-(double)getTransformedX:(double)longitude;
-(double)getTransformedY:(double)latitude;
- (UIColor *)randomColor;
- (NSString *)hexStringFromColor:(UIColor *)color;
-(int)getRandomNumberBetween:(int)from to:(int)to;
#pragma mark Action
- (IBAction)btnActionClose:(id)sender;

@end
