//
//  MyGroupTVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class MyGroupTVC: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
