//
//  AnnotationModal.swift
//  FlyZone
//
//  Created by Dhruv Singh on 11/07/16.
//  Copyright © 2016 Dhruv Singh. All rights reserved.
//

import UIKit
import MapKit

class AnnotationModal: NSObject, MKAnnotation {
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var info: String
    var index: String
    var distnaceFromHomeLocation: String
    var isShowDistance  : Bool
    init(title: String, coordinate: CLLocationCoordinate2D, info: String,index: String,distnaceFromHomeLocation: String,isShowDistance: Bool) {
        self.title = title
        self.coordinate = coordinate
        self.info = info
        self.index = index
        self.distnaceFromHomeLocation = distnaceFromHomeLocation
        self.isShowDistance = isShowDistance
    }
}
