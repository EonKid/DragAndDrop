//
//  DroneAnnotation.swift
//  FlyZone
//
//  Created by Dhruv Singh on 25/10/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class DroneAnnotation: NSObject,MKAnnotation {
   
   dynamic var coordinate = CLLocationCoordinate2D()
    var annotationView: DJIAircraftAnnotationView?
    var title : String?
     init(coordiante coordinate: CLLocationCoordinate2D,title: NSString) {
        self.coordinate = coordinate
        self.title = title as String
    }
    
     func setNewCoordinate(_ newCoordinate: CLLocationCoordinate2D) {
        self.coordinate = newCoordinate
    }
  
    func updateHeading(_ heading: Float) {
        if (self.annotationView != nil) {
            self.annotationView?.updateHeading(heading)
            
        }
    }
}
