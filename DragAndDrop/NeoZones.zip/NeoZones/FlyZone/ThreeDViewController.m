//
//  ThreeDViewController.m
//  FlyZone
//
//  Created by Dhruv Singh on 05/09/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

#import "ThreeDViewController.h"
#import <Nuti/Nuti.h>
#import <Nuti/NTColor.h>
@implementation ThreeDViewController
double earthRadius = 6371;
double MERCATOR_OFFSET = 268435456.0;
double MERCATOR_RADIUS = 85445659.44705395;
double DEGREES = 180.0;

@synthesize strTitle;
@synthesize arrAllZones;
- (void)loadView
{
    [NTLog setShowDebug:YES];
    [NTLog setShowInfo:YES];
    // You can get your free/commercial license from: http://developer.nutiteq.com
    [NTMapView registerLicense:@"XTUN3Q0ZEcnIzeDhtUTFmVEtvbFhESXN5Q0ZvKzVrVkZBaFJWMDhFY3ZxK3JmelBodmZpVzFyWTdDdGUrOWc9PQoKcHJvZHVjdHM9c2RrLWlvcy0zLioKYnVuZGxlSWRlbnRpZmllcj1jb20uZHJvbmUubmVvRmx5em9uZQp3YXRlcm1hcms9bnV0aXRlcQpvbmxpbmVMaWNlbnNlPTEKdXNlcktleT00YmRhYTY2YzUwY2I4NTZkM2RlM2IyZWIyYTZkYjMyZgo="];
    
    self.mapView = [[NTMapView alloc] initWithFrame:CGRectMake(0, 64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    self.view = self.mapView;
    [self.mapView.getOptions setPanningMode:NT_PANNING_MODE_STICKY_FINAL];
}

#pragma mark Transformation X and Y
-(double)getTransformedX:(double)longitude{

    return longitude * 111319.49079327358;
}
-(double)getTransformedY:(double)latitude{

    return log(fmax(0.0, tan(latitude * 0.008726646259971648 +  0.7853981633974483))) * 6378137.0000000009;
}

#pragma mark Find maximum
-(long)findMaximumHeight:(NSArray *)arrData{
   NSDictionary  *dictTemp = [arrData objectAtIndex:0];
    NSString *str_maximum_height = [NSString stringWithFormat:@"%@",[dictTemp objectForKey:@"max_alt"]];
    long maximum_height = [str_maximum_height stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].integerValue;
    for (NSDictionary *dictSample in arrData) {
    NSString *str_maximum_height_temp = [NSString stringWithFormat:@"%@",[dictSample objectForKey:@"max_alt"]];
        long maximum_height_temp = [str_maximum_height_temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].integerValue;
        if (maximum_height < maximum_height_temp) {
            maximum_height = maximum_height_temp;
        }
    }
    return maximum_height;
}
- (UIColor *)randomColor {
    return [UIColor colorWithRed:((float)rand() / RAND_MAX)
                        green:((float)rand() / RAND_MAX)
                         blue:((float)rand() / RAND_MAX)
                        alpha:1.0f];
}
-(int)getRandomNumberBetween:(int)from to:(int)to {
    return (int)from + arc4random() % (to-from+1);
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.arrColors = @[
                    @0x330000ff,@0x331900ff,@0x333300ff,@0x193300ff,@0x003300ff,
                    @0x003319ff,@0x003333ff,@0x001933ff,@0x190033ff,@0x190033ff,
                    @0x330033ff,@0x330019ff,@0x00000000,@0x660000ff,@0x663300ff,
                    @0x666600ff,@0x336600ff,@0x006600ff,@0x006633ff,@0x006666ff
                  ];
    
    NSLog(@"arrZones: %@ \n All Zones ",arrAllZones);
    NTEPSG3857* proj = [[NTEPSG3857 alloc] init];
    [[self.mapView getOptions] setBaseProjection:proj];
     NSDictionary *dictTemp = [NSDictionary new];
    if (arrAllZones.count > 0) {
        
        for (NSDictionary *dict in arrAllZones) {
            NSArray *arrTemp  = [dict objectForKey:@"zones"];
            if (arrTemp.count > 0) {
                dictTemp = dict;
                break;
            }
        }
        
   
    dictTemp = [arrAllZones objectAtIndex:0];
        
    NSArray *arrTempFirstZone  = [dictTemp objectForKey:@"zones"];
        if (arrTempFirstZone.count > 0) {
    NSDictionary *dictTempZones = [NSDictionary new];
    dictTempZones = [arrTempFirstZone objectAtIndex:0];
    NSString *strLat = [NSString stringWithFormat:@"%@",[dictTempZones objectForKey:@"lat"]];
    NSString *strLong = [NSString stringWithFormat:@"%@",[dictTempZones objectForKey:@"longt"]];
    double latitude = [strLat stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
    double longitude = [strLong stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
    
    double x = [self getTransformedX:longitude];
    double y = [self getTransformedY:latitude];
   
    [self.mapView setFocusPos:[[NTMapPos alloc] initWithX:x y:y]  durationSeconds:0];
    [self.mapView setZoom:14 durationSeconds:0];
    [self.mapView setRotation:0 durationSeconds:0];
    // Set default style parameters and create base layer
    self.vectorStyleName = @"looseleaf";
    [self updateBaseLayer];
    }
    // GLKViewController-specific parameters for smoother animations
    [self setResumeOnDidBecomeActive:NO];
    [self setPreferredFramesPerSecond:60];
        
        for (int i = 0; i< arrAllZones.count; i++) {
           
            NSDictionary *dictTempZones = [NSDictionary new];
            dictTempZones = [self.arrAllZones objectAtIndex:i];
            NSArray *arrZones = [NSArray new];
            arrZones = [dictTempZones objectForKey:@"zones"];
            if (arrZones.count > 0) {
             long maximum_height = [self findMaximumHeight:arrZones];
            // Initialize a local vector data source
        NTLocalVectorDataSource* vectorDataSource = [[NTLocalVectorDataSource alloc] initWithProjection:proj];
            // Initialize a vector layer with the previous data source
            NTVectorLayer* vectorLayer = [[NTVectorLayer alloc] initWithDataSource:vectorDataSource];
            // Add the previous vector layer to the map
            [[self.mapView getLayers] add:vectorLayer];
            // Set visible zoom range for the vector layer
            [vectorLayer setVisibleZoomRange:[[NTMapRange alloc] initWithMin:10 max:24]];
            // Create 3D polygon style and poses
            NTPolygon3DStyleBuilder* polygon3DStyleBuilder = [[NTPolygon3DStyleBuilder alloc] init];
          //  int index = [self getRandomNumberBetween:0 to:19];
          //  int color = (int)[self.arrColors objectAtIndex:index];
            [polygon3DStyleBuilder setColor:[[NTColor alloc] initWithColor:0x800000FF]];
            
            //[polygon3DStyleBuilder setColor:[[NTColor alloc] initWithR: 123/255.0 g: 125/255.0 b: 125/255.0 a: 1.0]];
            // (2) X is longitude, Y is latitude, NOT like in many other APIs !
            NTMapPosVector* polygon3DPoses = [[NTMapPosVector alloc] init];
            for (NSDictionary *dictTemp in arrZones) {
                NSString *strLatNew = [NSString stringWithFormat:@"%@",[dictTemp objectForKey:@"lat"]];
                NSString *strLongNew = [NSString stringWithFormat:@"%@",[dictTemp objectForKey:@"longt"]];
                double latitudeNew = [strLatNew stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
                double longitudeNew = [strLongNew stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
                [polygon3DPoses add:[[NTMapPos alloc] initWithX:[self getTransformedX:longitudeNew] y:[self getTransformedY:latitudeNew]]];
            }
            
            NSDictionary *dictFirst = [arrZones objectAtIndex:0];
            NSString *strLatNew = [NSString stringWithFormat:@"%@",[dictFirst objectForKey:@"lat"]];
            NSString *strLongNew = [NSString stringWithFormat:@"%@",[dictFirst objectForKey:@"longt"]];
            double latitudeNew = [strLatNew stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
            double longitudeNew = [strLongNew stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
            
            [polygon3DPoses add:[[NTMapPos alloc] initWithX:[self getTransformedX:longitudeNew] y:[self getTransformedY:latitudeNew]]];
            // Create 3D polygon holes poses
            NTMapPosVector* polygon3DHolePoses = [[NTMapPosVector alloc] init];
            NTMapPosVectorVector* polygon3DHoles = [[NTMapPosVectorVector alloc] init];
            [polygon3DHoles add:polygon3DHolePoses];
            // Add to datasource
            NTPolygon3D* polygon3D = [[NTPolygon3D alloc] initWithGeometry:[[NTPolygonGeometry alloc] initWithPoses:polygon3DPoses holes:polygon3DHoles] style:[polygon3DStyleBuilder buildStyle] height: maximum_height];
            //[polygon3D setMetaDataElement:@"ClickText" element:@"3D Polygon"];
            [vectorDataSource add:polygon3D];
        }
        }
 
   
    }else{
        NSString *strLat = [[NSUserDefaults standardUserDefaults] objectForKey:@"lat"];
        NSString *strLong = [[NSUserDefaults standardUserDefaults] objectForKey:@"long"];
        double latitudeNew = [strLat stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
        double longitudeNew = [strLong stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]].doubleValue;
        if (strLat) {
            NTEPSG3857* proj = [[NTEPSG3857 alloc] init];
            [[self.mapView getOptions] setBaseProjection:proj];
            double x = [self getTransformedX:longitudeNew];
            double y = [self getTransformedY:latitudeNew];
            [self.mapView setFocusPos:[[NTMapPos alloc] initWithX:x y:y]  durationSeconds:0];
            [self.mapView setZoom:14 durationSeconds:0];
            [self.mapView setRotation:0 durationSeconds:0];
            // Set default style parameters and create base layer
            self.vectorStyleName = @"looseleaf";
            [self updateBaseLayer];
       
        }
    }
}



- (NSString *)hexStringFromColor:(UIColor *)color {
    const CGFloat *components = CGColorGetComponents(color.CGColor);
    CGFloat r = components[0];
    CGFloat g = components[1];
    CGFloat b = components[2];
    return [NSString stringWithFormat:@"#%02lX%02lX%02lX",
            lroundf(r * 255),
            lroundf(g * 255),
            lroundf(b * 255)];
}

-(NSDictionary*)styles
{
    return @{
             @"Basic":		   @"basic",
             @"NutiBright 2D": @"nutibright-v2a",
             @"Nutiteq dark": @"nutiteq-dark",
             @"NutiBright 3D": @"nutibright3d",
             @"Loose Leaf":	   @"looseleaf"
          };
}


- (void)updateBaseLayer
{

    // Load vector tile styleset
    NSString* styleAssetName = [self.vectorStyleName stringByAppendingString: @".zip"];
    BOOL styleBuildings3D = NO;
    if ([self.vectorStyleName isEqualToString:@"nutibright3d"]) {
        styleAssetName = @"nutibright-v2a.zip";
        styleBuildings3D = YES;
    }
    NTUnsignedCharVector *vectorTileStyleSetData = [NTAssetUtils loadBytes:styleAssetName];
    NTMBVectorTileStyleSet *vectorTileStyleSet = [[NTMBVectorTileStyleSet alloc] initWithData:vectorTileStyleSetData];
    
    // Create vector tile decoder using the styleset and update style parameters
    self.vectorTileDecoder = [[NTMBVectorTileDecoder alloc] initWithStyleSet:vectorTileStyleSet];
   
    if ([styleAssetName isEqualToString:@"nutibright-v2a.zip"] && styleBuildings3D) { // only OSM Bright style supports this currently
        [self.vectorTileDecoder setStyleBoolParameter:@"buildings3d" value:YES];
    }
    [self.vectorTileDecoder setStyleStringParameter:@"markers3d" value:@"1"];
    [self.vectorTileDecoder setStyleStringParameter:@"texts3d" value:@"1"];
    [self.vectorTileDecoder setStyleStringParameter:@"shields3d" value:@"1"];
    // special parameters for elevation contour style
    [self.vectorTileDecoder setStyleStringParameter:@"contour_stroke" value:@"rgba(217, 166, 140, 0.53)"];
    [self.vectorTileDecoder setStyleFloatParameter:@"contour_width" value:0.8];
    // Create tile data source
    if (!self.vectorTileDataSource) {
        self.vectorTileDataSource = [self createTileDataSource];
    }
    // Create vector tile layer, using previously created data source and decoder
    if (self.baseLayer) {
        [[self.mapView getLayers] remove:self.baseLayer];
    }
    self.baseLayer = [[NTVectorTileLayer alloc] initWithDataSource:self.vectorTileDataSource decoder:self.vectorTileDecoder];
    
    // Add vector tile layer
    [[self.mapView getLayers] insert:0 layer:self.baseLayer];
}

- (NTTileDataSource*)createTileDataSource
{
    // Create global online vector tile data source, use Nutiteq test account
    NTTileDataSource *vectorTileDataSource = [[NTNutiteqOnlineTileDataSource alloc] initWithSource:@"nutiteq.osm"];
    // We don't use vectorTileDataSource directly (this would be also option),
    // but via caching to cache data locally non-persistently
    NTTileDataSource* cacheDataSource = [[NTCompressedCacheTileDataSource alloc] initWithDataSource:vectorTileDataSource];
    return cacheDataSource;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = false;
    self.title = strTitle;
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    // GLKViewController-specific, do on-demand rendering instead of constant redrawing.
    [self setPaused:YES];
    [self.view bringSubviewToFront:self.vwNavigation];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:64/255.0 green:160/255.0 blue:215/255.0 alpha:1.0];
    UIImage *buttonImage = [UIImage imageNamed:@"icBack"];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 20, 30, 44);
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = customBarItem;
}
- (void)back {
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)close{
    [self.navigationController popViewControllerAnimated:true];
}


- (IBAction)btnActionClose:(id)sender {
    [self.navigationController popViewControllerAnimated:true];

}
@end
