//
//  DividerAnnotation.swift
//  FlyZone
//
//  Created by Dhruv Singh on 19/01/17.
//  Copyright © 2017 toxsl. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class DividerAnnotation: NSObject , MKAnnotation {
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var info: String
    var nextIndex: String
    var prevIndex: String
    init(title: String, coordinate: CLLocationCoordinate2D, info: String,nextIndex: String,prevIndex: String) {
        self.title = title
        self.coordinate = coordinate
        self.info = info
        self.nextIndex = nextIndex
        self.prevIndex = prevIndex
       // print("Divider data \(title) ,lat:\(coordinate.latitude) ,longitude: \(coordinate.longitude) info: \(info) ,prevIndex: \(prevIndex) , nextindex: \(nextIndex)")
    }
}
