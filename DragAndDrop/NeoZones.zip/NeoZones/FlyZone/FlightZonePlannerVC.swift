//
//  FlightZonePlannerVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 28/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class FlightZonePlannerVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnDrawer(_ sender: AnyObject) {
        KAppDelegate.openDrawerAction()
    }
    
    @IBAction func btnTestFlight(_ sender: AnyObject) {
        let testVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "CreateOfflineZoneVC") as! CreateOfflineZoneVC
        self.navigationController?.pushViewController(testVc, animated: true)
        
    }
    @IBAction func btnOnlineMode(_ sender: AnyObject) {
        
        if (UserDefaults.standard.object(forKey: "auth_code")) != nil{
            let onlineVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "ZonePlannerOnlineVC") as! ZonePlannerOnlineVC
            self.navigationController?.pushViewController(onlineVc, animated: true)

        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please login to Enter Online Mode")
        
        }
        
            }
    @IBAction func btnOfflineMode(_ sender: AnyObject) {
        let offlineVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "ZonePlannerOfflineVC") as! ZonePlannerOfflineVC
        self.navigationController?.pushViewController(offlineVc, animated: true)
    }
    @IBAction func btnSettings(_ sender: AnyObject) {
        KAppDelegate.gotoSettings()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
