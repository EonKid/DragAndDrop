//
//  UpdateGroupVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 12/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

protocol updateGroupDelegate {
    func updateGroup()

}

var protocolObjectUpdateGroupName: updateGroupDelegate?


class UpdateGroupVC: UIViewController {

    //MARK:- VARIABLE
    var isGroupSecret = String()
    var modalObject = GroupList()
    
   //MARK:- IBOUTLET
    
    @IBOutlet weak var textFieldNameOfGroup: UITextField!
    
    @IBOutlet weak var btnGroupIsSecret: UIButton!
    //MARK:- ACTION
    
    
    
    @IBAction func btnPrssGroupIsSecret(_ sender: AnyObject) {
        if btnGroupIsSecret.isSelected == true {
            btnGroupIsSecret.isSelected = false
        
            isGroupSecret = "0"
        }else{
        
            btnGroupIsSecret.isSelected = true
            isGroupSecret = "1"
        }
        
    }
    
    @IBAction func btnPrssUpdate(_ sender: AnyObject) {
        self.view.endEditing(true)
        if textFieldNameOfGroup.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Group name")
        }else{
        
            let updateZoneUrl = "\(KServerUrl)"+"\(kUpdateGroupData)" + "\(modalObject.id)"
            let param = [
            
                "Group[name]" :  textFieldNameOfGroup.text!,
                "Group[type_id]": isGroupSecret
            ]
            updateGroup(updateZoneUrl, postParam: param as Dictionary<String, AnyObject>?)
            
        }
        
        
    }
    
    @IBAction func btnPrssCancel(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:- API HIT
    func updateGroup(_ url: String,postParam: Dictionary<String, AnyObject>? = nil)  {
        WebServiceRequest.postNormalData(postParam, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK")
            {
                proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["message"]!))
                self.dismiss(animated: true, completion: {
                     protocolObjectUpdateGroupName?.updateGroup()
                })
              
            }
            else
            {
                let errorMessage = responseDict["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                           }
            }, failure: { (error) in
                
                if error.localizedDescription.characters.count > 0{
                let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.updateGroup(url, postParam: postParam)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }

        })
        
        
    }

    
    //MARK:- VIEWCONTROLLER LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        isGroupSecret = "0"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
