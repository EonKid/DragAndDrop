//
//  CreateEventVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 04/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit


protocol setUpEventOnlineDelegate {
    func setUpEventOnline(_ dictInfo:NSDictionary)
}

protocol createEventDelegate {
    func createEvent()
}
var protocolCreateEvent: createEventDelegate?
var protocolObjectSetupEventOnline: setUpEventOnlineDelegate?

class CreateEventVC: UIViewController ,setChooseLocationPointDelegate{
    
    var isUpdateEvent = Bool()
    var isFromCreateOnline = Bool()
    
    //MARK:- VARIABLE
    var groupID = String()
    var datePicker1 = UIDatePicker()
    var datePicker2 = UIDatePicker()
    var dictLocationInfo = NSMutableDictionary()
    var modalEventListOnline = EventListOnline()
    
    //MARK:- IBOUTLET
    @IBOutlet weak var txtNameOfEvent: UITextField!
    
    @IBOutlet weak var txtStartDateOfEvent: UITextField!
    
    @IBOutlet weak var cnstEndEventTop: NSLayoutConstraint!
    @IBOutlet weak var txtEndDateOfEvent: UITextField!
    
    @IBOutlet weak var cnstHeightOfPlace: NSLayoutConstraint!
    @IBOutlet weak var txtFieldPassword: UITextField!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var txtFieldConfirmPassword: UITextField!
    
    @IBOutlet weak var btnCreateEvent: UIButton!
    @IBOutlet weak var lblLocation: UILabel!
    
    //MARK:- VIEWCONTROLLER
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isUpdateEvent == true {
            lblLocation.text = modalEventListOnline.location
            lblTitle.text = modalEventListOnline.name
            cnstHeightOfPlace.constant = 0
            cnstEndEventTop.constant = 0
            btnCreateEvent.setTitle("Update", for: UIControlState())
        }else{
            lblTitle.text = "Create Event"
         btnCreateEvent.setTitle("Create", for: UIControlState())
            cnstHeightOfPlace.constant = 40
             cnstEndEventTop.constant = 8
        }
        
        self.txtStartDateOfEvent.inputView = datePicker1
        self.txtEndDateOfEvent.inputView = datePicker2
        datePicker1.minimumDate = datePicker1.date
        datePicker2.minimumDate = datePicker1.date
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"//this your string date format
        txtStartDateOfEvent.text = dateFormatter.string(from: datePicker1.date)
        datePicker1.minimumDate = datePicker1.date
        txtEndDateOfEvent.text = dateFormatter.string(from: datePicker1.date)
        
        datePicker1.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged1(_:)), for: UIControlEvents.valueChanged)
        datePicker2.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged2(_:)), for: UIControlEvents.valueChanged)
    }
    //MARK:- UITEXTFIELD DELEGATE
    func textFieldDidBeginEditing(_ textField: UITextField){
        if txtStartDateOfEvent == textField {
            datePicker1.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged1(_:)), for: UIControlEvents.valueChanged)
        }
        if txtEndDateOfEvent == textField {
            datePicker2.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged2(_:)), for: UIControlEvents.valueChanged)
        }
        
    }
    
    func datePickerValueChanged1(_ sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"//this your string date format
        txtStartDateOfEvent.text = dateFormatter.string(from: sender.date)
        datePicker2.minimumDate = sender.date
        txtEndDateOfEvent.text = dateFormatter.string(from: sender.date)
        
        
    }
    func datePickerValueChanged2(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"//this your string date format
        txtEndDateOfEvent.text = dateFormatter.string(from: sender.date)
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        if txtStartDateOfEvent == textField {
            datePicker1.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged1(_:)), for: UIControlEvents.valueChanged)
        }
        if txtEndDateOfEvent == textField {
            datePicker2.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged2(_:)), for: UIControlEvents.valueChanged)
        }
        
        
    }
    
    
    //MARK:- ACTION
    
    @IBAction func btnPrssCancel(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnPrssLocation(_ sender: AnyObject) {
        let chooseLacationVC = storyboard?.instantiateViewController(withIdentifier: "ChooseLocationVC") as! ChooseLocationVC
        protocolChooseLocation = self
        chooseLacationVC.modalTransitionStyle = .crossDissolve
        chooseLacationVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(chooseLacationVC, animated: true, completion: nil)

    }
    
    
    @IBAction func btnPrssCreateEvent(_ sender: AnyObject) {
        
        self.view.endEditing(true)
        let strPassword = txtFieldPassword.text
        let strConfirmPassword = txtFieldConfirmPassword.text
        var lat = String()
        var long = String()
        if isUpdateEvent == false {
            if dictLocationInfo.object(forKey: "lat") != nil && dictLocationInfo.object(forKey: "longt") != nil {
                let  strLat = dictLocationInfo["lat"] as! String
                let strLong = dictLocationInfo["longt"] as! String
                lat  = strLat.trimmingCharacters(in: CharacterSet.whitespaces)
                long  = strLong.trimmingCharacters(in: CharacterSet.whitespaces)
            }
            if txtNameOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
                
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Event name")
            }
            else if  lblLocation.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0 || (lblLocation.text?.contains("Event Location"))!
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Event Location")
                
            }else if  txtStartDateOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Start Date of Event")
                
            }
            else if txtEndDateOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter End Date of Event")
            }else if txtFieldPassword.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).characters.count == 0{
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
            }else if txtFieldConfirmPassword.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).characters.count == 0{
                proxy.sharedProxy().displayStatusCodeAlert("Please confirm Password")
            }else if strPassword != strConfirmPassword {
                proxy.sharedProxy().displayStatusCodeAlert("Password do not match")
            }
            else
            {
                    let createEventUrl = "\(KServerUrl)"+"\(kAddEvent)" + groupID
                    let param = [
                        " Event[name]" : "\(txtNameOfEvent.text!)",
                        "Event[from_date]" : "\(txtStartDateOfEvent.text!)",
                        "Event[to_date]" : "\(txtEndDateOfEvent.text!)",
                        "Event[password]" : "\(txtFieldPassword.text!)",
                        "Event[confirm_password]" : "\(txtFieldConfirmPassword.text!)",
                        "Event[lat]" :lat,
                        "Event[longt]" : long,
                        "Event[location]" : dictLocationInfo["location_name"] as! String
                    ]
                    createEvent(createEventUrl, parameters: param as Dictionary<String, AnyObject>)
            }
        }else{
            let  strLat = modalEventListOnline.lat
            let strLong = modalEventListOnline.long
            lat  = strLat.trimmingCharacters(in: CharacterSet.whitespaces)
            long  = strLong.trimmingCharacters(in: CharacterSet.whitespaces)
            
            if txtNameOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Event name")
            }
            else if  txtStartDateOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Start Date of Event")
                
            }
            else if txtEndDateOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
            {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter End Date of Event")
            }else if txtFieldPassword.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).characters.count == 0{
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
            }else if txtFieldConfirmPassword.text!.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).characters.count == 0{
                proxy.sharedProxy().displayStatusCodeAlert("Please confirm Password")
            }else if strPassword != strConfirmPassword {
                proxy.sharedProxy().displayStatusCodeAlert("Password do not match")
            }
            else
            {
                let createEventUrl = "\(KServerUrl)"+"\(kUpdateEventData)" + "\(modalEventListOnline.id)"
                let param = [
                    " Event[name]" : "\(txtNameOfEvent.text!)",
                    "Event[from_date]" : "\(txtStartDateOfEvent.text!)",
                    "Event[to_date]" : "\(txtEndDateOfEvent.text!)",
                    "Event[password]" : "\(txtFieldPassword.text!)",
                    "Event[confirm_password]" : "\(txtFieldConfirmPassword.text!)",
                    "Event[lat]" :lat,
                    "Event[longt]" : long,
                    "Event[location]" : modalEventListOnline.location
                ]
                createEvent(createEventUrl, parameters: param as Dictionary<String, AnyObject>)
            }
        }
    
    }
    
    //MARK:- DELEGATE
    func getLocationFromMap(_ dictLocation:NSMutableDictionary){
    
        lblLocation.text = dictLocation["location_name"] as? String
        if dictLocation["location_name"] as! String != "" {
            lblLocation.textColor = UIColor.black
        }
        let txtHeight = lblLocation.text!.heightWithConstrainedWidth(lblLocation.frame.width, font: UIFont.systemFont(ofSize: 17))
        lblLocation.frame.size.height = txtHeight
        dictLocationInfo = dictLocation

    }
    
    //MARK:- API REQUEST
    
    func createEvent(_ url: String,parameters: Dictionary<String, AnyObject>) {
        WebServiceRequest.postNormalData(parameters, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK"){
                proxy.sharedProxy().displayStatusCodeAlert("Event created successfully.")
                
                self.dismiss(animated: true, completion: {
                    if self.isFromCreateOnline == true{
                      let dictEvent = responseDict["detail"] as! NSDictionary
                        protocolObjectSetupEventOnline!.setUpEventOnline(dictEvent)
                    }else{
                    protocolCreateEvent!.createEvent()
                       }
                    })
            }else{
                proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
            }
            
            }, failure: { (error) in
                let errorMessage = "\(error.localizedDescription)"
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                
                let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                    action in
                    self.createEvent(url, parameters: parameters)
                    }
                )
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                    }
                )
                alertController.addAction(retryAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
                
        })
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
