import Foundation

struct Preference {
    static var defaultInstance:Preference = Preference()
    
    var uri:String? = "rtmp://46.101.250.232/live"
    var streamName:String? = "live"
}
