//
//  EventListOnLineTVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class EventListOnLineTVC: UITableViewCell {
    
    
    @IBOutlet weak var lblEventName: UILabel!
    
    @IBOutlet weak var lblCreatedUserName: UILabel!
    @IBOutlet weak var lblEventLocation: UILabel!
    
    @IBOutlet weak var lblEventBetweenDates: UILabel!
    
    @IBOutlet weak var lblMaxMinimumHeight: UILabel!
    @IBOutlet weak var lblZoneName: UILabel!
    
    @IBOutlet weak var imgTempLoc: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
