//
//  GroupList.swift
//  FlyZone
//
//  Created by Dhruv Singh on 04/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class GroupList: NSObject {
    var create_time = String()
    var id = Int32()
    var name = String()
    var type = String()
    var type_id = Int32()
    var create_user_name = String()
    var create_user_id = Int32()
    var is_followed = Int32()
}
