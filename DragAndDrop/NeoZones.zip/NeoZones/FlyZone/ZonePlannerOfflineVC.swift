//
//  ZonePlannerOfflineVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 28/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class ZonePlannerOfflineVC: UIViewController ,setLocationDelegateOffline{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func setLocationOfEventOffline(_ strName:String){
 
        let  strZone = "[]"
        let arrUserEvents = DBManager.sharedDatabase().getMessage("SELECT * FROM OfflineTBL order by id ASC")
        if arrUserEvents.count > 0 {
            let modalObject = arrUserEvents.lastObject as! EventOffline
            let enteriesQuery = NSString(format: "INSERT INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",modalObject.id+1, strName,strZone)
            DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
             proxy.sharedProxy().displayStatusCodeAlert("Zone created successfully")
            let mainVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "CreateOfflineZoneVC") as! CreateOfflineZoneVC
            mainVc.zone_id = modalObject.id+1
            mainVc.zone_name = modalObject.name
            mainVc.zone_array = NSArray()
            self.navigationController?.pushViewController(mainVc, animated: true)
        }else{
            let enteriesQuery = NSString(format: "INSERT INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",1, strName,strZone)
            DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
            let mainVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "CreateOfflineZoneVC") as! CreateOfflineZoneVC
            mainVc.zone_id = 1
            mainVc.zone_name = strName
            mainVc.zone_array = NSArray()
            self.navigationController?.pushViewController(mainVc, animated: true)
            proxy.sharedProxy().displayStatusCodeAlert("Zone created successfully")
        }
        
    }
    
    @IBAction func btnBack(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnCreateField(_ sender: AnyObject) {
        let createZoneVC = storyboard?.instantiateViewController(withIdentifier: "CreateZonePopupVC") as! CreateZonePopupVC
        protocolObjectOfflineZone = self
        createZoneVC.modalTransitionStyle = .crossDissolve
        createZoneVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createZoneVC, animated: true, completion: nil)
        
    }
    
    
    @IBAction func btnLoadField(_ sender: AnyObject) {
        let loadFieldVc = storyboard?.instantiateViewController(withIdentifier: "LoadFieldVC") as! LoadFieldVC
        self.navigationController?.pushViewController(loadFieldVc, animated: true)
    }
    @IBAction func btnMainMenu(_ sender: AnyObject) {
        KAppDelegate.gotoMainMenu()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
