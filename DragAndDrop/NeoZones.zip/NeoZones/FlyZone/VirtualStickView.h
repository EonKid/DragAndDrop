//
//  VirtualStickView.h
//  FlyZone
//  Created by Dhruv Singh on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VirtualStickView : UIView
{
    IBOutlet UIImageView *stickViewBase;
    IBOutlet UIImageView *stickView;
    
    UIImage *imgStickNormal;
    UIImage *imgStickHold;
    
    CGPoint mCenter;
    
    NSTimer* mUpdateTimer;
    CGPoint mTouchPoint;
}

@end
