//
//  MyGroupDetailVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 01/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class MyGroupDetailVC: UIViewController,UITableViewDelegate, UITableViewDataSource ,setChooseLocationPointDelegate,createEventDelegate{
    
    //MARK: - VARIABLES
    var editName = UITextField()
    var modalObjectGroup = GroupList()
    var arrEventOfGroup = NSMutableArray()
   
  
    //MARK: - IBOUTLET
    @IBOutlet weak var tblVw: UITableView!
    @IBOutlet weak var lblNameEvents: UILabel!
   
    //MARK:- VIEWCONTROLLER LIFECYCLE
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        lblNameEvents.text = modalObjectGroup.name
        self.getEventList()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
   
    //MARK:- DELEGATE
    func getLocationFromMap(_ dictLocation:NSMutableDictionary){
        self.getEventList()
    }
    func createEvent(){
     self.getEventList()
        
    }
    
    //MARK:- API HIT
    func getEventList()  {
        
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kGetEventByGroup)" + "\(modalObjectGroup.id)"
            
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    self.arrEventOfGroup.removeAllObjects()
                     self.tblVw.reloadData()
                    let arrTemp = responseDict["list"] as! NSArray
                    for i in 0 ..< arrTemp.count{
                        var dict = NSDictionary()
                        dict = arrTemp[i] as! NSDictionary
                        let eventModal = EventListOnline()
                        eventModal.id = Int32(((dict["id"] as! NSNumber).intValue))
                        eventModal.group_id = Int32(((dict["group_id"] as! NSNumber).intValue))
                        eventModal.name = dict["name"] as! String
                        eventModal.group_name = dict["group_name"] as! String
                        eventModal.create_time = dict["create_time"] as! String
                        eventModal.from_date = dict["from_date"] as! String
                        eventModal.to_date = dict["to_date"] as! String
                        eventModal.create_user_id = Int32(((dict["create_user_id"] as! NSNumber).intValue))
                        eventModal.create_user_name = dict["create_user_name"] as! String
                        eventModal.zones = dict["zones"] as! NSArray
                        if responseDict.object(forKey: "location") != nil {
                            eventModal.location = responseDict.object(forKey: "location") as! String
                        }else{
                            eventModal.location = ""
                        }
                        eventModal.lat =  dict["lat"] as! String
                        eventModal.long = dict["longt"] as! String
                        
                        self.arrEventOfGroup.add(eventModal)
                    }
                    if self.arrEventOfGroup.count > 0{
                       // self.tblVw.reloadData()
                        self.tblVw.reloadSections([0], with: .fade)

                    }
                    
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
                
            }) { (error) in
                
                if error.localizedDescription.characters.count > 0{
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.getEventList()
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
                
               
            }
            
        }
    }

    func deleteEvents(_ url: String,postParam: Dictionary<String, AnyObject>? = nil) {
        WebServiceRequest.postNormalData(postParam, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK")
            {
                  proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["message"]!))
                self.getEventList()
            }
            else
            {
                let errorMessage = responseDict["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                    action in
                    self.deleteEvents(url, postParam: postParam)
                    }
                )
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                    }
                )
                alertController.addAction(retryAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
            }, failure: { (error) in
                if error.localizedDescription.characters.count > 0{
                let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.deleteEvents(url, postParam: postParam)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
        })
    }
    
   //MARK:- ACTION
    
    @IBAction func btnPrssAddEvents(_ sender: AnyObject) {
        let createGroupVC = storyboard?.instantiateViewController(withIdentifier: "CreateEventVC") as! CreateEventVC
        protocolCreateEvent = self
        createGroupVC.groupID = "\(modalObjectGroup.id)"
        createGroupVC.modalTransitionStyle = .crossDissolve
        createGroupVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createGroupVC, animated: true, completion: nil)

        
    }
    @IBAction func btnBack(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    //MARK:- TableView Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrEventOfGroup.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 88
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVw.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyGroupTVC
        let modalObject = arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
        cell.lblName.text = modalObject.name
        return cell
        
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        if arrEventOfGroup.count > 0 {
            let mainVc = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "CreateZoneOnlineVC") as! CreateZoneOnlineVC
             let modalObject = self.arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
            mainVc.modalEventListOnline = modalObject
            mainVc.isFromOnlineGroup = true
            self.navigationController?.pushViewController(mainVc, animated: true)
        }
        
    }
  
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        var modal = EventListOnline()
        modal = self.arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
        if modal.create_user_id != Int32(userId) {
            proxy.sharedProxy().displayStatusCodeAlert("You cannot delete other user Event")
            return [UITableViewRowAction()]
        }else{
            let delete = UITableViewRowAction(style: .destructive, title: "                    ") { (action, indexPath) in
                let alertController = UIAlertController(title: "", message: "Are you sure to delete Event?", preferredStyle: .alert)
                let deleteAction = UIAlertAction(title: "Delete", style: .default, handler: {
                    action in
                    let modalObject = self.arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
                    let url = "\(KServerUrl)"+"\(kDeleteEvent)" + "\(modalObject.id)"
                    self.deleteEvents(url, postParam: nil)
                    }
                )
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                    }
                )
                alertController.addAction(deleteAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
            let edit = UITableViewRowAction(style: .normal, title: "                     ") { (action, indexPath) in
                if self.arrEventOfGroup.count > 0{
                    let modalObject = self.arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
                    let createEventVC = self.storyboard?.instantiateViewController(withIdentifier: "CreateEventVC") as! CreateEventVC
                    protocolCreateEvent = self
                    createEventVC.isUpdateEvent = true
                    createEventVC.modalEventListOnline = modalObject
                    createEventVC.modalTransitionStyle = .crossDissolve
                    createEventVC.modalPresentationStyle = .overCurrentContext
                    self.providesPresentationContextTransitionStyle = true
                    self.present(createEventVC, animated: true, completion: nil)
                }
            }
            delete.backgroundColor = UIColor(patternImage: UIImage(named:"group_del_slider")!)
            edit.backgroundColor = UIColor(patternImage: UIImage(named:"group_edit_slider")!)
            return [delete, edit]
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
