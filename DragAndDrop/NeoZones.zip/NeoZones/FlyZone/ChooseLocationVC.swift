//
//  ChooseLocationVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 08/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import MapKit
import Alamofire

protocol setChooseLocationPointDelegate {
    func getLocationFromMap(_ dictLocation:NSMutableDictionary)
}

var protocolChooseLocation: setChooseLocationPointDelegate?


class ChooseLocationVC: UIViewController,MKMapViewDelegate, UIGestureRecognizerDelegate {
    
    //MARK:- VARIABLE
     var tapGesture =  UITapGestureRecognizer()
     let dictZoneInfo = NSMutableDictionary()
    var isChooseLocation = Bool()
     var hitURL = String()
    //MARK:- IBOUTLET
    @IBOutlet weak var vwEditDelete: UIView!
    @IBOutlet weak var vwDoneDelete: UIView!

    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var btnEditLocation: UIButton!
    
    //MARK:- VIEWCONTROLLER LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if #available(iOS 9.0, *) {
            mapView.mapType = .hybridFlyover
        } else {
           mapView.mapType = .hybrid
        }
        isChooseLocation = true
       vwDoneDelete.isHidden = true
        self.setMapCurrent()
    }
    
    func setMapCurrent() {
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
            let span = MKCoordinateSpanMake(0.02, 0.02)
            let region = MKCoordinateRegion(center: userLoc, span: span)
            mapView.setRegion(region, animated: true)
            mapView.showsUserLocation = true
        }
    }

    
   //MARK:- GESTURERECOGNIZER AND MAPKIT DELEGATE
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let imgView = UIImageView()
        imgView.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        imgView.image =  UIImage(named: "location")
        if (annotation.isKind(of: MKUserLocation.self)) {
            return nil
        }
        let reuseId = "createZoneArea"
        if (annotation.isKind(of: AnnotationModal.self)) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            altitudeVw.backgroundColor = UIColor.clear
            altitudeVw.addSubview(imgView)
            let lblTitle = UILabel(frame: CGRect(x: 10, y: 2, width: 30, height: 30))
            lblTitle.font = lblTitle.font.withSize(15)
            lblTitle.text = ""
            lblTitle.textAlignment = NSTextAlignment.center
            lblTitle.textColor = UIColor.white
            altitudeVw.addSubview(lblTitle)
            anView.addSubview(altitudeVw)
            anView.canShowCallout = false
            anView.isEnabled = true
            anView.isUserInteractionEnabled = true
            anView.rightCalloutAccessoryView = nil
            anView.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
            anView.centerOffset = CGPoint(x: 0,y: -25)
            return anView
        }
        return nil
    }

   
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool{
        return true
    }

    //MARK:- WEBSERVICE HANDLING
    func getCurrentPlaceInfo() {
        if dictZoneInfo.object(forKey: "lat") != nil {
            let lat =  dictZoneInfo.object(forKey: "lat") as! String
            let strLat = lat.trimmingCharacters(in: CharacterSet.whitespaces)
            let long = dictZoneInfo.object(forKey: "longt") as! String
              let strLong = long.trimmingCharacters(in: CharacterSet.whitespaces)
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = Double(strLat)!
            userLoc.longitude = Double(strLong)!
            self.getPlaceName(userLoc)
        }
    }

    //MARK:- GET CURRENT ADDRESS
    func getPlaceName(_ userLoc: CLLocationCoordinate2D) {
        let routeUrl = "\(googleBaseURL)geocode/json?latlng=\(userLoc.latitude),\(userLoc.longitude)"+apiKey
        hitURL = "getPlaceName"
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
             request(routeUrl, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:nil)
                .responseJSON {response in
                    do {
                        KAppDelegate.hideActivityIndicator()
                        if(response.response?.statusCode == 200) {
                            if let JSON = response.result.value as? NSDictionary{
                                 self.serviceResponseSetAddress(JSON  .mutableCopy() as! NSMutableDictionary)
                                
                            }else{
                                
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }

                          //  print(JSONDIC)
                           
                        } else {
                            proxy.sharedProxy().stautsHandler(routeUrl, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                        }
                    }
                    catch let error as NSError {
                        KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().displayStatusCodeAlert(error.description)
                    }
            }
        }
        else {
            proxy.sharedProxy().openSettingApp()
        }
        
    }
    
    func serviceResponseSetAddress(_ JSON: NSMutableDictionary)  {
        print(JSON)
        if (JSON["status"]! as AnyObject).isEqual("OK"){
            let addressDic = (JSON["results"] as! NSArray).firstObject as! NSDictionary
           // print(JSON)
            let LocName = addressDic["formatted_address"]! as! String
            dictZoneInfo.setObject(LocName, forKey: "location_name" as NSCopying)
            self.dismiss(animated: true, completion: nil)
            protocolChooseLocation?.getLocationFromMap(dictZoneInfo)
        }else{
           proxy.sharedProxy().displayStatusCodeAlert("Error,Cannot get address")
        }
    }
    
    //MARK:- ACTION
    
    func recognizeTapGesture(_ gestureReconizer: UITapGestureRecognizer) {
        if self.mapView.annotations.count == 1 {
            if isChooseLocation == true {
                let touchLocation = gestureReconizer.location(in: mapView)
                let locationCoordinate = mapView.convert(touchLocation,toCoordinateFrom: mapView)
               // print("Tapped at lat: \(locationCoordinate.latitude) long: \(locationCoordinate.longitude)")
                let annotation = AnnotationModal(title: " ", coordinate: CLLocationCoordinate2D(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude), info: "Added location",index: "",distnaceFromHomeLocation: "",isShowDistance: false)
                mapView.addAnnotation(annotation)
                dictZoneInfo.setObject("\(locationCoordinate.latitude)", forKey: "lat" as NSCopying)
                dictZoneInfo.setObject(" \(locationCoordinate.longitude)", forKey: "longt" as NSCopying)
                vwDoneDelete.isHidden = false
            }

        }else{
                vwDoneDelete.isHidden = true
        }
    }
    
    @IBAction func btnPrssDone(_ sender: AnyObject) {
        vwDoneDelete.isHidden = true
        self.getCurrentPlaceInfo()
    }
   
    
    @IBAction func btnPrssDelete(_ sender: AnyObject) {
         vwDoneDelete.isHidden = true
        dictZoneInfo.removeAllObjects()
        isChooseLocation = true
        let annotationsToRemove = mapView.annotations.filter { $0 !== mapView.userLocation }
        mapView.removeAnnotations( annotationsToRemove)
        
    }
    
    @IBAction func btnPrssCancel(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnPrssChooseLocation(_ sender: AnyObject) {
        
        vwDoneDelete.isHidden = true
        isChooseLocation = true
        vwDoneDelete.isHidden = true
        //For TapGesture Recognization
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(ChooseLocationVC.recognizeTapGesture(_:)))
        tapGesture.delegate = self
        mapView.addGestureRecognizer(tapGesture)
    }
    
    
    @IBAction func btnPrssEditLocation(_ sender: AnyObject) {
        if btnEditLocation.isSelected == true {
            btnEditLocation.isSelected = false
            vwDoneDelete.isHidden = true
        }else{
        
            btnEditLocation.isSelected = true
            vwDoneDelete.isHidden = false
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
