//
//  EventOffline.swift
//  FlyZone
//
//  Created by Dhruv Singh on 17/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//


import UIKit

class EventOffline: NSObject {
    var id = Int32()
    var name = String()
    var zones = NSArray()
}
