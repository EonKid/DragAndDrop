//
//  MyGroupVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 01/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class MyGroupVC: UIViewController, UITableViewDataSource, UITableViewDelegate ,directConnectionDelegate,updateGroupDelegate{
    //MARK:- VARIABLE
    var editName = UITextField()
     var arrMyGroups = NSMutableArray()
    
    //MARK:- IBOUTLET
    @IBOutlet weak var tblVw: UITableView!
    
    @IBAction func btnPrssDrawer(_ sender: AnyObject) {
        self.navigationController?.isNavigationBarHidden = true
        KAppDelegate.openDrawerAction()
    }
    
    //MARK:- API HIT
    func getGroupList()  {
        
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kMyGroups)" + "?auth_code=\(authCode)"
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    let arrTemp = responseDict["list"] as! NSArray
                    self.arrMyGroups.removeAllObjects()
                    for i in 0 ..< arrTemp.count{
                        var dict = NSDictionary()
                        dict = arrTemp[i] as! NSDictionary
                        let groupModal = GroupList()
                        groupModal.id = Int32(((dict["id"] as! NSNumber).intValue))
                        groupModal.type_id = Int32(((dict["type_id"] as! NSNumber).intValue))
                        groupModal.name = dict["name"] as! String
                        groupModal.type = dict["type"] as! String
                        groupModal.create_time = dict["create_time"] as! String
                        groupModal.create_user_name = dict["create_user_name"] as! String
                        groupModal.create_user_id = Int32(((dict["create_user_id"] as! NSNumber).intValue))
                        groupModal.is_followed = Int32((dict["is_followed"] as! NSString) as String)!
                        self.arrMyGroups.add(groupModal)
                    }
                    if self.arrMyGroups.count > 0{
                     //   self.tblVw.reloadData()
                        self.tblVw.reloadSections([0], with: .fade)
                    }
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
            }) { (error) in
                
                if error.localizedDescription.characters.count > 0{
                
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.getGroupList()
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }

    func deleteGroup(_ url: String,postParam: Dictionary<String, AnyObject>? = nil)  {
        WebServiceRequest.postNormalData(postParam, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK")
            {
                 proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["message"]!))
                self.getGroupList()
            }
            else
            {
                let errorMessage = responseDict["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                
            }
            }, failure: { (error) in
                if error.localizedDescription.characters.count > 0{
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.deleteGroup(url, postParam: postParam)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            })
    }
    
    
    
    //MARK:- VIEWCONTROLLER LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
         self.getGroupList()
    }
    
    //MARK:- DELEGATE
    func directConnectionDone(_ dictEventInfo:NSDictionary)
    {
        let eventModal = EventListOnline()
        eventModal.id = Int32(((dictEventInfo["id"] as! NSNumber).intValue))
        eventModal.group_id = Int32(((dictEventInfo["group_id"] as! NSNumber).intValue))
        eventModal.name = dictEventInfo["name"] as! String
        eventModal.group_name = dictEventInfo["group_name"] as! String
        eventModal.create_time = dictEventInfo["create_time"] as! String
        eventModal.from_date = dictEventInfo["from_date"] as! String
        eventModal.to_date = dictEventInfo["to_date"] as! String
        eventModal.create_user_id = Int32(((dictEventInfo["create_user_id"] as! NSNumber).intValue))
        eventModal.create_user_name = dictEventInfo["create_user_name"] as! String
        eventModal.zones = dictEventInfo["zones"] as! NSArray
        let mainVc = self.storyboard!.instantiateViewController(withIdentifier: "CreateZoneOnlineVC") as! CreateZoneOnlineVC
        mainVc.modalEventListOnline = eventModal
        self.navigationController?.pushViewController(mainVc, animated: true)
    }

    
    //MARK:- ACTION
    @IBAction func btnDirctConection(_ sender: AnyObject) {
        if (UserDefaults.standard.object(forKey: "auth_code")) != nil{
        let dirctVc = storyboard?.instantiateViewController(withIdentifier: "DirectConnectionVC") as! DirectConnectionVC
        protocolDirectConnection = self
        dirctVc.modalTransitionStyle = .crossDissolve
        dirctVc.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(dirctVc, animated: true, completion: nil)
        }else{
        
            proxy.sharedProxy().displayStatusCodeAlert("Please Login to continue for Direct Connection")
        }
    }
    @IBAction func btnMainMenu(_ sender: AnyObject) {
        KAppDelegate.gotoMainMenu()
    }
    
        
    //MARK:- DELEGATE
    func updateGroup(){
        self.getGroupList()
    }
    
    //MARK:- TableView Methods
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 88
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMyGroups.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVw.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyGroupTVC
        var modalObject  = GroupList()
        modalObject = arrMyGroups[(indexPath as NSIndexPath).row] as! GroupList
        cell.lblName.text = modalObject.name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if arrMyGroups.count > 0 {
            var modalObject = GroupList()
            modalObject = arrMyGroups[(indexPath as NSIndexPath).row] as! GroupList
            let detailVC = KAppDelegate.StoryBoard().instantiateViewController(withIdentifier: "MyGroupDetailVC") as! MyGroupDetailVC
            detailVC.modalObjectGroup = modalObject
            self.navigationController?.pushViewController(detailVC, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
         let userId  = UserDefaults.standard.object(forKey: "id") as! Int
            var modal = GroupList()
            modal = self.arrMyGroups[(indexPath as NSIndexPath).row] as! GroupList
            if modal.create_user_id != Int32(userId) {
                proxy.sharedProxy().displayStatusCodeAlert("You cannot delete other user Group")
                return [UITableViewRowAction()]
            }else{
            let delete = UITableViewRowAction(style: .destructive, title: "                    ") { (action, indexPath) in
                    let alertController = UIAlertController(title: "", message: "Are you sure to delete Group?", preferredStyle: .alert)
                    let deleteAction = UIAlertAction(title: "Delete", style: .default, handler: {
                        action in
                        if self.arrMyGroups.count > 0 {
                            var modalObject = GroupList()
                            modalObject = self.arrMyGroups[(indexPath as NSIndexPath).row] as! GroupList
                            let url = "\(KServerUrl)"+"\(kDeleteGroup)" + "\(modalObject.id)"
                            self.deleteGroup(url, postParam: nil)
                        }
                        }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                        }
                    )
                    alertController.addAction(deleteAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
                
                
                let edit = UITableViewRowAction(style: .normal, title: "                     ") { (action, indexPath) in
                    if self.arrMyGroups.count > 0 {
                        var modalObject = GroupList()
                        modalObject = self.arrMyGroups[(indexPath as NSIndexPath).row] as! GroupList
                        let updateGroupVC = self.storyboard?.instantiateViewController(withIdentifier: "UpdateGroupVC") as! UpdateGroupVC
                        protocolObjectUpdateGroupName = self
                        updateGroupVC.modalObject = modalObject
                        updateGroupVC.modalTransitionStyle = .crossDissolve
                        updateGroupVC.modalPresentationStyle = .overCurrentContext
                        self.providesPresentationContextTransitionStyle = true
                        self.present(updateGroupVC, animated: true, completion: nil)            }
                }
                delete.backgroundColor = UIColor(patternImage: UIImage(named:"group_del_slider")!)
                edit.backgroundColor = UIColor(patternImage: UIImage(named:"group_edit_slider")!)
                return [delete, edit]
        }
    }
    
    /*
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
