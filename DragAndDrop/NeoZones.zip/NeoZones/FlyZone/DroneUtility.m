//
//  DroneUtility.m
//  FlyZone
//  Created by Dhruv Singh on 25/10/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

#import "DroneUtility.h"
#import <DJISDK/DJISDK.h>
@implementation DroneUtility
+(DJIBaseProduct*) fetchProduct {
    return [DJISDKManager product];
}

+(DJIAircraft*) fetchAircraft {
    if (![DJISDKManager product]) {
        return nil;
    }
    if ([[DJISDKManager product] isKindOfClass:[DJIAircraft class]]) {
        return ((DJIAircraft*)[DJISDKManager product]);
    }
    return nil;
}



+(DJIFlightController*) fetchFlightController {
    if (![DJISDKManager product]) {
        return nil;
    }
    
    if ([[DJISDKManager product] isKindOfClass:[DJIAircraft class]]) {
        
        return ((DJIAircraft*)[DJISDKManager product]).flightController;
    }
    
    return nil;
}




@end
