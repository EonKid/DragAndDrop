//
//  EventListOnline.swift
//  FlyZone
//
//  Created by Dhruv Singh on 04/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import Foundation
class EventListOnline: NSObject {
    var create_time = String()
    var id = Int32()
    var group_name = String()
    var group_id = Int32()
    var name  = String()
    var from_date = String()
    var to_date = String()
    var create_user_id = Int32()
    var create_user_name = String()
    var location = String()
    var lat = String()
    var long = String()
    var zones = NSArray()
}
