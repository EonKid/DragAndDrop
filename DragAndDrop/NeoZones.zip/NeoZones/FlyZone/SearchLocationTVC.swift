//
//  SearchLocationTVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 06/09/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class SearchLocationTVC: UITableViewCell {

    @IBOutlet weak var lblPlaces: UILabel!
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
