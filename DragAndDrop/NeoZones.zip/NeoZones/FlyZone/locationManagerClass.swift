//
//  proxy.swift
//  FlyZone
//  Created by Dhruv Singh on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.

import UIKit
import CoreMotion
import CoreLocation
import Alamofire
var locationShareInstance:locationManagerClass = locationManagerClass()

class locationManagerClass: NSObject, CLLocationManagerDelegate, WebServiceDelegate , UIAlertViewDelegate
{
//    // MARK: - Class Variables


    var locationManager = CLLocationManager()
    
    
    class func sharedLocationManager() -> locationManagerClass
    {
        locationShareInstance = locationManagerClass()
        return locationShareInstance
    }
    
    
    func startStandardUpdates() {
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.activityType = .automotiveNavigation
        locationManager.distanceFilter = 10
        // meters
        locationManager.pausesLocationUpdatesAutomatically = false
        
        if (Bundle.main.object(forInfoDictionaryKey: "NSLocationWhenInUseUsageDescription") != nil) {
            locationManager.requestWhenInUseAuthorization()
        }
        
        locationManager.startUpdatingLocation()
       
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // If it's a relatively recent event, turn off updates to save power.
        let location: CLLocation = locations.last!
        let strLocation = "\(location.coordinate.latitude)"
        if strLocation == "" {
            
        }else{
        UserDefaults.standard.set("\(location.coordinate.latitude)", forKey: "lat")
        UserDefaults.standard.set("\(location.coordinate.longitude)", forKey: "long")
        UserDefaults.standard.synchronize()
            debugPrint("Spedd: \(location.speed)")
//        self.updateLocationToServer()
            self.stopStandardUpdate()
        }
    }
    
    func stopStandardUpdate(){
        locationManager.stopUpdatingLocation()
    }
    
    
    //MARK:- WHEN DENIED
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == CLAuthorizationStatus.denied {
            
            NSLog("DENIAL")
            
            UserDefaults.standard.set("\(0.0)", forKey: "lat")
            UserDefaults.standard.set("\(0.0)", forKey: "long")
            
            self.generateAlertToNotifyUser()
        }
    }
    
    func generateAlertToNotifyUser() {
        
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.notDetermined{
            
            var title: String
            title = ""
            let message: String = "Location Services are not able to determine your location"
            
            let alertView: UIAlertView = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: "Cancel", otherButtonTitles: "Settings")
            alertView.show()
        }
        
        
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.denied{
            
            var title: String
            
            title = "Location services are off"
            let message: String = "To post spots or find near by spots, you must turn on Location Services from Settings"
            
            let alertView: UIAlertView = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: "Cancel", otherButtonTitles: "Settings")
            alertView.show()
        }
        
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.notDetermined
        {
            startStandardUpdates()
        }
    }
    
    
    
    
    
//    func updateLocationToServer() {
//        
//        let authCode: (AnyObject?) = (NSUserDefaults.standardUserDefaults().valueForKey("auth_code"))
//        if authCode != nil
//        {
//            
//            var userLoc = CLLocationCoordinate2D()
//            if NSUserDefaults.standardUserDefaults().objectForKey("lat") != nil {
//                let lat =  NSUserDefaults.standardUserDefaults().objectForKey("lat") as! String
//                let long = NSUserDefaults.standardUserDefaults().objectForKey("long") as! String
//                userLoc.latitude = CDouble(lat)!
//                userLoc.longitude = CDouble(long)!
//            }
//            
//            let latitute =  userLoc.latitude
//            let longitude = userLoc.longitude
//            
//            print(latitute)
//            print(longitude)
//            let LoginUrl = "\(KServerUrl)"+"\(updateLoction)" + "\(objProfile.id)"
//            let userAgent = "\(KMode)"+"/"+"\(KAppName)"
//            let param = [
//                               
//                "User[lat]":"\(latitute)",
//                "User[long]":"\(longitude)"
//                
//            ]
//            
//            
//            if Reachability.isConnectedToNetwork() == true {
//                //  kAppDelegate.showActivityIndicator()
//                Alamofire.request(.POST, LoginUrl, parameters: param, headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
//                    .responseJSON { response in
//                        do {
//                            //                            kAppDelegate.hideActivityIndicator()
//                            
//                            print(response.response)
//                            if(response.response?.statusCode == 200)
//                            {
//                                var JSONDIC = NSMutableDictionary()
//                                JSONDIC = try  NSJSONSerialization.JSONObjectWithData(response.data!, options: []) as! NSMutableDictionary
//                                print("JSONDIC RESPONSE:" , JSONDIC)
//                                self.serviceResponse(JSONDIC)
//                            }else {
//                                delegateObject = self
//                                proxy.sharedProxy().stautsHandler(LoginUrl, parameter: param, response: response.response, data:response.data, error: response.result.error)
//                            }
//                        } catch let error as NSError {
//                            KAppDelegate.hideActivityIndicator()
//                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
//                        }
//                }
//            }else {
//                proxy.sharedProxy().openSettingApp()
//            }
//        }
//    }
    
    //MARK:- Serviece Response
    func serviceResponse(_ JSON:NSMutableDictionary) {
        if (JSON["action"]! as AnyObject).isEqual("setLocation") && (JSON["controller"]! as AnyObject).isEqual("driver") {
            if (JSON["status"]! as AnyObject).isEqual("OK") {
                //       proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                
            } else
            {
                //        let errorMessage = JSON["error"] as! String
                //                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
        }
    }
    
    func retryMethod(_ paramsDic: Dictionary<String, AnyObject>, withServiceUrl: NSString, error: NSError?)
    {
        let retryURL = "\(withServiceUrl)"
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
            if(paramsDic.count>0)
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .post, parameters: paramsDic, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                if let JSON = response.result.value as? NSDictionary{
                                    self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                                }
                            }
                            else
                            {
                                delegateObject = self
                                proxy.sharedProxy().stautsHandler(retryURL, parameter:paramsDic, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            NSLog("EXCEPTION : %@", error.description)
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
            else
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                if let JSON = response.result.value as? NSDictionary{
                                    self.serviceResponse(JSON .mutableCopy() as! NSMutableDictionary)
                                }
                            }
                            else
                            {
                                delegateObject = self
                                proxy.sharedProxy().stautsHandler(retryURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                        catch let error as NSError
                        {
                            
                            NSLog("EXCEPTION : %@", error.description)
                            
                            proxy.sharedProxy().displayStatusCodeAlert(error.description)
                        }
                }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
        if buttonIndex == 1 {
            // Send the user to the Settings for this app
            let settingsURL: URL = URL(string: UIApplicationOpenSettingsURLString)!
            UIApplication.shared.openURL(settingsURL)
        }
        
    }
    
    
}

