//  CreateZoneOnlineVC.swift
//  FlyZone
//  Created by Dhruv Narayan Singh on 04/08/16.
//  Copyright © 2016 toxsl. All rights reserved.

import UIKit
import MapKit
import Alamofire
import CoreLocation
import GLKit
import DJISDK
import UserNotifications
import PubNub
import VideoPreviewer


fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}



class CreateZoneOnlineVC: UIViewController,MKMapViewDelegate, UIGestureRecognizerDelegate,CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource,UISearchControllerDelegate,UISearchBarDelegate,setLocationDelegateOffline,DJISDKManagerDelegate,UINavigationControllerDelegate,DJIFlightControllerDelegate,DJISimulatorDelegate,DJIRemoteControllerDelegate,DJIMissionManagerDelegate, PNObjectEventListener, DJICameraDelegate,DJIBatteryDelegate{
  
    //MARK: - Streaming
    
    //MARK:-  IBOutlet
    
    @IBOutlet weak var imgDroneConnected: UIImageView!
    @IBOutlet weak var lblDroneName: UILabel!
    
    @IBOutlet weak var lblFlyingMode: UILabel!
    
    @IBOutlet weak var imgRemoteController: UIImageView!
    
    @IBOutlet weak var imgRCSignalStrength: UIImageView!
    
    @IBOutlet weak var imgDroneCamera: UIImageView!
    
    @IBOutlet weak var imgCameraSignal: UIImageView!
    
    
    @IBOutlet weak var imgDroneBattery: UIImageView!
    
    @IBOutlet weak var lblDroneBatteryStatus: UILabel!
    
    @IBOutlet weak var imgiPadBattery: UIImageView!
    
    @IBOutlet weak var lbliPadBatteryStatus: UILabel!
    
    @IBOutlet weak var lblSateliteCount: UILabel!
    
    //Grid Mission
    
    @IBOutlet weak var lblRotateGridAtAngle: UILabel!
    
    
    @IBOutlet weak var sliderRotateGrid: UISlider!
    @IBOutlet weak var lblFlightTimeEstimate: UILabel!
    
    @IBOutlet weak var lblWayPointQty: UILabel!
    
    @IBOutlet weak var lblSpeedWhileGridMission: UILabel!
    
    @IBOutlet weak var lblAltitudeOfEachWaypoint: UILabel!
    
    @IBOutlet weak var lblGridGapInMeter: UILabel!
    
    @IBOutlet weak var sliderSpeedWhileWaypointMission: UISlider!
    
    @IBOutlet weak var sliderAltitudeWhileWaypointMission: UISlider!
    
    @IBOutlet weak var sliderGridGap: UISlider!
    
    @IBOutlet var viewWaypointUpload: WaypointUploadingAlertView!
    
    @IBOutlet weak var cnstGridMissionSetup: NSLayoutConstraint!
     var arrLocations = [CLLocation]()
    var arrLocationsReal = [CLLocation]()
    @IBOutlet weak var btnStartGridMission: UIButton!
    //MARK: - VARIABLE
    // Stores reference on PubNub client to make sure what it won't be released.
    var client: PubNub!
    var userId = Int()
    var segmentLines = NSMutableArray()
    var arrPubNubChannels = [String]()
    var dictMultipleTrakerList = NSMutableDictionary()
    var dictMultipleDroneList = NSMutableDictionary()
    var dictMultipleTrackerSelectionState = NSMutableDictionary()
    //Flight control
    
    var dictCenterCoordinatesPolygons = NSMutableDictionary()
    var product = DJIBaseProduct()
    var mXVelocity = Float()
    var mYVelocity = Float()
    var mYaw = Float()
    var mThrottle = Float()
    var droneLocationCoordinate = CLLocationCoordinate2D()
    var aircraftAnnotation:DroneAnnotation!
    var trackerAnnotation:UserAnnotation!
    var homeLocationOfUser = CLLocationCoordinate2D()
    var missionManager = DJIMissionManager()
    var waypointMission = DJIWaypointMission()
    var counter_max_radius = 0
    var takeOffCoordinates = CLLocationCoordinate2D()
    var isTypeOffLandingHomePoint  = Bool()
    var distanceXPos = Float()
    var arrMinMaxHeightDictionary = NSMutableArray()
    var backgroundTask: UIBackgroundTaskIdentifier = UIBackgroundTaskInvalid
    var updateTimer: Timer?
    var trackerId = String()
    var executionTime = TimeInterval()
    var radianYaw = Double()
    var trackerLocationCoordinates = CLLocationCoordinate2D()
    var heading_tracker = Float()
    var isFollowMeMissionStarted = Bool()
    var followTrackerStep : DJIFollowMeStep?
    var state_id = Int()
    var min_height = Float()
    var current_altitude = Float()
    var current_vertical_speed = Float()
    var distanceInMeters = Float()
    var current_positionX = Float()
    var current_positionY = Float()
    var current_PitchY = Float()
    var current_RollX = Float()
    var followMeMission: DJIFollowMeMission? = nil
    var followMeStarted: Bool = false
    var isWaypointMissionStarted: Bool = false
    var isWayPointFromWebStarted = "0"
    var waypointTargetCoordinate = CLLocationCoordinate2D()
    var isWayPointMissionOn: Bool = false
    var adapter : VideoPreviewerSDKAdapter!
    @IBOutlet weak var btnfpvFullScreenOverlay: UIButton!
    @IBOutlet weak var btnFullScreen: UIButton!
    @IBOutlet weak var fpvFullScreen: UIView!
    @IBOutlet weak var fpvView: UIView!
    @IBOutlet weak var fpvTempView: UIView!
    @IBOutlet weak var cnstWaypointMissionViewTrailingSpace: NSLayoutConstraint!
    //Simulator control
    @IBOutlet weak var vwSimulatorControl: UIView!
    @IBOutlet weak var btnEnterVSMode: UIView!
    @IBOutlet weak var btnExitVSMode: UIButton!
    @IBOutlet weak var btnStartSimulator: UIButton!
    @IBOutlet weak var btnTakeOff: UIButton!
       @IBOutlet weak var btnLandDrone: UIButton!
    @IBOutlet weak var imgTagRight: UIImageView!
    @IBOutlet weak var lblTransmissionTime: UILabel!
    @IBOutlet weak var imgTagLeft: UIImageView!
    @IBOutlet weak var btnStartTracking: UIButton!
    @IBOutlet weak var cnstfpvFullScreen: NSLayoutConstraint!
    
    var selectedAnnotationVw = MKAnnotationView()
    var isFromOnlineGroup = Bool()
    var modalEventListOnline = EventListOnline()
    var firstModal = ZoneCreateModal()
    var locationArray = NSMutableArray()
    var hitURL = String()
    var isUpdate = Bool()
    var isDragToPoint = Bool()
    var arrEventsList = NSMutableArray()
    var str_Min_Altitude = String()
    var str_Max_Altitude = String()
    var dictUpdateBools = NSMutableDictionary()
    var zoneCreateModal = ZoneCreateModal()
    let MERCATOR_OFFSET = 268435456.0
    let MERCATOR_RADIUS = 85445659.44705395
    let DEGREES = 180.0
    var isDragPin  = Bool()
    var isFromOfflineEventList = Bool()
    var isLandingPointsToBeMarked = Bool()
    var line = CAShapeLayer()
    var isLandingPointsOutside = Bool()
    var landingCircle = MKCircle()
    var isShowDistance = Bool()
    
    //Multiple zones creation
    var isPlacePolygon = Bool()
    var isAltitude = Bool()
    var isDrawPolygon  = Bool()
    var isDeletePolygon = Bool()
    var selectedIndexPath = IndexPath()
    var dictPolygon = NSMutableDictionary()
    var  vw = UIView()
    var linePath = UIBezierPath()
    var strZoneIdUpdate = String()
    var isOverLapped = Bool()
    var gridView = UIView()
    //Main array
    var dictMainEventList = NSMutableDictionary()
    var strCurrentEventId = String()
    
    //Delete landing points 
    var isLandingPointsToBeDeleted = Bool()
    var isPinPointsToBeDeleted = Bool()
    var isSelfIntersecting = Bool()
    //MARK:- IBOUTLET
    //Flight control outlets
    var imgStartView = UIImageView()
    var imgLastView = UIImageView()
    
    //Constraints
    
    //helipad pops
    @IBOutlet weak var cnstHelipadPops: NSLayoutConstraint!
    @IBOutlet weak var lblSetMinAndMaxSpeed: UILabel!
    
    //Stick left
    @IBOutlet weak var cnstYPositiveStickLeft: NSLayoutConstraint!
    @IBOutlet weak var cnstYNegativeStickLeft: NSLayoutConstraint!
    @IBOutlet weak var cnstXNegativeStickLeft: NSLayoutConstraint!
    @IBOutlet weak var cnstXPositiveStickLeft: NSLayoutConstraint!
    //Stick right
    
    @IBOutlet weak var cnstYPositiveStickRight: NSLayoutConstraint!
    
    @IBOutlet weak var cnstYNegativeStickRight: NSLayoutConstraint!
   
    @IBOutlet weak var cnstXNegativeStickRight: NSLayoutConstraint!
    
    
    @IBOutlet weak var cnstXPositiveStickRight: NSLayoutConstraint!
    //Aircraft velocity
    
    @IBOutlet weak var cnstYPositiveVelocity: NSLayoutConstraint!
    
    @IBOutlet weak var cnstYNegativeVelocity: NSLayoutConstraint!
    
    @IBOutlet weak var cnstXNegativeVelocity: NSLayoutConstraint!
    
    @IBOutlet weak var cnstXPositiveVelocity: NSLayoutConstraint!
    //aircraft distance from the ground
    @IBOutlet weak var cnstZPositive: NSLayoutConstraint!
    
    @IBOutlet weak var cnstZNegative: NSLayoutConstraint!
    
    
    //setup label
    @IBOutlet weak var lblYPositiveLeftStick: UILabel!
    
    
    @IBOutlet weak var lblXPosPositionLeftStick: UILabel!
    
    @IBOutlet weak var lblYPosRight: UILabel!
    
    @IBOutlet weak var lblXPosRight: UILabel!
    
    @IBOutlet weak var lblYAircraftVelocity: UILabel!
    
    @IBOutlet weak var lblZAboveGround: UILabel!
    @IBOutlet weak var lblXAircraftVelocity: UILabel!
    
    @IBOutlet weak var lblDistanceToNearestBoundary: UILabel!
    
    @IBOutlet weak var lblStatusDroneIsInZone: UILabel!
    
    
    @IBOutlet weak var lblGPSData: UILabel!
    
    @IBOutlet weak var lblDistanceAboveGround: UILabel!
    
    @IBOutlet weak var lblVelocityXStatus: UILabel!
    
    @IBOutlet weak var lblVelocityYStatus: UILabel!
    
    @IBOutlet weak var lblVelocityZStatus: UILabel!
    
    @IBOutlet weak var lblAltitudeX: UILabel!
    
    @IBOutlet weak var lblAltitudeY: UILabel!
    
    @IBOutlet weak var lblAltitudeZ: UILabel!
    
    
    //other
    @IBOutlet weak var vwChooseAltitude: UIView!
    @IBOutlet weak var vwCollectiveAltitudes: UIView!
    @IBOutlet weak var mapVw: MKMapView!
    @IBOutlet weak var txtFldCollectiveMin: UITextField!
    @IBOutlet weak var txtFldCollectiveMax: UITextField!
    @IBOutlet weak var txtFldSeperateMin: UITextField!
    @IBOutlet weak var txtFldSeperateMax: UITextField!
    @IBOutlet weak var vwSeparateAltitude: UIView!
    @IBOutlet weak var btnSettingsZone: UIButton!
    @IBOutlet weak var tableViewPlaces: UITableView!
    @IBOutlet weak var btnEditOutlet: UIButton!
    @IBOutlet weak var cnstVwSeparateOriginY: NSLayoutConstraint!
    @IBOutlet weak var vwAddEvent: UIView!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnDeleteZone: UIButton!
    @IBOutlet weak var cnstVwSeparateOriginX: NSLayoutConstraint!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblSeparateAltitudes: UILabel!
    @IBOutlet weak var btnPrssSetPinPositions: UIButton!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblOnlineGroupName: UILabel!
    @IBOutlet weak var tableViewEventList: UITableView!
    @IBOutlet weak var vwEventsLists: UIView!
    @IBOutlet weak var cnstVwSettingsBottom: NSLayoutConstraint!
    @IBOutlet weak var btnZonesList: UIButton!
    
    @IBOutlet weak var btnReadyToFly: UIButton!
    
    @IBOutlet weak var virtualStickRight: VirtualStickView!
    
    @IBOutlet weak var virtualStickLeft: VirtualStickView!
    
    @IBOutlet weak var vwDataFromDrone: UIView!
   
    
    @IBOutlet weak var btnHelipad: UIButton!
    
    @IBOutlet weak var btnDrawOnPop: UIButton!
    
    //MARK: - TESTING CONSTANTS
    
    
    @IBOutlet weak var txtField_K_Pitch: UITextField!
    
    @IBOutlet weak var txtField_D_Pitch: UITextField!
    
    @IBOutlet weak var txtField_K_Roll: UITextField!
   
    @IBOutlet weak var txtField_D_Roll: UITextField!
    
    @IBOutlet weak var txtField_K_Vertical: UITextField!
    
    @IBOutlet weak var txtField_D_Vertical: UITextField!
    
    @IBOutlet weak var vwTestingConstant: UIView!
    
    @IBOutlet weak var switchRollPitch: UISwitch!
    
    @IBOutlet weak var switchVertical: UISwitch!
    
    var testingTimer: Timer?
    
    //MARK:- VARIABLE
    var latitudePick = Float64()
    var longitudePick = Float64()
    var setRegionBool = Bool()
    var annotationAry = [MKAnnotation]()
    var counter = Int32()
    var isCompleted = Bool()
    let locationManager = CLLocationManager()
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    var arrDrawArea = NSMutableArray()
    var mapPolyline = MKPolyline()
    var tapGesture =  UITapGestureRecognizer()
    var showPin = Bool()
    
    //MARK:- IBOUTLET
    @IBOutlet weak var btnDrawEdit: UIButton!
    @IBOutlet weak var vwSearchBar: UIView!
    @IBOutlet weak var cnstVwSettings: NSLayoutConstraint!
   
    //MARK:- Map Methd
    var userLoc = CLLocationCoordinate2D()
    
    @IBAction func btnPrssActionLandingPoints(_ sender: AnyObject) {
        isDragToPoint = true
        isCompleted = false
        vwChooseAltitude.isHidden = true
        showPin = true
        counter = 0
        isLandingPointsToBeMarked = false
        //Place polygon
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id  {
            isDragToPoint = true
            if (self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray)?.count > 0 {
                showPin = false
                isLandingPointsToBeMarked = false
                isDragToPoint = true
                isCompleted = false
                //1.Setting the correct home point
                if let fc = DroneUtility.fetchFlightController(){
                 //1. Enter virtual stick mode
                    fc.yawControlMode = .angularVelocity
                    fc.rollPitchControlMode = .angle
                    fc.rollPitchCoordinateSystem = .ground
                    fc.enableVirtualStickControlMode(completion: { (error) in
                        if error?.localizedDescription.characters.count > 0
                        {
                            proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                        }else{
                            
                        //2.Start simulator
                            if CLLocationCoordinate2DIsValid(self.homeLocationOfUser){
                                fc.simulator?.start(withLocation: self.homeLocationOfUser, updateFrequency: 20, gpsSatellitesNumber: 10, withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0
                                    {
                                        proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                                    }else{
                                        self.btnStartSimulator.isSelected = true
                                        self.btnStartSimulator.setTitle("Stop", for: .normal)

                                        //3.Display home point
                                        let polygon = self.dictPolygon.object(forKey: "\(self.zoneCreateModal.id)") as! MKPolygon
                                        if self.isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)) == true{
                                            self.isDragPin = false
                                            let annotation = LandingPointAnnotationModal(title: self.zoneCreateModal.name, coordinate: CLLocationCoordinate2D(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude), info: "\(self.zoneCreateModal.id)",index: "\(self.counter)")
                                            self.mapVw.addAnnotation(annotation)
                                          
                                            //2.Set flight failsafe operation
                                            let failsafeOperation = DJIFlightFailsafeOperation.goHome
                                            fc.setFlightFailsafeOperation(failsafeOperation, withCompletion: { (error) in
                                                if error?.localizedDescription.characters.count > 0{
                                                    //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                                }else{
                                                
                                                    fc.setGoHomeBatteryThreshold(25, withCompletion: { (error) in
                                                        if error?.localizedDescription.characters.count > 0{
                                                            //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                                        }else{
                                                         let zoneStatusURL = "\(KServerUrl)"+"\(kZoneStatus)" + "\(self.zoneCreateModal.id)"
                                                            let param = [
                                                                "EventZone[state_id]": "1"
                                                                ]
                                                            self.updateStatus(zoneStatusURL, postParam: param as Dictionary<String, AnyObject>)
                                                        }
                                                    })
                                                }
                                            })
                                            
                                        }else{
                                            proxy.sharedProxy().displayStatusCodeAlert("You cannot place landing point outside of polygon ")
                                        }
                                    }
                                })
                                
                            }else{
                            
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to fetch home location")
                            }
                        }
                    })
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                }
            }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }
        }else{
            if (self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray)?.count == 0 {
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }else{
                if zoneCreateModal.id == 0 {
                    proxy.sharedProxy().displayStatusCodeAlert("Please select zone")
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("You cannot enter into other user zone")
                }
            }
        }
    }
    
    func reinstateBackgroundTask() {
        if backgroundTask == UIBackgroundTaskInvalid {
            registerBackgroundTask()
        }
    }
    
    func registerBackgroundTask() {
        backgroundTask = UIApplication.shared.beginBackgroundTask { [weak self] in
            if self?.arrPubNubChannels.count > 0 && ((self?.client) != nil) != nil{
                self?.client.unsubscribeFromAll()
            }
            
            let zoneStatusURL = "\(KServerUrl)"+"\(kZoneStatus)" + "\(self?.zoneCreateModal.id)"
            let param = [
                "EventZone[state_id]": "0"
                        ]
            self?.updateStatus(zoneStatusURL, postParam: param as Dictionary<String, AnyObject>)
            debugPrint("URL:",zoneStatusURL)
            debugPrint("Param:",param)
            self?.endBackgroundTask()
        }
        assert(backgroundTask != UIBackgroundTaskInvalid)
    }
    
    func endBackgroundTask() {
        print("Background task ended.")
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = UIBackgroundTaskInvalid
    }
    
    func updateStatusOfZoneInBackground() {
        let zoneStatusURL = "\(KServerUrl)"+"\(kZoneStatus)" + "\(self.zoneCreateModal.id)"
        let param = [
            "EventZone[state_id]": "0"
            ]
        self.updateStatus(zoneStatusURL, postParam: param as Dictionary<String, AnyObject>)
        debugPrint("URL:",zoneStatusURL)
        debugPrint("Param:",param)

        switch UIApplication.shared.applicationState {
        case .active:
            break
        case .background:
            print("Background time remaining = \(UIApplication.shared.backgroundTimeRemaining) seconds")
        case .inactive:
            break
        }
    }
    
    //MARK:- ACTION
    //Virtual stick mode 
    @IBAction func btnActionEnterVirtualStick(_ sender: AnyObject) {
        
        if let flightController = DroneUtility.fetchFlightController(){
        flightController.yawControlMode = .angularVelocity
        flightController.rollPitchControlMode = .velocity
        flightController.virtualStickAdvancedModeEnabled = true
        flightController.rollPitchCoordinateSystem = .ground
        flightController.verticalControlMode = .velocity
        flightController.enableVirtualStickControlMode(completion: { (error) in
               if error?.localizedDescription.characters.count > 0
                {
                  proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                }else{
                  proxy.sharedProxy().displayStatusCodeAlert("Vitual stick mode enabled")
                   flightController.intelligentFlightAssistant?.setCollisionAvoidanceEnabled(true, withCompletion: nil)
                }
            })
        }else{
          proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
        
    }
    
    @IBAction func btnActionExitVSMode(_ sender: AnyObject) {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.disableVirtualStickControlMode(completion: { (error) in
               if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Exit Virtual Stick Mode: \(error!.localizedDescription)")
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Vitual stick mode disabled")
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    @IBAction func btnActionStartStopSimulator(_ sender: AnyObject) {
        var userLoc = CLLocationCoordinate2D()
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
        }
        
        let aircraft = DroneUtility.fetchAircraft()
        if aircraft != nil {
            aircraft?.remoteController?.delegate = self
            aircraft?.battery?.delegate = self
        }
        
        if btnStartSimulator.isSelected == true {
            if CLLocationCoordinate2DIsValid(self.droneLocationCoordinate) {
         
                let zoneStatusURL = "\(KServerUrl)"+"\(kZoneStatus)" + "\(self.zoneCreateModal.id)"
                let param = [
                    "EventZone[state_id]": "0",
                    ]
                self.updateStatus(zoneStatusURL, postParam: param as Dictionary<String, AnyObject>)

            }
            
            let delay = 2.0 * Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            
                if self.trackerId.characters.count > 0{
                    
                    let statusURL = "\(KServerUrl)" + "\(kLockedConfirmationZone)" + "\(self.zoneCreateModal.id)"
                    let param = [
                        "EventZone[uid]":"\(self.trackerId)",
                        "EventZone[is_locked]":"0"
                    ]
                    self.postTrackingConfirmationNO(statusURL, postParam: param as Dictionary<String, AnyObject>)
                }
            }
            
            self.btnStartSimulator.isSelected = false
            self.btnStartSimulator.setTitle("Start", for: .normal)
            self.isWayPointMissionOn = false
            
            if let flightController = DroneUtility.fetchFlightController(){
                flightController.simulator?.stop(completion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator error: \(error!.localizedDescription)")
                    }else{
                        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
                        if Int32(userId) == self.zoneCreateModal.create_user_id {
                           
                            for someAnnotation in annotationsToRemove {
                                let strId = "\(self.zoneCreateModal.id)"
                                if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                                    let annotation = someAnnotation as! LandingPointAnnotationModal
                                    if annotation.info == strId {
                                        self.mapVw.removeAnnotation(annotation)
                                    }
                                }
                                
                                if someAnnotation.isKind(of: WaypointAnnotation.self) {
                                    let annotation = someAnnotation as! WaypointAnnotation
                                    if annotation.info == strId {
                                        self.mapVw.removeAnnotation(annotation)
                                    }
                                }
                               
                            }
                            
                            self.droneLocationCoordinate = kCLLocationCoordinate2DInvalid
                        }
                        proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator succeeded.")
                    }
                })
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            }
            
        }else{
                if let flightController = DroneUtility.fetchFlightController(){
                flightController.simulator?.start(withLocation: userLoc, updateFrequency: 20, gpsSatellitesNumber: 10, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Start flight error: \(error!.localizedDescription)")
                    }else{
                        self.btnStartSimulator.isSelected = true
                        self.btnStartSimulator.setTitle("Stop", for: .normal)
                        proxy.sharedProxy().displayStatusCodeAlert("Start Simulator succeeded.")
                        self.pubNubClientSetup()
                         self.setLandingPointHome()
                        //2.Set flight failsafe operation
                        let failsafeOperation = DJIFlightFailsafeOperation.goHome
                        flightController.setFlightFailsafeOperation(failsafeOperation, withCompletion: { (error) in
                            if error?.localizedDescription.characters.count > 0{
                            //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                
                            }else{
                                flightController.setGoHomeBatteryThreshold(25, withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0{
                                        //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                    }else{
                                    
                                        let delay = 0.1 * Double(NSEC_PER_SEC)
                                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                                            
                                            if CLLocationCoordinate2DIsValid(self.droneLocationCoordinate){
                                                let location_coordinate = self.droneLocationCoordinate
                                                let userId  = UserDefaults.standard.object(forKey: "id") as! Int
                                                //3.Display home point
                                                let polygon = self.dictPolygon.object(forKey: "\(self.zoneCreateModal.id)") as! MKPolygon
                                                if self.isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: location_coordinate.latitude, longitude: location_coordinate.longitude)) == true{
                                                    self.isDragPin = false
                                                    let annotation = LandingPointAnnotationModal(title: self.zoneCreateModal.name, coordinate: CLLocationCoordinate2D(latitude: location_coordinate.latitude, longitude: location_coordinate.longitude), info: "\(self.zoneCreateModal.id)",index: "0")
                                                    self.mapVw.addAnnotation(annotation)
                                                    
                                                    let zoneStatusURL = "\(KServerUrl)"+"\(kZoneStatus)" + "\(self.zoneCreateModal.id)"
                                                    let param = [
                                                        "EventZone[state_id]": "1",
                                                        ]
                                                    self.updateStatus(zoneStatusURL, postParam: param as Dictionary<String, AnyObject>)
                                                 
                                                    //Set maximum flight height
                                                    let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                                                    flightController.flightLimitation?.setMaxFlightHeight(max_height, withCompletion: { (error) in
                                                        if error?.localizedDescription.characters.count > 0{
                                                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                                        }
                                                    })
                                                    
                                                }else{
                                                    proxy.sharedProxy().displayStatusCodeAlert("You cannot place landing point outside of polygon ")
                                                }
                                            }
                                        }
                                    }
                                })
                            }
                        })
                    }
                })
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            }
        }
    }
    @IBAction func btnActionTakeOff(_ sender: AnyObject) {
         self.initialFlightSetup()
    }
    
    func initialFlightSetup()  {
        if let flightController = DroneUtility.fetchFlightController(){
            if CLLocationCoordinate2DIsValid(self.droneLocationCoordinate) {
             self.min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
                self.takeOffCoordinates = self.droneLocationCoordinate
               
                let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                let stepsToGo = DJIGoToStep.init(coordinate: self.droneLocationCoordinate, altitude: self.min_height)
                let customMission = DJICustomMission.init(steps: [stepsToGo!])
                DJIMissionManager.sharedInstance()!.prepare(customMission!, withProgress: { (value) in
                }, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0{
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }else{
                        DJIMissionManager.sharedInstance()!.startMissionExecution(completion: { (error) in
                            if error?.localizedDescription.characters.count > 0{
                                proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                            }else{
                             proxy.sharedProxy().displayStatusCodeAlert("Take off succeeded...")
                                flightController.setFlightOrientationMode(.courseLock, withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0{
                                    }else{
                                        //Set maximum flight height
                                       // proxy.sharedProxy().displayStatusCodeAlert("Maximum : \(max_height)")
                                        flightController.flightLimitation?.setMaxFlightHeight(max_height, withCompletion: nil)
                                        }
                                })
                            }
                        })
                    }
                })
                
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to fetch current location")
            }
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    


    
    @IBAction func trackUser(_ sender: Any) {
        
            self.cnstWaypointMissionViewTrailingSpace.constant = -124.0
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstWaypointMissionViewTrailingSpace.constant = 8.0
                self.view.layoutIfNeeded()
                self.btnStartTracking.isHidden = true
            })
        

    }
    
    @IBAction func btnPrssStartWayPointMission(_ sender: Any) {
        self.isWaypointMissionStarted = true
       self.isWayPointMissionOn = true
        
        
    }
    
    @IBAction func btnActionCloseWaypointView(_ sender: Any) {
        //Delete previous annotation
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        //Delete home coordinates
        for someAnnotation in annotationsToRemove {
            let strId = "\(zoneCreateModal.id)"
            if someAnnotation.isKind(of: WaypointAnnotation.self) {
                let annotation = someAnnotation as! WaypointAnnotation
                if annotation.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
        self.waypointTargetCoordinate = kCLLocationCoordinate2DInvalid
        self.cnstWaypointMissionViewTrailingSpace.constant = 8.0
        self.view.layoutIfNeeded()
        UIView.animate(withDuration: Double(0.50), animations: {
            self.cnstWaypointMissionViewTrailingSpace.constant = -124.0
            self.view.layoutIfNeeded()
            self.btnStartTracking.isHidden = false
            self.isWayPointMissionOn = false
        })
    }
    
    
    func setLandingPointHome() {
        if   let fc = DroneUtility.fetchFlightController()
        {
            var userLoc = CLLocationCoordinate2D()
                if UserDefaults.standard.object(forKey: "lat") != nil && UserDefaults.standard.object(forKey: "long") != nil{
                    let lat =  UserDefaults.standard.object(forKey: "lat") as! String
                    let long = UserDefaults.standard.object(forKey: "long") as! String
                    userLoc.latitude = CDouble(lat)!
                    userLoc.longitude = CDouble(long)!
                    fc.setHomeLocation(userLoc, withCompletion: { (error) in
                       // proxy.sharedProxy().displayStatusCodeAlert("Unable to set home location: \(error?.localizedDescription)")
                    })
            }
        }
    }
    
    
    //MARK: - LAND TO PARTICULAR POSITION
    
    func landToParticularPosition(_ landingPoints: CLLocationCoordinate2D,dronelocation_coord:CLLocationCoordinate2D)  {
        //Disable maximum flight distance
        if let fc = DroneUtility.fetchFlightController(){
            //1.Set home location with aircraft current location
            fc.getHomeLocation(completion: { (aircraftHomeLocation, error) in
                if error?.localizedDescription.characters.count > 0{
                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                }else{
                    //2.Set maximum altitude for the zone
                    let converted_max_ht = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                    fc.setGoHomeAltitude(converted_max_ht, withCompletion: { (error) in
                        if error?.localizedDescription.characters.count > 0 {
                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                        }else{
                            //3.Varify go home set or not
                            fc.getGoHomeAltitude(completion: { (minimum_altitude, error) in
                                if error?.localizedDescription.characters.count > 0{
                                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                }else{
                                    fc.goHome(completion: { (error) in
                                        if error?.localizedDescription.characters.count > 0{
                                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                        }else{
                                            proxy.sharedProxy().displayStatusCodeAlert("Landing started...")
                                        }
                                    })
                                }
                            })
                        }
                    })
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    
    @IBAction func btnActionLandDrone(_ sender: AnyObject) {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            if Int(self.current_altitude) != 0{
                self.isWayPointMissionOn = false
                if CLLocationCoordinate2DIsValid(self.takeOffCoordinates){
                    if self.isLandingDroneConflictingWithOtherPolygons(landingLocation: self.takeOffCoordinates) == true{
                        let alertController = UIAlertController(title: "Please wait !", message: "Your landing path involves other user zone.Please ensure that no other drones should be present while you land.Do you still want to continue?", preferredStyle: .alert)
                        
                        let continueAction = UIAlertAction(title: "Continue", style: .default, handler: {
                            action in
                            self.landToParticularPosition(self.takeOffCoordinates,dronelocation_coord: self.droneLocationCoordinate)
                        } )
                        alertController.addAction(continueAction)
                        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {
                            action in
                            
                        } )
                        alertController.addAction(continueAction)
                        alertController.addAction(cancelAction)
                        self.present(alertController, animated: true, completion: nil)
                    }else{
                    self.landToParticularPosition(self.takeOffCoordinates,dronelocation_coord: self.droneLocationCoordinate)
                    }
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("You cannnot land drone without takeoff")
            }
        }
    }
    
    
    @IBAction func btnActionPopDrawAndHelipad(_ sender: AnyObject) {
        isLandingPointsToBeDeleted = false
        if self.btnDrawEdit.isSelected == true {
            self.btnDrawEdit.isSelected = false
            self.cnstHelipadPops.constant = 156.0
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstHelipadPops.constant = 0.0
                self.view.layoutIfNeeded()
            })
            
        }else{
            self.btnDrawEdit.isSelected = true
            self.cnstHelipadPops.constant = 0.0
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstHelipadPops.constant = 156.0
                self.view.layoutIfNeeded()
            })
        }
    }
    
    
    func StopSimulatorDrone() {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.simulator?.stop(completion: { (error) in
               if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator error: \(error!.localizedDescription)")
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator succeeded.")
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    
    func autolandStarted()  {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.goHome(completion: { (error) in
           if error?.localizedDescription.characters.count > 0
                {
                proxy.sharedProxy().displayStatusCodeAlert("error: \(error!.localizedDescription)")
                    self.StopSimulatorDrone()
            }else{
            proxy.sharedProxy().displayStatusCodeAlert("Landing Started..")
                self.StopSimulatorDrone()
                                    
        }
    })
            

        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }

    }
    
    @IBAction func btnPrssActionReadyToFly(_ sender: AnyObject) {
       
        
//        self.cnstGridMissionSetup.constant = 4.0
//        let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
//        let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
//        sliderAltitudeWhileWaypointMission.minimumValue = min_height
//        sliderAltitudeWhileWaypointMission.maximumValue = max_height
//        var arrAnnotation = [MKAnnotation]()
//        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
//        //if Int32(userId) == zoneCreateModal.create_user_id {
//            //Polygon pin points
//            for someAnnotation in annotationsToRemove {
//                let strId = "\(zoneCreateModal.id)"
//                if someAnnotation.isKind(of: AnnotationModal.self) {
//                    let annotation = someAnnotation as! AnnotationModal
//                    if annotation.info == strId {
//                        arrAnnotation.append(annotation)
//                    }
//                }
//            }
//            self.mapVw.showAnnotations(arrAnnotation, animated: true)
//            let gridDivion = sliderGridGap.value
//        let viewRotate = UIView.init(frame: self.mapVw.frame)
//        segmentLines = proxy.sharedProxy().getSegments(viewRotate, numberOfDivisions: Int32(self.sliderGridGap.value),angle: Double(self.sliderRotateGrid.value))
//            self.getGridWayPointMission(Int32(gridDivion),isDrawLines:true)
//            self.lblWayPointQty.text = "\(arrLocations.count) PTS"
//
    
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id  {
            if btnReadyToFly.isSelected == true {
                self.btnStartTracking.isHidden = true
                btnReadyToFly.isSelected = false
                btnReadyToFly.setTitle("Ready to Fly", for: .normal)
                self.autolandStarted()
                virtualStickLeft.isHidden = true
                virtualStickRight.isHidden = true
                vwDataFromDrone.isHidden = true
                btnZonesList.isHidden = false
                vwEventsLists.isHidden = false
                btnSettingsZone.isHidden = false
                cnstVwSettings.constant = 0
                vwChooseAltitude.isHidden = true
                vwCollectiveAltitudes.isHidden = true
                vwSeparateAltitude.isHidden = true
                vwSimulatorControl.isHidden = true
                vwSearchBar.isHidden = false
                self.vwTestingConstant.isHidden = true
                self.isWayPointMissionOn = false
                
            }else{
                
                if self.isSelfIntersecting == true {
                    proxy.sharedProxy().displayStatusCodeAlert("Error: Invalid polygon structure")
                }else if self.isOverLapped == true{
                proxy.sharedProxy().displayStatusCodeAlert("Error: you cannot make polygon in other users zone")
                }else{
                    
                    if CLLocationCoordinate2DIsValid(homeLocationOfUser) && homeLocationOfUser.latitude != 0.0 && homeLocationOfUser.longitude != 0.0 {
                        // let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                        let arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray
                        if arrTemp?.count > 0 {
                            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                            for someAnnotation in annotationsToRemove {
                                let strId = "\(zoneCreateModal.id)"
                                if someAnnotation.isKind(of: AnnotationModal.self) {
                                    let annotaion = someAnnotation as! AnnotationModal
                                    if annotaion.info == strId {
                                        self.mapVw.removeAnnotation(someAnnotation)
                                    }
                                }
                            }
                            
                            for someAnnotation in annotationsToRemove {
                                let strId = "\(zoneCreateModal.id)"
                                if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                                    let annotaion = someAnnotation as! LandingPointAnnotationModal
                                    if annotaion.info == strId {
                                        //  self.mapVw.removeAnnotation(someAnnotation)
                                    }
                                }
                                if someAnnotation.isKind(of: DividerAnnotation.self) {
                                    let annotaion = someAnnotation as! DividerAnnotation
                                    if annotaion.info == strId {
                                        self.mapVw.removeAnnotation(someAnnotation)
                                    }
                                }
                            }
                            
                            //Set max flight radius
                            if let flightController = DroneUtility.fetchFlightController(){
                                //Set settings
                                self.btnSettingsZone.isSelected = false
                                self.cnstVwSettingsBottom.constant = 118
                                self.cnstVwSettings.constant = 500.0
                                self.view.layoutIfNeeded()
                                UIView.animate(withDuration: Double(0.50), animations: {
                                    self.cnstVwSettings.constant = 0
                                    self.cnstVwSettingsBottom.constant = 60
                                    self.view.layoutIfNeeded()
                                })
                                // self.fpvTempView.isHidden = false
                                self.vwTestingConstant.isHidden = true
                                self.btnStartTracking.isHidden = false
                                self.btnReadyToFly.isSelected = true
                                self.btnReadyToFly.setTitle("Exit", for: .normal)
                                self.vwSearchBar.isHidden = true
                                self.vwSimulatorControl.isHidden = false
                                self.cnstHelipadPops.constant = 0
                                self.setUpManager()
                                
                                
                                
                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                            }
                            
                        }else{
                            proxy.sharedProxy().displayStatusCodeAlert("Please create zone before connecting to drone")
                        }
                        
                    }else{
                        
                        proxy.sharedProxy().displayStatusCodeAlert("Cannot fetch user location")
                    }
                
                }
                
                
              
              }
            }else{
            
            let arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray
            if zoneCreateModal.id == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone before connecting to drone")
            }else{
                if arrTemp?.count > 0{
                 proxy.sharedProxy().displayStatusCodeAlert("Please create zone before connecting to drone")
                }else{
                 proxy.sharedProxy().displayStatusCodeAlert("You cannot fly into other user's zone")
                }
            }
        }
    }
    
    
    //MARK:- WEBSERVICE HANDLING
    func updateStatus(_ url: String,postParam: Dictionary<String, AnyObject>)  {
        WebServiceRequest.postNormalData(postParam, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK")
            {
               
            }
            else
            {
               // let errorMessage = responseDict["error"] as! String
                proxy.sharedProxy().displayStatusCodeAlert("Unable to get response")
            }
        }, failure: { (error) in
            
            if error.localizedDescription.characters.count > 0{
                
                let alertController = UIAlertController(title: "Error", message: "\(error.localizedDescription)", preferredStyle: .alert)
                let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                    action in
                    self.updateStatus(url, postParam: postParam)
                }
                )
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                }
                )
                alertController.addAction(retryAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
        })
    }

    
   //MARK: - ACTIONS
   
    
    @IBAction func btnActionFpvFullScreen(_ sender: Any) {
       
        if self.btnFullScreen.isSelected == true {
            self.btnFullScreen.isSelected = false
            VideoPreviewer.instance().start()
            adapter = VideoPreviewerSDKAdapter(videoPreviewer: VideoPreviewer.instance())
            adapter?.start()
            VideoPreviewer.instance().setView(self.fpvView)
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstfpvFullScreen.constant = 0.0
                self.view.layoutIfNeeded()
                 self.fpvTempView.isHidden = true
                 self.btnfpvFullScreenOverlay.isHidden = true
            })
    
        }else{
            
            self.btnFullScreen.isSelected = true
            VideoPreviewer.instance().start()
            adapter = VideoPreviewerSDKAdapter(videoPreviewer: VideoPreviewer.instance())
            adapter?.start()
            VideoPreviewer.instance().setView(self.fpvFullScreen)
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstfpvFullScreen.constant = 1024.0
                self.fpvTempView.isHidden = true
                self.view.layoutIfNeeded()
                self.btnfpvFullScreenOverlay.isHidden = false
            })

        }
        
    }
   
    @IBAction func btnActionFullScreenVideoClose(_ sender: Any) {
        self.btnFullScreen.isSelected = false
       self.cnstfpvFullScreen.constant = 0.0
        self.fpvTempView.isHidden = false
       VideoPreviewer.instance().setView(self.fpvView)
        self.btnfpvFullScreenOverlay.isHidden = true
        
    }
    
    
    @IBAction func btnAction3DView(_ sender: AnyObject) {
            isLandingPointsToBeMarked = false
            let vc  = storyboard?.instantiateViewController(withIdentifier: "ThreeDViewController") as! ThreeDViewController
            vc.strTitle = self.modalEventListOnline.name
            let arrTempAllZones = NSMutableArray()
            if arrEventsList.count > 0 {
            for eventObject  in arrEventsList {
                let event = eventObject as! ZoneCreateModal
                let dictEvent = NSMutableDictionary()
                dictEvent.setObject(event.name, forKey: "name" as NSCopying)
                dictEvent.setObject(event.zones, forKey: "zones" as NSCopying)
                dictEvent.setObject(event.id.hashValue, forKey: "id" as NSCopying)
                arrTempAllZones.add(dictEvent)
            }
            print("Array passed : ",arrTempAllZones)
            vc.arrAllZones = arrTempAllZones as [AnyObject]
            self.navigationController?.pushViewController(vc, animated: false)
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone to view 3D zone")
           }
    }
    
    @IBAction func btnPrssAddEvents(_ sender: AnyObject) {
   isLandingPointsToBeMarked = false
    //Delete annotation
    let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            let strId = "\(zoneCreateModal.id)"
            if someAnnotation.isKind(of: AnnotationModal.self) {
                let annotaion = someAnnotation as! AnnotationModal
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
            
            if someAnnotation.isKind(of: DividerAnnotation.self) {
                let annotaion = someAnnotation as! DividerAnnotation
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
        
        
        let createZoneVC = storyboard?.instantiateViewController(withIdentifier: "CreateZonePopupVC") as! CreateZonePopupVC
        protocolObjectOfflineZone = self
        createZoneVC.modalTransitionStyle = .crossDissolve
        createZoneVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createZoneVC, animated: true, completion: nil)
    }
    @IBAction func btnPrssCloseEvents(_ sender: AnyObject) {
        if self.btnZonesList.isSelected == true {
            self.btnZonesList.isSelected = false
            vwEventsLists.isHidden = true
        }else{
            self.btnZonesList.isSelected = true
            vwEventsLists.isHidden = false
        }
    }
    
    @IBAction func btnEditClose(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        vwChooseAltitude.isHidden = true
        isDragToPoint = true
    }
    @IBAction func btnPrssSetPinPosition(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        showPin = false
        vwChooseAltitude.isHidden = true
        isDragToPoint = true
        isCompleted = false
        if zoneCreateModal.zones.count == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
        }
    }
    
    
    @IBAction func btnPrssSeparateDone(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        if txtFldSeperateMin.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Minimum Altitude")
        }else if txtFldSeperateMax.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Maximum Altitude")
        }else {
            if txtFldSeperateMax.text!.isNumeric == true && txtFldSeperateMin.text!.isNumeric{
                let min_height = Int32(txtFldSeperateMin.text!)
                let max_height = Int32(txtFldSeperateMax.text!)
                
                if Float(max_height!)/3.2808 <= 500.00{
                    if min_height! <= max_height!  {
                        if min_height! >= 66 {
                            if selectedAnnotationVw.annotation != nil {
                                if (selectedAnnotationVw.annotation?.isKind(of: AnnotationModal.self))! {
                                    let annotation = selectedAnnotationVw.annotation as? AnnotationModal
                                    let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation!.info)) as! NSMutableArray
                                    let dict = arrTempDrawPolygon[selectedAnnotationVw.tag-1] as! NSMutableDictionary
                                    dict["max_alt"] = txtFldSeperateMax.text!
                                    dict["min_alt"] = txtFldSeperateMin.text!
                                    arrTempDrawPolygon.replaceObject(at: selectedAnnotationVw.tag-1, with: dict)
                                    self.dictMainEventList.setObject(arrTempDrawPolygon, forKey: "\(annotation!.info)" as NSCopying)
                                    let str_id = annotation!.info
                                    for i in 0 ..< arrEventsList.count{
                                        let modalObject = arrEventsList[i] as! ZoneCreateModal
                                        if modalObject.id == Int32(str_id) {
                                            modalObject.zones = arrTempDrawPolygon
                                            arrEventsList.replaceObject(at: i, with: modalObject)
                                            tableViewEventList.reloadData()
                                        }
                                    }
                                    vwSeparateAltitude.isHidden = true
                                    // mapVw.deselectAnnotation(selectedAnnotationVw.annotation, animated: true)
                                    
                                }
                            }
                         
                        }else{
                            proxy.sharedProxy().displayStatusCodeAlert("Minimum height should be greater than 66 ft.")
                        }
                        
                    }else{
                        proxy.sharedProxy().displayStatusCodeAlert("Minimum Height should be less than Maximum Height")
                    }
                }else{
                    
                    proxy.sharedProxy().displayStatusCodeAlert("Maximum height should be less than or equals to 500")
                }
                vwSeparateAltitude.isHidden = true
            
            }else{
                txtFldSeperateMin.text! = ""
                txtFldSeperateMax.text! = ""
                proxy.sharedProxy().displayStatusCodeAlert("Please enter valid height")
            }
        }
    }
    
    
    @IBAction func btnPrssSettings(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0
        btnDrawEdit.isSelected = false
        isLandingPointsToBeMarked = false
        if self.btnSettingsZone.isSelected == true {
            self.btnSettingsZone.isSelected = false
            self.cnstVwSettingsBottom.constant = 118
            self.cnstVwSettings.constant = 500.0
          
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstVwSettings.constant = 0
                self.cnstVwSettingsBottom.constant = 60
                self.view.layoutIfNeeded()
            })
            
        }else{
            self.btnSettingsZone.isSelected = true
            self.cnstVwSettings.constant = 0.0
            self.cnstVwSettingsBottom.constant = 60
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstVwSettings.constant = 500
                self.cnstVwSettingsBottom.constant = 118
                self.view.layoutIfNeeded()
            })
        }
    }
    
    @IBAction func btnPrssSeparateClose(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
       // mapVw.deselectAnnotation(selectedAnnotationVw.annotation, animated: true)
        vwSeparateAltitude.isHidden = true
    }
    
    @IBAction func btnBack(_ sender: AnyObject) {
        
        if self.product.isConnected == true {
            DJISDKManager.stopConnectionToProduct()
        }
        
        if updateTimer != nil {
            updateTimer?.invalidate()
            updateTimer = Timer.scheduledTimer(timeInterval: 2.0, target: self,
                                               selector: #selector(updateStatusOfZoneInBackground), userInfo: nil, repeats: false)
            registerBackgroundTask()
        }
        self.missionManager.delegate = nil
       
        if adapter != nil{
            VideoPreviewer.instance().unSetView()
            adapter.stop()
        }
        
        _ =  self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func btnCollectiveAction(_ sender: AnyObject) {
        isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        vwChooseAltitude.isHidden = true
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id || zoneCreateModal.id == 0{
            if zoneCreateModal.zones.count == 0 {
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }else{
                vwCollectiveAltitudes.isHidden = false
            }
        }else{
         vwCollectiveAltitudes.isHidden = true
            
        }
    }
    
    @IBAction func btnSeperateAction(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        let annotation = selectedAnnotationVw.annotation as? AnnotationModal
        if annotation != nil {
            vwChooseAltitude.isHidden = true
            vwSeparateAltitude.isHidden = false
            let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation?.info)!) as! NSArray
            if arrTempDrawPolygon.count > 0 {
                isCompleted = true
                showPin = false;
            }
            vwChooseAltitude.isHidden = true
            let dictShowAltitude = arrTempDrawPolygon[selectedAnnotationVw.tag-1] as! NSMutableDictionary
            txtFldSeperateMin.text = dictShowAltitude.value(forKey: "min_alt") as? String
            txtFldSeperateMax.text = dictShowAltitude.value(forKey: "max_alt") as? String
            vwSeparateAltitude.isHidden = false
            let mainScreenWidth = UIScreen.main.bounds.size.width
            let mainScreenHeight = UIScreen.main.bounds.size.height
            UIDevice.current.beginGeneratingDeviceOrientationNotifications()
            if UIDevice.current.orientation.isLandscape {
                //  Landscape
                if selectedAnnotationVw.frame.origin.x >= mainScreenWidth-250 {
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x - 600
                    
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }else{
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x-350
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }
                //isPortrait
                
            } else  if UIDevice.current.orientation.isPortrait {
                
                //Portrait
                if view.frame.origin.x >= mainScreenWidth-250 {
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x-500
                    if view.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-520
                    }
                }else{
                    cnstVwSeparateOriginX.constant = abs(selectedAnnotationVw.frame.origin.x)-250
                    
                    if view.frame.origin.y >= mainScreenHeight-100 {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-520
                    }
                    
                }
            }else{
                if selectedAnnotationVw.frame.origin.x >= mainScreenWidth-250 {
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x - 600
                    
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }else{
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x-350
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }
            }
            lblSeparateAltitudes.text = " Separate Altitudes(\(selectedAnnotationVw.tag))"
        }else{
            if zoneCreateModal.zones.count == 0 {
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone pins")
            }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please select zone from Zones list")
           }
        }
        vwChooseAltitude.isHidden = true
    }
    @IBAction func btnCollectiveCross(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        vwCollectiveAltitudes.isHidden = true
    }
    @IBAction func btnCollectiveDone(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        if txtFldCollectiveMin.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Minimum Altitude")
        }else if txtFldCollectiveMax.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Maximum Altitude")
        }else {
            
            if txtFldCollectiveMin.text!.isNumeric == true && txtFldCollectiveMax.text!.isNumeric{
            
                let min_height = Int32(txtFldCollectiveMin.text!)
                let max_height = Int32(txtFldCollectiveMax.text!)
                if zoneCreateModal.id != 0 {
                    
                    let arrTempDrawPolygon = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSMutableArray
                    if Float(max_height!)/3.2808 <= 500.00 {
                        if min_height < max_height {
                            
                            if min_height! >= 66 {
                                if arrTempDrawPolygon.count == 0 {
                                    vwCollectiveAltitudes.isHidden = true
                                    proxy.sharedProxy().displayStatusCodeAlert("Please select points on Map to create zones")
                                }else{
                                    
                                    for i in 0 ..< arrTempDrawPolygon.count {
                                        let dictUpdateAltitude = arrTempDrawPolygon[i] as! NSMutableDictionary
                                        dictUpdateAltitude.setObject(txtFldCollectiveMin.text!, forKey: "min_alt" as NSCopying)
                                        dictUpdateAltitude.setObject(txtFldCollectiveMax.text!, forKey: "max_alt" as NSCopying)
                                        arrTempDrawPolygon.replaceObject(at: i, with: dictUpdateAltitude)
                                    }
                                    self.dictMainEventList.setObject(arrTempDrawPolygon, forKey: "\(zoneCreateModal.id)" as NSCopying)
                                    
                                    let str_id = zoneCreateModal.id
                                    for i in 0 ..< arrEventsList.count{
                                        let modalObject = arrEventsList[i] as! ZoneCreateModal
                                        if modalObject.id == str_id {
                                            modalObject.zones = arrTempDrawPolygon
                                            arrEventsList.replaceObject(at: i, with: modalObject)
                                            tableViewEventList.reloadData()
                                        }
                                    }
                                    vwCollectiveAltitudes.isHidden = true
                                }
                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Please enter minimum height greater than 66 ft.")
                            }
                            
                        }else{
                            proxy.sharedProxy().displayStatusCodeAlert("Minimum Height should be less than Maximum Height")
                        }
                    }else{
                        proxy.sharedProxy().displayStatusCodeAlert("Maximum height must be less than or equal to 500")
                    }
                }
                
            }else{
            
                txtFldCollectiveMin.text! = ""
               txtFldCollectiveMax.text! = ""
                proxy.sharedProxy().displayStatusCodeAlert("Please enter valid number")
            }
          
        }
    }
    
    @IBAction func btnEditAction(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0.0
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isAltitude = true
        isPlacePolygon = false
        isDrawPolygon = false
        isDeletePolygon = false
         vwChooseAltitude.isHidden = false
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id {
            vwCollectiveAltitudes.isHidden = true
             vwSeparateAltitude.isHidden = true
        }

    }
    
    @IBAction func btnPrssDragPolygon(_ sender: AnyObject) {
       
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id {
        let arrZones = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
        if arrZones.count > 0 {
        vw.frame = CGRect(x: 0, y: 0, width: self.mapVw.frame.size.width, height: self.mapVw.frame.size.height)
        //Delete annotations
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            let strId = "\(self.zoneCreateModal.id)"
            if someAnnotation.isKind(of: AnnotationModal.self) {
                let annotaion = someAnnotation as! AnnotationModal
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
            if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                let annotaion = someAnnotation as! LandingPointAnnotationModal
                if annotaion.info == strId {
                   // self.mapVw.removeAnnotation(someAnnotation)
                }
            }
            
            if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                let annotaion = someAnnotation as! ZoneNameAnnotationModal
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
            
            if someAnnotation.isKind(of: DividerAnnotation.self) {
                let annotaion = someAnnotation as! DividerAnnotation
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
            
        }
        
            
            
        //Remove overlay
        for overlay in self.mapVw.overlays {
            if overlay.isKind(of: MKPolygon.self) {
                let strTitle = String(validatingUTF8: overlay.title!!)!
                print("Zone Name : \(strTitle)")
                if strTitle == self.zoneCreateModal.name {
                    self.mapVw.remove(overlay)
                }
  
            }
        }
       
        let arrPoints = NSMutableArray()
        //Convert lat and longitude to x and y pos of zone
        for i in 0 ..< arrZones.count {
            var zoneLoc = CLLocationCoordinate2D()
            let dict = arrZones[i] as! NSMutableDictionary
            let lat = dict["lat"] as! String
            let long = dict["longt"] as! String
            let min_height = Int32((dict["min_alt"] as! NSString) as String)
            let max_height = Int32((dict["max_alt"] as! NSString) as String)
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            zoneLoc.latitude = Double(newLat)!
            zoneLoc.longitude = Double(newLong)!
            let point = self.mapVw.convert(zoneLoc, toPointTo: self.mapVw)
            let dictPoints = NSMutableDictionary()
            dictPoints.setObject(vw.frame.origin.x+point.x, forKey: "xPos" as NSCopying)
            dictPoints.setObject(vw.frame.origin.y+point.y, forKey: "yPos" as NSCopying)
            dictPoints.setObject("\(min_height)", forKey: "min_alt" as NSCopying)
            dictPoints.setObject("\(max_height)", forKey: "max_alt" as NSCopying)
            arrPoints.add(dictPoints)
        }

        var firstPos = CGPoint()
        let dictPos = arrPoints.object(at: 0) as! NSMutableDictionary
        firstPos.x = CGFloat(Float(dictPos["xPos"] as! NSNumber))
        firstPos.y = CGFloat(Float(dictPos["yPos"] as! NSNumber))
        linePath.move(to: firstPos)
        //Shape Layer
        line.frame = vw.frame
        
        for i in 1 ..< arrPoints.count {
            var posTemp = CGPoint()
            let dictPos = arrPoints.object(at: i) as! NSMutableDictionary
            posTemp.x = CGFloat(Float(dictPos["xPos"] as! NSNumber))
            posTemp.y = CGFloat(Float(dictPos["yPos"] as! NSNumber))
            linePath.addLine(to: posTemp)
  
        }
     
        linePath.close()
        line.lineWidth = 1.0
        line.path = linePath.cgPath
        line.fillColor = UIColor(red: 15.0/255, green: 125.0/255, blue: 239.0/255, alpha: 0.10).cgColor
        line.strokeColor = UIColor(red: 71.0/255, green: 194.0/255, blue: 19.0/255, alpha: 1).cgColor
        vw.layer.addSublayer(line)
        vw.backgroundColor = UIColor.clear
        self.mapVw.addSubview(vw)
        self.mapVw.bringSubview(toFront: vw)
        let panGR = UIPanGestureRecognizer(target: self, action: #selector(CreateZoneOnlineVC.didPan(_:)))
        vw.addGestureRecognizer(panGR)
        vwChooseAltitude.isHidden = true
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please create polygon first")
        }
        }else{
            if zoneCreateModal.id == 0 {
               proxy.sharedProxy().displayStatusCodeAlert("Please first create or select zone")
            }else{
           proxy.sharedProxy().displayStatusCodeAlert("You cannot edit other user zone")
            }
        }
    }
    
    
    @IBAction func btnPrssClear(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0.0
         isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isDeletePolygon = true
        isPlacePolygon = false
        isAltitude = false
        isDrawPolygon = false
        
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id {
            if zoneCreateModal.id != 0 {
                let alertController = UIAlertController(title: "", message: "Are you sure to delete \"\(zoneCreateModal.name)\" zone?", preferredStyle: .alert)
                let deleteAction = UIAlertAction(title: "Delete", style: .default, handler: {
                    action in
                    
                    self.showPin = false
                    self.counter = 0
                    self.isCompleted = false
                    self.isDragToPoint = true
                    
                    //Delete annotation
                    let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                    for someAnnotation in annotationsToRemove {
                        let strId = "\(self.zoneCreateModal.id)"
                        if someAnnotation.isKind(of: AnnotationModal.self) {
                            let annotaion = someAnnotation as! AnnotationModal
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                        if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                            let annotaion = someAnnotation as! LandingPointAnnotationModal
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                        
                        if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                            let annotaion = someAnnotation as! ZoneNameAnnotationModal
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                        
                        if someAnnotation.isKind(of: DividerAnnotation.self) {
                            let annotaion = someAnnotation as! DividerAnnotation
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                        
                    }
                    
                    //Remove overlay
                    for overlay in self.mapVw.overlays {
                        if overlay.isKind(of: MKPolygon.self){
                            let strTitle = String(validatingUTF8: overlay.title!!)!
                            print("Zone Name : \(strTitle)")
                            if strTitle == self.zoneCreateModal.name {
                                self.mapVw.remove(overlay)
                            }
                        }
                }
                    
                    let deleteUrl = "\(KServerUrl)" + "\(kDeleteZone)" + "\(self.zoneCreateModal.id)"
                    KAppDelegate.showActivityIndicator()
                    let reachability = Reachability()
                    if  reachability?.isReachable  == true

                    {

                         request(deleteUrl, method: .post, parameters: nil, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                            .responseJSON { response in
                                do
                                {
                                if(response.response?.statusCode == 200)
                                    {
                                        if let JSONDIC = response.result.value as? NSDictionary{
                                            if (JSONDIC["status"]! as AnyObject).isEqual("OK")
                                            {
                                                let  arrTemp  = NSMutableArray()
                                                self.dictMainEventList.setObject(arrTemp, forKey: "\(self.zoneCreateModal.id)" as NSCopying)
                                                self.vwChooseAltitude.isHidden = true
                                                self.vwCollectiveAltitudes.isHidden = true
                                                self.annotationAry.removeAll()
                                                self.vwSeparateAltitude.isHidden = true
                                                self.vwChooseAltitude.isHidden = true
                                                if self.arrEventsList.count > 0 {
                                                    self.arrEventsList.removeObject(at: self.selectedIndexPath.row)
                                                    self.tableViewEventList.reloadData()
                                                    
                                                }
                                                self.dictMainEventList.removeObject(forKey: "\(self.zoneCreateModal.id)")
                                                self.zoneCreateModal = ZoneCreateModal()
                                                
                                                KAppDelegate.hideActivityIndicator()
                                                proxy.sharedProxy().displayStatusCodeAlert("Zone deleted successfully")
                                                
                                            }else{
                                                
                                                KAppDelegate.hideActivityIndicator()
                                                let message = JSONDIC["error"] as! String
                                                proxy.sharedProxy().displayStatusCodeAlert(message)
                                            }
                                        }else{
                                            proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                                        }
                                    }
                                    else
                                    {
                                        KAppDelegate.hideActivityIndicator()
                                         proxy.sharedProxy().stautsHandler(deleteUrl, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                                    }
                                }
                                catch let error as NSError
                                {
                                    KAppDelegate.hideActivityIndicator()
                                    NSLog("EXCEPTION : %@", error.description)
                                }
                        }
                    }
                    else
                    {
                        KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().openSettingApp()
                      }
                    }
                )
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                    }
                )
                alertController.addAction(deleteAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
          
        }else{
            
            if zoneCreateModal.id == 0 {
                proxy.sharedProxy().displayStatusCodeAlert("Please select zone")
            }else{
               proxy.sharedProxy().displayStatusCodeAlert("You cannot delete \(zoneCreateModal.name)'s zone")
            }
          
        }
        
    }
    
    func isLandingDroneConflictingWithOtherPolygons(landingLocation:CLLocationCoordinate2D) -> Bool {
        
        //check current polygon with other polygons
        var isIntersectionFound = false
        if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
            let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
            let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
           
            for i in 0..<self.arrEventsList.count{
                let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalEvent.zones).object(forKey: "maximum_height") as! Float

                if zoneCreateModal.id != modalEvent.id {
                    let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                    if arrTempOther.count > 0 {
                        let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                        let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                        if somePolygon!.pointCount > 0 {
                                if isInsideThePolygon(other_polygon, sampleLocation: landingLocation) == true {
                                    if max_height <= current_min_height {
                                         isIntersectionFound = true
                                         break
                                    }
                            }
                        }
                    }
                }
            }
        }

        return isIntersectionFound
    }
    
    func isIntersectionFoundWithOtherPolygons() -> Bool {
        
        //check current polygon with other polygons
        var isIntersectionFound = false
        var isHeightIntersected = false
        if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
            let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
            let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
            let current_max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
            for i in 0..<self.arrEventsList.count{
                let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                if zoneCreateModal.id != modalEvent.id {
                    let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                    if arrTempOther.count > 0 {
                        let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                        let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                        let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalEvent.zones).object(forKey: "minimum_height") as! Float
                        let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalEvent.zones).object(forKey: "maximum_height") as! Float
                        
                        //Find Height intersection
                        //case 0:
                        if current_min_height >= min_height  && current_max_height <= min_height{
                            isHeightIntersected = true
                        }
                        //case 1:
                        if current_min_height <= min_height && current_max_height >= max_height {
                            isHeightIntersected = true
                        }else{
                            if current_max_height >= min_height && current_max_height <= max_height {
                                isHeightIntersected = true
                            }
                            
                        }
                        
                        if somePolygon!.pointCount > 0 {
                            if  isHeightIntersected == true {
                                isIntersectionFound = true
                                break
                            }
                        }
                    }
                }
            }
        }
        
        return isIntersectionFound

    }
    
    
    @IBAction func btnPrssDraw(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0
         isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isDrawPolygon = true
        isPlacePolygon = false
        isAltitude = false
        isDeletePolygon = false
        self.showPin = false
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id {
       
            //Draw Polygon
            isDragToPoint = true
            counter = 0
            isCompleted = false
            if let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSMutableArray{
            if arrTemp.count  < 3 {
                    proxy.sharedProxy().displayStatusCodeAlert("Please select atleast 3 points to draw a region")
            }else{
               
                if isLandingPointsOutside == true {
                    proxy.sharedProxy().displayStatusCodeAlert("Please place landing points inside the polygon")
                }else{
                    if isCompleted == false {
                       // vwChooseAltitude.isHidden = false
                        self.zoneCreateModal.zones = arrTemp as NSArray
                        self.arrEventsList.replaceObject(at: (selectedIndexPath as NSIndexPath).row, with: self.zoneCreateModal)
                        if self.arrEventsList.count > 0 {
                            self.tableViewEventList.reloadData()
                        }
                        //check current polygon with other polygons
                        var isIntersectionFound = false
                        var isHeightIntersected = false
                        if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
                          let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSMutableArray
                            let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                            let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "minimum_height") as! Float
                            let current_max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "maximum_height") as! Float
                            for i in 0..<self.arrEventsList.count{
                                let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                                if zoneCreateModal.id != modalEvent.id {
                                    let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                                    if arrTempOther.count > 0 {
                                        let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                                        let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                                        
                                        let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTempOther).object(forKey: "minimum_height") as! Float
                                        let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTempOther).object(forKey: "maximum_height") as! Float
                                        
                                        //Find Height intersection
                                        //case 0:
                                        if current_min_height >= min_height  && current_max_height <= min_height{
                                            isHeightIntersected = true
                                        }
                                        //case 1:
                                        if current_min_height <= min_height && current_max_height >= max_height {
                                            isHeightIntersected = true
                                        }else{
                                            if current_max_height >= min_height && current_max_height <= max_height {
                                                isHeightIntersected = true
                                            }
                                            
                                        }
                                        
                                        
                                        if somePolygon!.pointCount > 0 {
                                            if  isHeightIntersected == true {
                                                isIntersectionFound = true
                                                 break
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        if isIntersectionFound == true{
                            isOverLapped = true
                        }else{
                            isOverLapped = false
                        }

                        var strIsUpdate = String()
                        strIsUpdate = self.dictUpdateBools.object(forKey: "\(zoneCreateModal.id)") as! String
                        if  strIsUpdate == "1"{
                            //check overlay
                            var isOverlayDraw = false
                            for overlay in self.mapVw.overlays {
                                if overlay.isKind(of: MKPolygon.self) {
                                    let strTitle = String(validatingUTF8: overlay.title!!)!
                                    if strTitle == zoneCreateModal.name {
                                        isOverlayDraw = true
                                    }
                                }
                            }
                            
                            if isOverlayDraw == false {
                                self.isDragPin = true
                                if isIntersectionFound == true{
                                isOverLapped = true
                               }else{
                                isOverLapped = false
                            }
                                
                                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                                //Polygon pin points
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: AnnotationModal.self) {
                                        let annotaion = someAnnotation as! AnnotationModal
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                self.drawPloygon(arrTemp, strTitle: "\(zoneCreateModal.name)", strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true,strCreatedUserId: "\(zoneCreateModal.create_user_id)",willShowDistance:true)
                            }
                           
                            if isIntersectionFound == false{
                                 let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                                //Polygon pin points
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: AnnotationModal.self) {
                                        let annotaion = someAnnotation as! AnnotationModal
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                //1.Remove the previous polygon
                                //Remove overlay
                                for overlay in self.mapVw.overlays {
                                    if overlay.isKind(of: MKPolygon.self) {
                                        let strTitle = String(validatingUTF8: overlay.title!!)!
                                        print("Zone Name : \(strTitle)")
                                        if strTitle == self.zoneCreateModal.name {
                                            self.mapVw.remove(overlay)
                                        }
                                    }
                                }
                                
                                //Remove divider annotation
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: DividerAnnotation.self) {
                                        let annotaion = someAnnotation as! DividerAnnotation
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                
                                //Remove center coordinate
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self){
                                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                  self.drawPloygon(arrTemp, strTitle: zoneCreateModal.name, strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true, strCreatedUserId: "\(userId)",willShowDistance:true)
                                
                            self.updateEvent("\(zoneCreateModal.id)")
                            }else{
                                
                                if isIntersectionFound == true{
                                    isOverLapped = true
                                }else{
                                    isOverLapped = false
                                }
                                
                                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                                //Polygon pin points
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: AnnotationModal.self) {
                                        let annotaion = someAnnotation as! AnnotationModal
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                //1.Remove the previous polygon
                                //Remove overlay
                                for overlay in self.mapVw.overlays {
                                    if overlay.isKind(of: MKPolygon.self) {
                                        let strTitle = String(validatingUTF8: overlay.title!!)!
                                        print("Zone Name : \(strTitle)")
                                        if strTitle == self.zoneCreateModal.name {
                                            self.mapVw.remove(overlay)
                                        }
                                    }
                                }
                                
                                //Remove divider annotation
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: DividerAnnotation.self) {
                                        let annotaion = someAnnotation as! DividerAnnotation
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                
                                //Remove center coordinate
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self){
                                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                
                                self.drawPloygon(arrTemp, strTitle: zoneCreateModal.name, strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true, strCreatedUserId: "\(userId)",willShowDistance:true)
                                
                                proxy.sharedProxy().displayStatusCodeAlert("Please place zone outside of other zone")
                            }
                            
                        }else{
                            self.isDragPin = true
                            if isIntersectionFound == true{
                                isOverLapped = true
                            }else{
                                isOverLapped = false
                            }
                            
                            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                            //Polygon pin points
                            for someAnnotation in annotationsToRemove {
                                let strId = "\(zoneCreateModal.id)"
                                if someAnnotation.isKind(of: AnnotationModal.self) {
                                    let annotaion = someAnnotation as! AnnotationModal
                                    if annotaion.info == strId {
                                        self.mapVw.removeAnnotation(someAnnotation)
                                    }
                                }
                            }

                            
                            self.drawPloygon(arrTemp, strTitle: "\(zoneCreateModal.name)", strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true,strCreatedUserId: "\(zoneCreateModal.create_user_id)",willShowDistance:true)
                            
                            if isIntersectionFound == false {
                                var jsonString : NSString = ""
                                do
                                {
                                    let arrJson = try JSONSerialization.data(withJSONObject: arrTemp, options: JSONSerialization.WritingOptions.prettyPrinted)
                                    let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
                                    jsonString = string! as NSString
                                    
                                }
                                catch let error as NSError
                                {
                                    print(error.description)
                                }
                               
                               
                                let creatUrl = "\(KServerUrl)" + "\(kUpdateZone)" + "\(zoneCreateModal.id)"
                                let param = [
                                    "Zone[details]": "\(jsonString)",
                                    "Zone[points]" : "[]"
                                ]
                                
                                KAppDelegate.showActivityIndicator()
                                let reachability = Reachability()
                                if  reachability?.isReachable  == true
                                {
                                    request(creatUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                                        
                                        .responseJSON { response in
                                            do
                                            {
                                                if(response.response?.statusCode == 200)
                                                {
                                                    if let JSONDIC = response.result.value as? NSDictionary{
                                                        if (JSONDIC["status"]! as AnyObject).isEqual("OK")
                                                        {
                                                            //set bool variables
                                                            self.dictUpdateBools.setObject("1", forKey: "\(self.zoneCreateModal.id)" as NSCopying)
                                                            self.isDragPin = true
                                                            self.isUpdate = true
                                                            
                                                            KAppDelegate.hideActivityIndicator()
                                                            proxy.sharedProxy().displayStatusCodeAlert("Zone updated successfully")
                                                        }else{
                                                            
                                                            self.counter = 0
                                                            self.isCompleted = false
                                                            KAppDelegate.hideActivityIndicator()
                                                            let message = JSONDIC["error"] as! String
                                                            proxy.sharedProxy().displayStatusCodeAlert(message)
                                                        }
                                                        
                                                    }else{
                                                        
                                                        proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                                                    }
                                                }
                                                else
                                                {
                                                    KAppDelegate.hideActivityIndicator()
                                                }
                                            }
                                            catch let error as NSError
                                            {
                                                KAppDelegate.hideActivityIndicator()
                                                NSLog("EXCEPTION : %@", error.description)
                                            }
                                    }
                                }
                                else
                                {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().openSettingApp()
                                }
                            }else{
                            
                                proxy.sharedProxy().displayStatusCodeAlert("Please place zone outside the other zone")
                            }
                            
                         
                        }
                    }
                    
                }
              
                
                //this is end
            }
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone ")
        }

        }else{
         proxy.sharedProxy().displayStatusCodeAlert("Please create zone ")
        }
    }
    
    //MARK:- API HIT
    func updateEvent(_ strId:String) {
        var jsonString : NSString = ""
        do
        {
            let arrJson = try JSONSerialization.data(withJSONObject: self.dictMainEventList.object(forKey: strId) as! NSArray, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
        }
        catch let error as NSError
        {
            print(error.description)
        }
        
        let creatUrl = "\(KServerUrl)" + "\(kUpdateZone)" + strId
        let param = [
            "Zone[details]": "\(jsonString)",
            "Zone[points]" : "[]"
        ]
        
        KAppDelegate.showActivityIndicator()
        let reachability = Reachability()
        if  reachability?.isReachable  == true

        {
           request(creatUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do
                    {
                    if(response.response?.statusCode == 200)
                        {
                            if let JSONDIC = response.result.value as? NSDictionary{
                                if (JSONDIC["status"]! as AnyObject).isEqual("OK")
                                {
                                    print(JSONDIC)
                                    //set bool variables
                                    self.dictUpdateBools.setObject("1", forKey: strId as NSCopying)
                                    KAppDelegate.hideActivityIndicator()
                                    //  let message = JSONDIC["message"] as! String
                                    proxy.sharedProxy().displayStatusCodeAlert("Zone updated successfully")
                                }else{
                                    self.showPin = true
                                    self.counter = 0
                                    self.isCompleted = false
                                    KAppDelegate.hideActivityIndicator()
                                    let message = JSONDIC["error"] as! String
                                    proxy.sharedProxy().displayStatusCodeAlert(message)
                                }

                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }
                        }
                        else
                        {
                            KAppDelegate.hideActivityIndicator()
                        }
                    }
                    catch let error as NSError
                    {
                        KAppDelegate.hideActivityIndicator()
                        NSLog("EXCEPTION : %@", error.description)
                    }
            }
        }
        else
        {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
   
    
    //MARK: - Search Action
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar){
        isLandingPointsToBeMarked = false
       // mapVw.removeGestureRecognizer(tapGesture)
        searchBar.text = ""
        self.tableViewPlaces.isHidden = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            let phrase =  self.searchBar.text!
            // range will be nil if no letters is found
            if  proxy.sharedProxy().containsOnlyLetters(phrase) == true {
                // print("letters found")
                self.search_API(phrase)
            }
            else {
                //print("letters not found")
            }
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        self.searchBar.showsCancelButton = true
        let delay = 0.5 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            let phrase =  self.searchBar.text!
            // range will be nil if no letters is found
            if  proxy.sharedProxy().containsOnlyLetters(phrase) == true {
                 self.search_API(phrase)
            }
            else {
            }
        }
    }
    
       
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.text = ""
        self.searchBar.showsCancelButton = false
        self.tableViewPlaces.isHidden = true
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        let delay = 1.0 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            self.searchBar.text = ""
            self.searchBar.showsCancelButton = false
            searchBar.resignFirstResponder()
            self.tableViewPlaces.isHidden = true
        }
    }
    
    
    //MARK: - JSON STRING
    func getJSONString(_ arrTemp:NSArray) -> NSString {
        var jsonString : NSString = ""
        do
        {
            let arrJson = try JSONSerialization.data(withJSONObject: arrTemp, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
            return jsonString
            
        }
        catch _ as NSError
        {
           return jsonString
        }

    }
    
    //MARK: - DELEGATE CREATE ZONE
    func setLocationOfEventOffline(_ strName:String){
        let  arrTemp = NSArray()
        let jsonString : NSString = getJSONString(arrTemp)
        let strGetJSONStringLanding = getJSONString(arrTemp)
       
        let creatUrl = "\(KServerUrl)" + "\(kCreateZone)" + "\(modalEventListOnline.id)"
        let param = [
            "Zone[details]": "\(jsonString)",
            "EventZone[name]": strName,
            "Zone[points]": strGetJSONStringLanding
        ] as [String : Any]
       
        KAppDelegate.showActivityIndicator()
        let reachability = Reachability()
        if  reachability?.isReachable  == true

        {
           request(creatUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do
                    {
                        if(response.response?.statusCode == 200)
                        {
                            if let JSONDIC = response.result.value as? NSDictionary{
                                if (JSONDIC["status"]! as AnyObject).isEqual("OK")
                                {
                                    
                                    let dict = JSONDIC["detail"] as! NSDictionary
                                    let modalEvents = ZoneCreateModal()
                                    modalEvents.id = Int32(((dict["id"] as! NSNumber).intValue))
                                    modalEvents.name = dict["name"] as! String
                                    modalEvents.zones = dict["points"] as! NSArray
                                    modalEvents.create_user_id = Int32(((dict["create_user_id"] as! NSNumber).intValue))
                                    modalEvents.create_user_name = dict["create_user_name"] as! String
                                    let arrEvent = NSMutableArray()
                                    arrEvent.add(modalEvents)
                                    arrEvent.addObjects(from: self.arrEventsList as [AnyObject])
                                    self.arrEventsList = arrEvent.mutableCopy() as! NSMutableArray
                                    
                                    //set bool variables
                                    self.dictUpdateBools.setObject("0", forKey: "\(modalEvents.id)" as NSCopying)
                                    //Set Main dictionary list
                                    self.dictMainEventList.setObject(arrTemp, forKey: "\(modalEvents.id)" as NSCopying)
                                    
                                    // self.arrEventsList.addObject(modalEvents)
                                    if self.arrEventsList.count > 0 {
                                        self.tableViewEventList.reloadData()
                                    }
                                    KAppDelegate.hideActivityIndicator()
                                    let message = JSONDIC["message"] as! String
                                    proxy.sharedProxy().displayStatusCodeAlert(message)
                                }else{
                                    KAppDelegate.hideActivityIndicator()
                                    let message = JSONDIC["error"] as! String
                                    proxy.sharedProxy().displayStatusCodeAlert(message)
                                }

                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }
                        }
                        else
                        {
                            KAppDelegate.hideActivityIndicator()
                        }
                    }
                    catch let error as NSError
                    {
                        KAppDelegate.hideActivityIndicator()
                        NSLog("EXCEPTION : %@", error.description)
                    }
            }
        }
        else
        {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
   
    
    
    //MARK:- DRAW POLYGON
    func drawPloygon(_ arrDrawAreaZones:NSArray,strTitle:String,strZoneId: String,willShowAnnotaion: Bool,strCreatedUserId: String,willShowDistance: Bool)  {
        let arrDrawAreaCoordinate = NSMutableArray()
        var annotationArrayTemp = [MKAnnotation]()
        let arrTemp = arrDrawAreaZones
        let event_id = strZoneId
        let event_name = strTitle
        var userLoc1 = CLLocationCoordinate2D()
        for i in 0 ..< arrTemp.count{
            var dict = NSDictionary()
            dict = arrTemp[i] as! NSDictionary
            let lat = dict["lat"] as! String
            let long = dict["longt"] as! String
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            userLoc1.latitude = Double(newLat)!
            userLoc1.longitude = Double(newLong)!
            if willShowDistance == true {
                let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "",isShowDistance: willShowDistance)
                let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
                if willShowAnnotaion == true {
                  
                }
                annotationArrayTemp.append(annotation)
                arrDrawAreaCoordinate.add(loc)

            }else{
                let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "",isShowDistance: willShowDistance)
                let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
                if willShowAnnotaion == true {
                  
                }
                annotationArrayTemp.append(annotation)
                arrDrawAreaCoordinate.add(loc)
                
            }
    }
        if arrDrawAreaCoordinate.count > 0
        {
            if willShowAnnotaion == true {
                 self.placeDividerMarker(strZoneName: zoneCreateModal.name, zoneCreateId: zoneCreateModal.id)
            }
            debugPrint("Coordinate: ",arrDrawAreaCoordinate)
            self.annotationAry = annotationArrayTemp
            let numberOfSteps: Int =  arrDrawAreaCoordinate.count
            var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
            let firstLocation =  arrDrawAreaCoordinate[0] as! CLLocation
            for index in 0 ..< numberOfSteps
            {
                let location: CLLocation =  arrDrawAreaCoordinate[index] as! CLLocation
                points.append(location.coordinate)
            }
            NSLog("ARRAY COORDINATES:%d",points.count)
            points.append(firstLocation.coordinate)
            let polygon = MKPolygon(coordinates: &points, count: points.count)
            polygon.title = strTitle
            print("Polygon name : \(polygon.title!) and center coordinate: \(polygon.coordinate)")
            
            polygon.subtitle = strCreatedUserId
            mapVw.add(polygon)
            self.dictPolygon.setObject(polygon, forKey: strZoneId as NSCopying)
            let centerCoordinate = proxy.sharedProxy().getCenterCoord(points)
            if homeLocationOfUser.latitude == 0.0 && homeLocationOfUser.longitude == 0.0 {
                  homeLocationOfUser = self.mapVw.userLocation.coordinate
            }
          
            if CLLocationCoordinate2DIsValid(homeLocationOfUser) {
                if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)) == true{
                    if willShowDistance == true {
                        self.isShowDistance = true
                    }
                    
                }else{
                    self.isShowDistance = false
                }
            }

            points.removeLast()
           
            for i in 0 ..< points.count
            {
                let location: CLLocation =  arrDrawAreaCoordinate[i] as! CLLocation
                let coordinate₀ = CLLocation(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)
                let coordinate₁ = CLLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
                let distanceInMeters = Float(proxy.sharedProxy().getDistanceInm(coordinate₀, from: coordinate₁))
                let distance =  String(format: "%0.2f m",distanceInMeters)
                debugPrint("Distance from home location:",distance)
                if willShowDistance == true {
                    let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "\(distance)",isShowDistance: willShowDistance)
                    if willShowAnnotaion == true {
                         mapVw.addAnnotation(annotation)
                    }
                }else{
                    let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "\(distance)",isShowDistance: willShowDistance)
                    if willShowAnnotaion == true {
                         mapVw.addAnnotation(annotation)
                    }
                }
            }
            
            self.dictCenterCoordinatesPolygons.setObject(centerCoordinate, forKey: strZoneId as NSCopying)
            let annotation = ZoneNameAnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: centerCoordinate.latitude, longitude: centerCoordinate.longitude ), info: "\(event_id)",index: "")
            self.mapVw.addAnnotation(annotation)
            showPin = false
            isCompleted = true
             debugPrint("Center point coordinates: ",dictCenterCoordinatesPolygons)
        }else{
            var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
            let polygon = MKPolygon(coordinates: &points, count: points.count)
            self.dictPolygon.setObject(polygon, forKey: strZoneId as NSCopying)
            self.dictCenterCoordinatesPolygons.setObject(kCLLocationCoordinate2DInvalid, forKey: strZoneId as NSCopying)
        }
    }
   /**
      Find center coordinates between two location coordinates of edges
     */
    
    func placeDividerMarker(strZoneName:String,zoneCreateId:Int32) {
        
        //1.Get all the edge coordinates
        let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
        if arrTemp.count > 0{
    
    for i in 0..<arrTemp.count {
            //GET LOCATION COORDINATES
        if i < arrTemp.count-1 {
            let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i] as! NSMutableDictionary)
                let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i+1] as! NSMutableDictionary)
            let centerCoordinates = proxy.sharedProxy().findCenterPoint(dronePosA, loc2: dronePosB)
            let annotation = DividerAnnotation.init(title: strZoneName, coordinate: centerCoordinates, info: "\(zoneCreateId)", nextIndex: "\(i+1)", prevIndex: "\(i)")
            self.mapVw.addAnnotation(annotation)
            
        }else{
            let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[0] as! NSMutableDictionary)
            let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[arrTemp.count - 1] as! NSMutableDictionary)
            let centerCoordinates = proxy.sharedProxy().findCenterPoint(dronePosA, loc2: dronePosB)
            let annotation = DividerAnnotation.init(title: strZoneName, coordinate: centerCoordinates, info: "\(zoneCreateId)", nextIndex: "\(0)", prevIndex: "\(arrTemp.count - 1)")
            self.mapVw.addAnnotation(annotation)
            
              }
            }
        }
    }

    
    //MARK: - API Hit
    func search_API( _ searchText:String){
        
        let trimmedText = searchText.replacingOccurrences(of: " ", with: "%20")
        let apiAddress = "\(googleBaseURL)"+"place/textsearch/json?query="
       // let apiAddress = "\(googleBaseURL)"
        let searchAddress = apiAddress + trimmedText + apiKey
        hitURL =  "SearchPlace"
        NSLog("searchAdd %@", searchAddress)
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            // KAppDelegate.showActivityIndicator()
            request(searchAddress, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:nil)
                .responseJSON { response in
                    do {
                        // KAppDelegate.hideActivityIndicator()
                        if(response.response?.statusCode == 200) {
                            if let JSON = response.result.value as? NSDictionary{
                                self.serviceResponsePlace(JSON .mutableCopy() as! NSMutableDictionary)
                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }
                           
                        }else {
                            proxy.sharedProxy().stautsHandler(searchAddress, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                        }
                    } catch let error as NSError {
                        // KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().displayStatusCodeAlert(error.description)
                    }
            }
        }else {
                proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponsePlace(_ JSON:NSMutableDictionary) {
        if(hitURL ==  "SearchPlace") {
            if (JSON["status"]! as AnyObject).isEqual("OK")
            {
                let resultsArray = JSON["results"] as! NSArray
             //   NSLog("Address %@", resultsArray)
                self.locationArray.removeAllObjects()
                for i in 0 ..< resultsArray.count {
                    var dict = NSMutableDictionary()
                    dict = (resultsArray[i] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                    let locationDict = NSMutableDictionary()
                    locationDict.setValue("\(dict["formatted_address"]!)", forKey: "sub_Address" )
                    locationDict.setValue("\(dict["formatted_address"]!)", forKey: "name" )
                    let strlat = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lat") as! NSNumber
                    let strlong = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lng") as! NSNumber

                    locationDict.setValue(strlat, forKey: "lat")
                    locationDict.setValue(strlong, forKey: "lng")
                    self.locationArray.add(locationDict)
                }
                let delay = 0.1 * Double(NSEC_PER_SEC)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                    if self.locationArray.count > 0 {
                        self.tableViewPlaces.reloadData()
                    }
                    self.hitURL =  ""
                }
            }
            else
            {
                let errorMessage = JSON["status"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
        }
    }
    
    
    func getEventZone()  {
        
        var newUserLoc = CLLocationCoordinate2D()
        let newLat1 = self.modalEventListOnline.lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let newLong2 = self.modalEventListOnline.long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        if newLat1.characters.count > 0 && newLong2.characters.count > 0 {
            newUserLoc.latitude = Double(newLat1)!
            newUserLoc.longitude = Double(newLong2)!
            
            // convert center coordiate to pixel space
            let centerPixelX = longitudeToPixelSpaceX(userLoc.longitude)
            let centerPixelY = latitudeToPixelSpaceY(userLoc.latitude)
            let zoomLevel = 8.0
            // determine the scale value from the zoom level
            let zoomExponent:Double =  zoomLevel
            let zoomScale:Double = pow(2.0, zoomExponent)
            
            // scale the map’s size in pixel space
            let mapSizeInPixels = self.mapVw.bounds.size
            let scaledMapWidth = Double(mapSizeInPixels.width) * zoomScale
            let scaledMapHeight = Double(mapSizeInPixels.height) * zoomScale
            
            // figure out the position of the top-left pixel
            let topLeftPixelX = centerPixelX - (scaledMapWidth / 2.0)
            let topLeftPixelY = centerPixelY - (scaledMapHeight / 2.0)
            
            // find delta between left and right longitudes
            let minLng = pixelSpaceXToLongitude(topLeftPixelX)
            let maxLng = pixelSpaceXToLongitude(topLeftPixelX + scaledMapWidth)
            let longitudeDelta = maxLng - minLng
            
            let minLat = pixelSpaceYToLatitude(topLeftPixelY)
            let maxLat = pixelSpaceYToLatitude(topLeftPixelY + scaledMapHeight)
            let latitudeDelta = -1.0 * (maxLat - minLat)
            let span =  MKCoordinateSpan(latitudeDelta: latitudeDelta, longitudeDelta: longitudeDelta)
            let region = MKCoordinateRegion(center: newUserLoc, span: span)
            self.mapVw.setRegion(region, animated: true)
        }else{
            if UserDefaults.standard.object(forKey: "lat") != nil {
                let lat =  UserDefaults.standard.object(forKey: "lat") as! String
                let long = UserDefaults.standard.object(forKey: "long") as! String
                var userLoc = CLLocationCoordinate2D()
                userLoc.latitude = CDouble(lat)!
                userLoc.longitude = CDouble(long)!
                let span = MKCoordinateSpanMake(0.02, 0.02)
                let region = MKCoordinateRegion(center: userLoc, span: span)
                mapVw.setRegion(region, animated: true)
                mapVw.showsUserLocation = true
               homeLocationOfUser = userLoc
            }
        }
        
       // KAppDelegate.showActivityIndicator()
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kGetEventZone)" + "\(modalEventListOnline.id)"
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
               // KAppDelegate.hideActivityIndicator()
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    let infoDict = responseDict["event"] as! NSDictionary
                    let arrAllZones =  infoDict["zones"] as! NSArray
                    var userLoc1 = CLLocationCoordinate2D()
                    let userId  = UserDefaults.standard.object(forKey: "id") as! Int
                    let arrUserZonesList = NSMutableArray()
                    let arrOtherUserList = NSMutableArray()
                    for i in 0 ..< arrAllZones.count{
                        //Main dictionary for all zones
                        let arrTempZones = NSMutableArray()
                        var dictForPoints = NSDictionary()
                        dictForPoints = arrAllZones[i] as! NSDictionary
                        // Make ZoneCreate modal
                        let modalZoneCreate =  ZoneCreateModal()
                        modalZoneCreate.id =  Int32(((dictForPoints["id"] as! NSNumber).intValue))
                        modalZoneCreate.name = dictForPoints["name"] as! String
                        modalZoneCreate.create_user_id = Int32(((dictForPoints["create_user_id"] as! NSNumber).intValue))
                        modalZoneCreate.create_user_name = dictForPoints["create_user_name"] as! String
                        
                        //Setup main zones array list
                        //Get all points
                        let arrPoints = dictForPoints["points"] as! NSArray
                        let nameDescriptor: NSSortDescriptor = NSSortDescriptor(key: "id", ascending: true)
                        let sortDescriptors = [nameDescriptor]
                        let arrTemp = arrPoints.sortedArray(using: sortDescriptors ) as NSArray
                        let zone_id = Int32(((dictForPoints["id"] as! NSNumber).intValue))
                        let strName = dictForPoints["name"] as! String
                        print(strName)
                        if i == 0{
                            self.firstModal = modalZoneCreate
                            self.zoneCreateModal = self.firstModal
                        }
                       
                        //Setup main zones array list
                        for j in 0 ..< arrTemp.count{
                        let dict = arrTemp[j] as! NSDictionary
                            let lat = dict["lat"] as! String
                            let long = dict["longt"] as! String
                            let min_alt = dict["min_alt"] as! String
                            let max_alt = dict["max_alt"] as! String
                            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                            userLoc1.latitude = Double(newLat)!
                            userLoc1.longitude = Double(newLong)!
                            let annotation = AnnotationModal(title: strName, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(zone_id)",index: "\(j+1)",distnaceFromHomeLocation: "",isShowDistance: false)
                            if  j == 0{
                                self.annotationAry.append(annotation)
                                if arrTempZones.count > 0{
                                    self.isCompleted = true
                                }else{
                                    self.isCompleted = false
                                }
                            }
                           
                            let dictZoneInfo = NSMutableDictionary()
                            dictZoneInfo.setObject(lat, forKey: "lat" as NSCopying)
                            dictZoneInfo.setObject(long, forKey: "longt" as NSCopying)
                            dictZoneInfo.setObject(min_alt, forKey: "min_alt" as NSCopying)
                            dictZoneInfo.setObject(max_alt, forKey: "max_alt" as NSCopying)
                            arrTempZones.add(dictZoneInfo)
                        }
                        
                        if Int32(userId) == modalZoneCreate.create_user_id{
                             modalZoneCreate.zones = arrTempZones as NSArray
                            arrUserZonesList.add(modalZoneCreate)
                            self.dictMainEventList.setObject(arrTempZones as NSArray, forKey: "\(zone_id)" as NSCopying)
                            
                            if arrTempZones.count > 0{
                                //set bool variables
                                self.dictUpdateBools.setObject("1", forKey: "\(zone_id)" as NSCopying)
                                let span = MKCoordinateSpanMake(0.025, 0.025)
                                let region = MKCoordinateRegion(center: userLoc1, span: span)
                                self.mapVw.setRegion(region, animated: true)
                                //self.drawPloygon(self.dictMainEventList.objectForKey("\(zone_id)") as! NSArray, strTitle: "\(modalZoneCreate.name)")
                                self.drawPloygon(arrTempZones, strTitle: "\(modalZoneCreate.name)", strZoneId: "\(modalZoneCreate.id)", willShowAnnotaion: false,strCreatedUserId: "\(modalZoneCreate.create_user_id)",willShowDistance:false)
                                
                            }else{
                                //set bool variables
                                self.dictUpdateBools.setObject("0", forKey: "\(zone_id)" as NSCopying)
                            }

                        }else{
                            modalZoneCreate.zones = arrTempZones as NSArray
                            arrOtherUserList.add(modalZoneCreate)
                            if arrTempZones.count > 0{
                                //set bool variables
                                let span = MKCoordinateSpanMake(0.025, 0.025)
                                let region = MKCoordinateRegion(center: userLoc1, span: span)
                                self.mapVw.setRegion(region, animated: true)
                                self.drawPloygon(arrTempZones, strTitle: "\(modalZoneCreate.name)", strZoneId: "\(modalZoneCreate.id)", willShowAnnotaion: false,strCreatedUserId: "\(modalZoneCreate.create_user_id)",willShowDistance:false)
                            }
                        }
                        
                    }
                    if arrUserZonesList.count > 0{
                        self.arrEventsList.addObjects(from: arrUserZonesList as [AnyObject])
                    }
                    
                    if arrOtherUserList.count > 0 {
                        self.arrEventsList.addObjects(from: arrOtherUserList as [AnyObject])
                    }
                    
                    if self.arrEventsList.count > 0{
                        self.tableViewEventList.reloadData()
                    }
                    
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
                
            }) { (error) in
               
                if error.localizedDescription.characters.count > 0{
                let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.getEventZone()
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
        
    }
    
    func setUpUI()  {
        vwSimulatorControl.isHidden = true
        vwSimulatorControl.layer.cornerRadius = 8
        vwDataFromDrone.layer.cornerRadius = 8.0
        cnstHelipadPops.constant = 0
        virtualStickLeft.isHidden = true
        virtualStickRight.isHidden = true
        vwDataFromDrone.isHidden = true
       
        //Initail left stick
        lblYPositiveLeftStick.layer.borderWidth = 1.0
        lblYPositiveLeftStick.layer.borderColor = UIColor.black.cgColor
        lblXPosPositionLeftStick.layer.borderWidth = 1.0
        lblXPosPositionLeftStick.layer.borderColor = UIColor.black.cgColor
       
        //Initial right stick
        lblYPosRight.layer.borderWidth = 1.0
        lblYPosRight.layer.borderColor = UIColor.black.cgColor
        lblXPosRight.layer.borderWidth = 1.0
        lblXPosRight.layer.borderColor = UIColor.black.cgColor
    
        //Initial velocity 
        lblYAircraftVelocity.layer.borderWidth = 1.0
        lblYAircraftVelocity.layer.borderColor = UIColor.black.cgColor
        lblXAircraftVelocity.layer.borderWidth = 1.0
        lblXAircraftVelocity.layer.borderColor = UIColor.black.cgColor
        //Initial z above ground
        lblZAboveGround.layer.borderWidth = 1.0
        lblZAboveGround.layer.borderColor = UIColor.black.cgColor
    }
    
   
    
     func refreshList(_ notification: NSNotification) {
        if let dictDetails = notification.object as? NSDictionary {
           debugPrint("GEt userdata:",dictDetails)
            trackerId = dictDetails.object(forKey: "uid") as! String
            let lat = dictDetails["lat"] as! String
            let long = dictDetails["longt"] as! String
       
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            trackerLocationCoordinates.latitude = Double(newLat)!
            trackerLocationCoordinates.longitude = Double(newLong)!
           
            if current_altitude > 0 {
                //Send status is_Tracking = true
                let alertController = UIAlertController(title: "Track User", message: "New user found,Do you want to track user?", preferredStyle: .alert)
                let retryAction = UIAlertAction(title: "Yes", style: .default, handler: {
                    action in
                    
                    let statusURL = "\(KServerUrl)" + "\(kLockedConfirmationZone)" + "\(self.zoneCreateModal.id)"
                    let param = [
                        "EventZone[uid]":"\(self.trackerId)",
                        "EventZone[is_locked]":"1"
                    ]
                    self.postTrackingConfirmation(statusURL, postParam: param as Dictionary<String, AnyObject>)
                    self.pubNubClientSetup()
                    self.client.subscribeToChannels(self.arrPubNubChannels, withPresence: false)
                })
                //Send status is_Tracking = false
                let cancelAction = UIAlertAction(title: "No", style: .default, handler: {
                    action in
                    let statusURL = "\(KServerUrl)" + "\(kLockedConfirmationZone)" + "\(self.zoneCreateModal.id)"
                    let param = [
                        "EventZone[uid]":"\(self.trackerId)",
                        "EventZone[is_locked]":"0"
                    ]
                    self.postTrackingConfirmationNO(statusURL, postParam: param as Dictionary<String, AnyObject>)
                } )
                alertController.addAction(retryAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please take-off drone to track user")
            }
        }
    }
    
    
    func postTrackingConfirmationNO(_ url: String,postParam: Dictionary<String, AnyObject>)  {
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
            request(url, method: .post, parameters: postParam, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do
                    {
                        if(response.response?.statusCode == 200)
                        {
                            if let JSONDIC = response.result.value as? NSDictionary{
                                debugPrint("Get data:",JSONDIC)
                                if (JSONDIC["status"]! as AnyObject).isEqual("OK")
                                {
                                    debugPrint("Get data from tracker:",JSONDIC)
                                    self.trackerId = ""
                                }
                            }
                        }
                    }
                    catch let error as NSError
                    {
                        
                        NSLog("EXCEPTION : %@", error.description)
                    }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }

    
    
    func postTrackingConfirmation(_ url: String,postParam: Dictionary<String, AnyObject>)  {
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
            request(url, method: .post, parameters: postParam, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do
                    {
                        if(response.response?.statusCode == 200)
                        {
                            if let JSONDIC = response.result.value as? NSDictionary{
                                debugPrint("Get data:",JSONDIC)
                                if (JSONDIC["status"]! as AnyObject).isEqual("OK")
                                {
                                    debugPrint("Get data from tracker:",JSONDIC)
                                    self.createMission()
                                }
                            }
                        }
                    }
                    catch let error as NSError
                    {
                        NSLog("EXCEPTION : %@", error.description)
                    }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    func createMission() {
        if let flightController = DroneUtility.fetchFlightController(){
            let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
            if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: trackerLocationCoordinates.latitude, longitude: trackerLocationCoordinates.longitude)) == true{
                if CLLocationCoordinate2DIsValid(self.trackerLocationCoordinates) {
                    let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
                    let stepsToGo = DJIGoToStep.init(coordinate: self.trackerLocationCoordinates, altitude: min_height)
                    let customMission = DJICustomMission.init(steps: [stepsToGo!])
                    DJIMissionManager.sharedInstance()!.prepare(customMission!, withProgress: { (value) in
                    }, withCompletion: { (error) in
                        if error?.localizedDescription.characters.count > 0{
                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                            if self.trackerId.characters.count > 0{
                            let statusURL = "\(KServerUrl)" + "\(kLockedConfirmationZone)" + "\(self.zoneCreateModal.id)"
                            let param = [
                                "EventZone[uid]":"\(self.trackerId)",
                                "EventZone[is_locked]":"0"
                            ]
                            self.postTrackingConfirmationNO(statusURL, postParam: param as Dictionary<String, AnyObject>)
                            }
                        }else{
                            DJIMissionManager.sharedInstance()!.startMissionExecution(completion: { (error) in
                                if error?.localizedDescription.characters.count > 0{
                                }
                            })
                        }
                    })
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("User is outside the zone")
            }
            
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    
    
    //MARK: - ViewController lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
//    if  let waypointView: UIView? = Bundle.main.loadNibNamed("WaypointUploadingAlertView", owner: self, options: nil)?[0] as? WaypointUploadingAlertView{
//            waypointView?.frame = vwSearchBar.frame
//            self.view.addSubview(waypointView!)
//        }

       UIDevice.current.isBatteryMonitoringEnabled = true
        self.isSelfIntersecting = false
      UIApplication.shared.isIdleTimerDisabled = true
      self.cnstGridMissionSetup.constant = -167.0
        self.btnfpvFullScreenOverlay.isHidden = true
        self.cnstfpvFullScreen.constant = 0.0
         self.fpvTempView.isHidden = true
        self.waypointTargetCoordinate = kCLLocationCoordinate2DInvalid
        //Testing constant
        self.vwTestingConstant.isHidden = true
        //waypoint view
        self.cnstWaypointMissionViewTrailingSpace.constant = -124.0
          userId  = UserDefaults.standard.object(forKey: "id") as! Int
        //New user found
        //    you need to add an observer at your view controller you need to add ":" here to pass the NSNotification object
      //  NotificationCenter.default.addObserver(self, selector: #selector(CreateZoneOnlineVC.refreshList(_:)), name: NSNotification.Name(rawValue: "userFound"), object: nil)
       // NotificationCenter.default.addObserver(self, selector: #selector(reinstateBackgroundTask), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
        self.btnStartTracking.isHidden = true
        self.lblTransmissionTime.text = "I/O Time: 0.0 sec"
        self.lblTransmissionTime.isHidden = true
        self.droneLocationCoordinate = kCLLocationCoordinate2DInvalid
        isLandingPointsToBeDeleted = false
        isPinPointsToBeDeleted = false
        self.setUpUI()
        self.flightControlSetup()
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = true
        cnstVwSettings.constant = 0
        cnstVwSettingsBottom.constant = 30
        isCompleted = false
        
        //For TapGesture Recognization
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(CreateZoneOnlineVC.recognizeTapGesture(_:)))
        mapVw.addGestureRecognizer(tapGesture)
        tapGesture.delegate = self
        self.showPin = false
        mapVw.mapType = .satellite
        self.mapVw.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
            let span = MKCoordinateSpanMake(0.025, 0.025)
            let region = MKCoordinateRegion(center: userLoc, span: span)
            mapVw.setRegion(region, animated: true)
            mapVw.showsUserLocation = true
            homeLocationOfUser = userLoc
        }
        isLandingPointsOutside = false
        self.getEventZone()
        
       
        
    }
    
    func testingPubNub() {
        if self.client != nil {
            let messageDict = NSMutableDictionary()
            let test_location = CLLocationCoordinate2DMake(30.7121365939565, 76.7101874026764)
            messageDict.setObject(test_location.latitude, forKey: "lat" as NSCopying)
            messageDict.setObject(test_location.longitude, forKey: "lng" as NSCopying)
            messageDict.setObject(userId, forKey: "id" as NSCopying)
            messageDict.setObject(Float(0.6), forKey: "heading" as NSCopying)
            messageDict.setObject(Int(1), forKey: "state_id" as NSCopying)
            messageDict.setObject(self.isWayPointFromWebStarted, forKey: "isWayPointFromWebStarted" as NSCopying)
            self.client.publish(messageDict, toChannel: "\(self.zoneCreateModal.name)_for_tracker",
                compressed: false, withCompletion: { (status) in
                    if !status.isError {
                         print("Success \(self.zoneCreateModal.name)_for_tracker : data sent")
                    }
                    else{
                         print("Success \(self.zoneCreateModal.name)_for_tracker : \(status.errorData)")
                        /**
                         Handle message publish error. Check 'category' property to find
                         out possible reason because of which request did fail.
                         Review 'errorData' property (which has PNErrorData data type) of status
                         object to get additional information about issue.
                         Request can be resent using: status.retry()
                         */
                    }
            })
            
            self.client.publish(messageDict, toChannel: "\(self.modalEventListOnline.name)_drones",
                compressed: false, withCompletion: { (status) in
                    if !status.isError {
                        print("Success \(self.modalEventListOnline.name)_drones : data sent")
                    }
                    else{
                        print("Success \(self.modalEventListOnline.name)_drones : \(status.errorData)")
 
                        /**
                         Handle message publish error. Check 'category' property to find
                         out possible reason because of which request did fail.
                         Review 'errorData' property (which has PNErrorData data type) of status
                         object to get additional information about issue.
                         Request can be resent using: status.retry()
                         */
                    }
            })

        }
    }
    
    func flightControlSetup() {
        //Flight control setUp
        virtualStickLeft.layer.cornerRadius = 64
        virtualStickRight.layer.cornerRadius = 64
        btnReadyToFly.layer.cornerRadius = 5
        btnReadyToFly.layer.borderWidth = 1
        btnReadyToFly.layer.borderColor = UIColor.white.cgColor
        NotificationCenter.default.addObserver(self, selector: #selector(CreateZoneOnlineVC.onStickChanged(notification:)) , name: NSNotification.Name(rawValue: "StickChanged"), object: nil)
    }
    
    
    func onStickChanged(notification:NSNotification) {
        let dict = notification.userInfo! as NSDictionary
        let vdir = dict.object(forKey: "dir") as! NSValue
        let dir = vdir.cgPointValue
        if let  virtualStick = (notification.object! as? VirtualStickView){
            if virtualStick == self.virtualStickLeft {
                self.setThrottle(Float(dir.y), andYaw: Float(dir.x))
            }
            else {
                self.setXVelocity(-(Float)(dir.y), andYVelocity: Float(dir.x))
            }
        }
    }
    
    @IBAction func btnPrssActionDone(_ sender: AnyObject) {
         isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isPlacePolygon = true
        isAltitude = false
        isDrawPolygon = false
        isDeletePolygon = false
        //Place polygon
        
        if UserDefaults.standard.object(forKey: "lat") != nil &&  UserDefaults.standard.object(forKey: "long") != nil{
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
            if CLLocationCoordinate2DIsValid(userLoc){
                let span = MKCoordinateSpanMake(0.001, 0.001)
                let region = MKCoordinateRegion(center: userLoc, span: span)
                mapVw.setRegion(region, animated: true)
                mapVw.showsUserLocation = true
            }
        }

        
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if Int32(userId) == zoneCreateModal.create_user_id || zoneCreateModal.create_user_id == 0 {
            isDragToPoint = true
            isLandingPointsToBeMarked = false
            if zoneCreateModal.id != 0 {
            let arrTemp = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
                if arrTemp.count == 0 {
                    showPin = true
                    counter = 0
                }else{
                    showPin = false
                    counter = 0
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }
        }
    }
    
    @IBOutlet weak var btnPrssDone: UIButton!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func registerApp(isReigster:Bool) {
        if isReigster == true {
            let strId = NSString(format: "7e438c239538748342a26574")
            debugPrint("strid : ",strId)
            DJISDKManager.registerApp(strId as String, with: self)
            self.missionManager = DJIMissionManager.sharedInstance()!
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        self.registerApp(isReigster: willRegisterApp)
        // self.reinstateBackgroundTask()
        if(UIDevice.current.orientation == .landscapeLeft || UIDevice.current.orientation == .landscapeRight || UIDevice.current.orientation == .unknown || UIDevice.current.orientation == .faceUp || UIDevice.current.orientation == .faceDown)
        {
            debugPrint("landscape")
        }else{
        UIDevice.current.setValue(UIInterfaceOrientation.landscapeLeft.rawValue, forKey: "orientation")
        }
        vwEventsLists.isHidden = true
    
        //set bool variable
        self.navigationController?.isNavigationBarHidden = true
        isPlacePolygon = false
        isAltitude = false
        isDrawPolygon = false
        isDeletePolygon = false
        self.view.bringSubview(toFront: vwSeparateAltitude)
        tableViewPlaces.backgroundColor = UIColor.clear
        tableViewPlaces.dataSource=self
        tableViewPlaces.delegate=self
        self.tableViewPlaces.isHidden = true
        self.view.bringSubview(toFront: tableViewPlaces)
        selectedIndexPath = IndexPath(row: 0, section: 0)
        isDragToPoint = true
        isUpdate = false
        self.isDragPin = false
       
        //bool set
        lblUserName.text = modalEventListOnline.create_user_name
        lblOnlineGroupName.text = modalEventListOnline.group_name
        lblEventName.text = modalEventListOnline.name
       
        //set images
        btnDrawEdit.setImage(UIImage(named: "path_heli"), for: UIControlState())
        btnEditOutlet.setImage(UIImage(named: "altitude"), for: UIControlState())
        btnDone.setImage(UIImage(named: "tickSettings"), for: UIControlState())
        btnDeleteZone.setImage(UIImage(named: "deleteZone"), for: UIControlState())
        strCurrentEventId = "\(modalEventListOnline.id)"
        vwSeparateAltitude.isHidden = true
        vwChooseAltitude.isHidden = true
        vwCollectiveAltitudes.isHidden = true
        counter = 0
        self.missionManager.delegate = self
        self.pubNubClientSetup()
       
    }
  
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
          UIApplication.shared.isIdleTimerDisabled = false
    }
    
    
    
    func convertedPoints(_ containingPoint:CGPoint,containerView:UIView) -> CGPoint {
        print("Previuos point: \(containingPoint)")
        let point = self.mapVw.convert(containingPoint, from: containerView)
        print("Next point: \(point)")
        return point
    }
    
    func didPan(_ panGR: UIPanGestureRecognizer) {
        self.mapVw.bringSubview(toFront: self.vw)
        //Set transformation
        var translation = panGR.translation(in: self.mapVw)
        translation = translation.applying(self.mapVw.transform)
        self.vw.center.x += translation.x
        self.vw.center.y += translation.y
        panGR.setTranslation(CGPoint.zero, in: self.mapVw)
        print("coordinates x: \(vw.frame.origin.x) y: \(vw.frame.origin.y)")
        
        self.mapVw.isUserInteractionEnabled = false;
        
        if panGR.state == .ended {
            self.mapVw.isUserInteractionEnabled = true;
            let arrZones = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
            let arrPoints = NSMutableArray()
            let arrLocationCoordinates = NSMutableArray()
            var zoneLoc = CLLocationCoordinate2D()
            
            //Convert lat and longitude to x and y pos of zone
            for i in 0 ..< arrZones.count {
                let dict = arrZones[i] as! NSMutableDictionary
                let lat = dict["lat"] as! String
                let long = dict["longt"] as! String
                let min_height = Int32(((dict["min_alt"] as! NSString).intValue))
                let max_height = Int32(((dict["max_alt"] as! NSString).intValue))
                let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                zoneLoc.latitude = Double(newLat)!
                zoneLoc.longitude = Double(newLong)!
                let point = self.mapVw.convert(zoneLoc, toPointTo: self.mapVw)
                let dictPoints = NSMutableDictionary()
                dictPoints.setObject(vw.frame.origin.x+point.x, forKey: "xPos" as NSCopying)
                dictPoints.setObject(vw.frame.origin.y+point.y, forKey: "yPos" as NSCopying)
                dictPoints.setObject("\(min_height)", forKey: "min_alt" as NSCopying)
                dictPoints.setObject("\(max_height)", forKey: "max_alt" as NSCopying)
                arrPoints.add(dictPoints)
            }
            
            //convert x and y position to coordinates
            for i in 0 ..< arrPoints.count {
                let dict = arrPoints[i] as! NSMutableDictionary
                let xPos =  Int32(Float(dict["xPos"] as! NSNumber))
                let yPos =  Int32(Float(dict["yPos"] as! NSNumber))
                let min_height = Int32(((dict["min_alt"] as! NSString).intValue))
                let max_height = Int32(((dict["max_alt"] as! NSString).intValue))
                let point = CGPoint(x: CGFloat(xPos), y: CGFloat(yPos))
                let locationCoordinate = mapVw.convert(point,toCoordinateFrom: mapVw)
                let dictCoordinates = NSMutableDictionary()
                dictCoordinates.setObject("\(locationCoordinate.latitude)", forKey: "lat" as NSCopying)
                dictCoordinates.setObject("\(locationCoordinate.longitude)", forKey: "longt" as NSCopying)
                dictCoordinates.setObject("\(min_height)", forKey: "min_alt" as NSCopying)
                dictCoordinates.setObject("\(max_height)", forKey: "max_alt" as NSCopying)
                arrLocationCoordinates.add(dictCoordinates)
            }
           
            let userId  = UserDefaults.standard.object(forKey: "id") as! Int
            linePath.removeAllPoints()
           
            self.dictMainEventList.setObject(arrLocationCoordinates, forKey: "\(zoneCreateModal.id)" as NSCopying)
          
            //make new polygon
            let arrPolygonPoints = proxy.sharedProxy().getCllocationCoordinate2d(arrLocationCoordinates)
            var pointsPolygon = proxy.sharedProxy().makeCoordinatePoints(arrPolygonPoints)
            //check is inside
            let firstLocation =  arrPolygonPoints[0] as! CLLocation
            pointsPolygon.append(firstLocation.coordinate)
           
            let polygon = MKPolygon(coordinates: &pointsPolygon, count: pointsPolygon.count)
            self.dictPolygon.setObject(polygon, forKey: "\(zoneCreateModal.id)" as NSCopying)

            //check current polygon with other polygons
            var isIntersectionFound = false
            var isHeightIntersected = false
             let arrTemp =  self.dictMainEventList.object(forKey:  "\(zoneCreateModal.id)") as! NSArray
            if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
                let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "minimum_height") as! Float
                let current_max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "maximum_height") as! Float
                for i in 0..<self.arrEventsList.count{
                    let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                    if zoneCreateModal.id != modalEvent.id {
                        let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                        if arrTempOther.count > 0 {
                            let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                            let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                            let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTempOther).object(forKey: "minimum_height") as! Float
                            let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTempOther).object(forKey: "maximum_height") as! Float
                           
                            //Find Height intersection
                            //case 0:
                            if current_min_height >= min_height  && current_max_height <= min_height{
                                isHeightIntersected = true
                            }
                            //case 1:
                            if current_min_height <= min_height && current_max_height >= max_height {
                                isHeightIntersected = true
                            }else{
                                if current_max_height >= min_height && current_max_height <= max_height {
                                    isHeightIntersected = true
                                }
                            }
                            
                            if somePolygon!.pointCount > 0 {
                             if  isHeightIntersected == true {
                                    isIntersectionFound = true
                                }
                                break
                            }
                        }
                    }
                }
            }

            if isIntersectionFound == true{
                isOverLapped = true
            }else{
                isOverLapped = false
            }
            
            self.drawPloygon(arrLocationCoordinates, strTitle: zoneCreateModal.name, strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true, strCreatedUserId: "\(userId)",willShowDistance:true)
            
            self.vw.removeFromSuperview()
            self.line.removeFromSuperlayer()
            for subView in vw.subviews {
                subView.removeFromSuperview()
            }
        }
    }
    
    //MARK:- TapGesture Recognizer
    func openImage(_ sender: UITapGestureRecognizer)
    {
        let point = sender.view
        print("index: \(point?.tag)")
    }
    
    func recognizeTapGesture(_ gestureReconizer: UITapGestureRecognizer) {
        
        let touchLocation = gestureReconizer.location(in: mapVw)
        let locationCoordinate = mapVw.convert(touchLocation,toCoordinateFrom: mapVw)
        
        print("Tapped index \(counter) lat: \(locationCoordinate.latitude) long: \(locationCoordinate.longitude)")
        print("Location x: and y:",touchLocation.x,touchLocation.y)
        
        if isWaypointMissionStarted == true && self.isWayPointMissionOn == true {
            let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
            if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude)) == true{
                
                //Delete previous annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                //Delete home coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: WaypointAnnotation.self) {
                        let annotation = someAnnotation as! WaypointAnnotation
                        if annotation.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                self.waypointTargetCoordinate = locationCoordinate
                let annotation = WaypointAnnotation.init(title: zoneCreateModal.name, coordinate: locationCoordinate, info: "\(zoneCreateModal.id)", isSelected: false)
                self.mapVw.addAnnotation(annotation)
                self.startWayPointMission(targetLocation: locationCoordinate,isWayPointMissionFromWebStarted:false)
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please place waypoint inside the polygon")
                //Delete previous annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                //Delete home coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: WaypointAnnotation.self) {
                        let annotation = someAnnotation as! WaypointAnnotation
                        if annotation.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
            }
        }
        
        if showPin == true {
            counter+=1
            if  zoneCreateModal.id != 0 {
                let userId  = UserDefaults.standard.object(forKey: "id") as! Int
                if Int32(userId) ==  zoneCreateModal.create_user_id{
                    if counter <= 20 {
                        self.isShowDistance = false
                        let annotation = AnnotationModal(title: zoneCreateModal.name, coordinate: CLLocationCoordinate2D(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude), info: "\(zoneCreateModal.id)",index: "\(counter)",distnaceFromHomeLocation: "",isShowDistance: false)
                        mapVw.addAnnotation(annotation)
                        let dictZoneInfo = NSMutableDictionary()
                        dictZoneInfo.setObject("\(locationCoordinate.latitude)", forKey: "lat" as NSCopying)
                        dictZoneInfo.setObject(" \(locationCoordinate.longitude)", forKey: "longt" as NSCopying)
                        dictZoneInfo.setObject("66", forKey: "min_alt" as NSCopying)
                        dictZoneInfo.setObject("70", forKey: "max_alt" as NSCopying)
                        let arrSome = self.dictMainEventList["\(zoneCreateModal.id)"] as! NSArray
                        let arrTemp  = NSMutableArray(array: arrSome)
                        arrTemp.add(dictZoneInfo)
                        self.dictMainEventList.setObject(arrTemp, forKey: "\(zoneCreateModal.id)" as NSCopying)
                        annotationAry.append(annotation)
                    }else{
                        
                        proxy.sharedProxy().displayStatusCodeAlert("You have reached the maximum number of points to place polygon")
                    }
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("You cannot edit other \(zoneCreateModal.create_user_name)'s zone")
                }
            }
            
        }
    }
  
    //MARK: - VALIDATE POINTS
    func isInsideThePolygon(_ polygon:MKPolygon,sampleLocation:CLLocationCoordinate2D) -> Bool {
        let mapPoint = MKMapPointForCoordinate(sampleLocation)
        let mapPointAsCGP = CGPoint(x: CGFloat(mapPoint.x),y: CGFloat(mapPoint.y))
        var isInside = false
        let mpr = CGMutablePath()
        let polygonPoints = polygon.points()
        for p in 0..<polygon.pointCount {
            let mp = polygonPoints[p]
            if p == 0 {
                mpr.move(to: CGPoint(x: CGFloat(mp.x), y: CGFloat(mp.y)))
            }
            else {
                mpr.addLine(to: CGPoint(x: CGFloat(mp.x), y: CGFloat(mp.y)))
            }
        }
        
        if mpr.contains(mapPointAsCGP) {
            isInside = true
        }
        
        return isInside
    }
    
    //MARK:- DELEGATE
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tableViewEventList {
            tableViewEventList.estimatedRowHeight = 70
            return UITableViewAutomaticDimension
        }else{
            tableViewPlaces.estimatedRowHeight = 60
            return UITableViewAutomaticDimension
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tableViewEventList {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cellEventList", for: indexPath) as! EventListOnLineTVC
            let modalObject = arrEventsList[(indexPath as NSIndexPath).row] as! ZoneCreateModal
            cell.lblZoneName.text = modalObject.name
           let converted_max_ht = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalObject.zones).object(forKey: "maximum_height") as! Float
            let converted_min_ht =  proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalObject.zones).object(forKey: "minimum_height") as! Float
            cell.lblMaxMinimumHeight.text = "\(Int32(converted_min_ht)) " + "/" + "\(Int32(converted_max_ht))" + " m"
            cell.lblCreatedUserName.text = modalObject.create_user_name
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellLocation", for: indexPath) as! SearchLocationTVC
             let locDict = locationArray[(indexPath as NSIndexPath).row] as! NSDictionary
            cell.lblPlaces.text = locDict["name"] as? String
            return cell
        }
    }
 
    //MARK: Map Conversion Methods
    fileprivate func longitudeToPixelSpaceX(_ longitude:Double)->Double{
        return round(MERCATOR_OFFSET + MERCATOR_RADIUS * longitude * M_PI / DEGREES)
    }
    
    fileprivate func latitudeToPixelSpaceY(_ latitude:Double)->Double{
        return round(MERCATOR_OFFSET - MERCATOR_RADIUS * log((1 + sin(latitude * M_PI / DEGREES)) / (1 - sin(latitude * M_PI / DEGREES))) / 2.0)
    }
    
    fileprivate func pixelSpaceXToLongitude(_ pixelX:Double)->Double{
        return ((round(pixelX) - MERCATOR_OFFSET) / MERCATOR_RADIUS) * DEGREES / M_PI
        
    }
    
    fileprivate func pixelSpaceYToLatitude(_ pixelY:Double)->Double{
        return (M_PI / 2.0 - 2.0 * atan(exp((round(pixelY) - MERCATOR_OFFSET) / MERCATOR_RADIUS))) * DEGREES / M_PI
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath){
        
        if arrEventsList.count > 0 {
        isLandingPointsToBeMarked = false
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
         let modalEvent  = self.arrEventsList[indexPath.row] as! ZoneCreateModal
        if Int32(userId) == modalEvent.create_user_id{
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        //Delete center coordinates
        for someAnnotation in annotationsToRemove {
            let strId = "\(zoneCreateModal.id)"
            if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                let annotaion = someAnnotation as! LandingPointAnnotationModal
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
        //Divider annoatation
            for someAnnotation in annotationsToRemove {
                let strId = "\(zoneCreateModal.id)"
                if someAnnotation.isKind(of: DividerAnnotation.self) {
                    let annotaion = someAnnotation as! DividerAnnotation
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
            }
         }
       }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        isLandingPointsToBeMarked = false
        if tableView == tableViewEventList {
            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
            let modalEvent  = self.arrEventsList[indexPath.row] as! ZoneCreateModal
             let userId  = UserDefaults.standard.object(forKey: "id") as! Int
            if Int32(userId) == modalEvent.create_user_id {
                //Polygon pin points
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: AnnotationModal.self) {
                        let annotaion = someAnnotation as! AnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //1.Remove the previous polygon
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        print("Zone Name : \(strTitle)")
                        if strTitle == self.zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                }
                
                //Remove divider annotation
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: DividerAnnotation.self) {
                        let annotaion = someAnnotation as! DividerAnnotation
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }

                
                //Remove center coordinate
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self){
                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                if zoneCreateModal.id != 0  {
                    //Create previuos polygon
                    let  arrTempPrev  = self.dictMainEventList.object(forKey: "\(self.zoneCreateModal.id)") as! NSArray
                    if arrTempPrev.count > 0 {
                        self.isOverLapped = false
                        self.drawPloygon(arrTempPrev, strTitle: "\(zoneCreateModal.name)", strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: false,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:false)
                    }
                }
                
               //other polygon
                self.zoneCreateModal = modalEvent
                selectedIndexPath = indexPath
                //test
                self.pubNubClientSetup()
                // self.arrPubNubChannels.append(dictDetails.object(forKey: "uid") as! String)
                self.client.subscribeToChannels(self.arrPubNubChannels, withPresence: false)
                //Updating polygon
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                isDragPin = true
                let  arrTemp  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                var isOverlayDraw = false
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        if strTitle == modalEvent.name {
                            isOverlayDraw = true
                        }
                    }
                }
                
                var isIntersectionFound = false
                var isHeightIntersected = false
                //check current polygon with other polygons
                if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
                    let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                    let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "minimum_height") as! Float
                    let current_max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "maximum_height") as! Float
                    for i in 0..<self.arrEventsList.count{
                        let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                        if zoneCreateModal.id != modalEvent.id {
                            let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                            if arrTempOther.count > 0 {
                                let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                                let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                                let current_arr =  self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                                let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: current_arr).object(forKey: "minimum_height") as! Float
                                let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: current_arr).object(forKey: "maximum_height") as! Float
                                //Find Height intersection
                                //case 0:
                                if current_min_height >= min_height  && current_max_height <= min_height{
                                    isHeightIntersected = true
                                }
                                //case 1:
                                if current_min_height <= min_height && current_max_height >= max_height {
                                    isHeightIntersected = true
                                }else{
                                    if current_max_height >= min_height && current_max_height <= max_height {
                                        isHeightIntersected = true
                                    }
                                }
                                
                                if somePolygon!.pointCount > 0 {
                                    if  isHeightIntersected == true {
                                        isIntersectionFound = true
                                    }
                                    break
                                }
                            }
                        }
                    }
                }
                
                //2.Remove second overlay
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        print("Zone Name : \(strTitle)")
                        if strTitle == self.zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                }
                
                if isIntersectionFound == true{
                    isOverLapped = true
                }else{
                    isOverLapped = false
                }
               
                if arrTemp.count > 0 {
               self.drawPloygon(arrTemp, strTitle: zoneCreateModal.name, strZoneId: "\(modalEvent.id)", willShowAnnotaion: true,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:true)
                }
               
                    let arrDrawAreaCoordinate = NSMutableArray()
                    var annotationArrayTemp = [MKAnnotation]()
                    let event_id = modalEvent.id
                    let event_name = modalEvent.name
                    var userLoc1 = CLLocationCoordinate2D()
                    for i in 0 ..< arrTemp.count{
                        var dict = NSDictionary()
                        dict = arrTemp[i] as! NSDictionary
                        let lat = dict["lat"] as! String
                        let long = dict["longt"] as! String
                        let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                        let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                        userLoc1.latitude = Double(newLat)!
                        userLoc1.longitude = Double(newLong)!
                        let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "",isShowDistance: false)
                        let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
                       // mapVw.addAnnotation(annotation)
                        annotationArrayTemp.append(annotation)
                        arrDrawAreaCoordinate.add(loc)
                    }
                
                
            if arrDrawAreaCoordinate.count > 0
            {
                showPin = false
                isCompleted = true
            }
                
            let  arrZones  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
            if arrZones.count > 0 {
                let numberOfSteps: Int =  arrDrawAreaCoordinate.count
                var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
                let firstLocation =  arrDrawAreaCoordinate[0] as! CLLocation
                for index in 0 ..< numberOfSteps
                {
                    let location: CLLocation =  arrDrawAreaCoordinate[index] as! CLLocation
                    points.append(location.coordinate)
                }
                NSLog("ARRAY COORDINATES:%d",points.count)
                points.append(firstLocation.coordinate)

                var arrAnnotation = [MKAnnotation]()
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                if Int32(userId) == modalEvent.create_user_id {
                    //Polygon pin points
                    for someAnnotation in annotationsToRemove {
                        let strId = "\(zoneCreateModal.id)"
                        if someAnnotation.isKind(of: AnnotationModal.self) {
                            let annotation = someAnnotation as! AnnotationModal
                            if annotation.info == strId {
                               arrAnnotation.append(annotation)
                            }
                        }
                    }
                }
                self.mapVw.showAnnotations(arrAnnotation, animated: true)
                
             }
                
        }else{
                proxy.sharedProxy().displayStatusCodeAlert("You don't have permission to edit \(self.zoneCreateModal.create_user_name) zone")
          }
        }else{
            //Search locations
            self.searchBar.text = ""
            self.searchBar.showsCancelButton = false
            searchBar.resignFirstResponder()
            if locationArray.count > 0 {
                let locDict = locationArray[(indexPath as NSIndexPath).row] as! NSDictionary
                let Lat = locDict.value(forKey: "lat") as! Float64
                let Long = locDict.value(forKey: "lng") as! Float64
                if locDict.value(forKey: "lat") != nil  &&  locDict.value(forKey: "lng") != nil{
                    let lat =  Lat
                    let long = Long
                    var userLoc = CLLocationCoordinate2D()
                    userLoc.latitude = CDouble(lat)
                    userLoc.longitude = CDouble(long)
                    let span = MKCoordinateSpanMake(0.025, 0.025)
                    let region = MKCoordinateRegion(center: userLoc, span: span)
                    mapVw.setRegion(region, animated: true)
                    mapVw.showsUserLocation = true
                    tableViewPlaces.isHidden = true
                    tableViewPlaces.deselectRow(at: indexPath, animated: false)
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableViewEventList {
            return self.arrEventsList.count
        }else{
            return locationArray.count
        }
    }
    
    //MARK:- GESTURERECOGNIZER AND MAPKIT DELEGATE
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool{
        return true
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, didChange newState: MKAnnotationViewDragState, fromOldState oldState: MKAnnotationViewDragState) {
        switch (newState) {
        case .ending :
            let annotation = view.annotation as? AnnotationModal
            if view.annotation!.isKind(of: AnnotationModal.self) {
                let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation!.info)) as! NSMutableArray
                let coord = (view.annotation?.coordinate)! as CLLocationCoordinate2D
                view.dragState = .none
                view.isSelected = false
                let dict = arrTempDrawPolygon[view.tag-1] as! NSMutableDictionary
                dict["lat"] = "\(coord.latitude)"
                dict["longt"] = "\(coord.longitude)"
                arrTempDrawPolygon.replaceObject(at: view.tag-1, with: dict)
                self.drawPloygon(arrTempDrawPolygon, strTitle: zoneCreateModal.name, strZoneId: "\((annotation!.info))", willShowAnnotaion: true,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:false)
               
                //Delete annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: AnnotationModal.self) {
                        let annotaion = someAnnotation as! AnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
               
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }

                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        if strTitle == zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                   
                }
                
                //Delete center coordinates between edges
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: DividerAnnotation.self) {
                        let annotaion = someAnnotation as! DividerAnnotation
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //check current polygon with other polygons
                var isIntersectionFound = false
                var isHeightIntersected = false
                
                if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil {
                    let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                    let arrTemp =  self.dictMainEventList.object(forKey:  "\(annotation!.info)") as! NSArray
                    let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "minimum_height") as! Float
                    let current_max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: arrTemp).object(forKey: "maximum_height") as! Float
                    for i in 0..<self.arrEventsList.count {
                        let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                        if zoneCreateModal.id != modalEvent.id {
                            let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                            if arrTempOther.count > 0 {
                                let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                                let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                                  let current_arr =  self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                                let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: current_arr).object(forKey: "minimum_height") as! Float
                                let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: current_arr).object(forKey: "maximum_height") as! Float
                                
                                //Find Height intersection
                                //case 0:
                                if current_min_height >= min_height  && current_max_height <= min_height{
                                    isHeightIntersected = true
                                }
                                //case 1:
                                if current_min_height <= min_height && current_max_height >= max_height {
                                    isHeightIntersected = true
                                }else{
                                
                                    if current_max_height >= min_height && current_max_height <= max_height {
                                        isHeightIntersected = true
                                    }
                                }
                                
                                if somePolygon!.pointCount > 0 {
                                    if  isHeightIntersected == true {
                                        isIntersectionFound = true
                                    }
                                    break
                                }
                            }
                        }
                    }
                }
               
                if isIntersectionFound == true{
                    isOverLapped = true
                }else{
                    isOverLapped = false
                }
                
                var intersection = Bool()
               
                let arrPolygonCoordinates = proxy.sharedProxy().getCllocationCoordinate2d(arrTempDrawPolygon)
                let arrNewCoordinates = proxy.sharedProxy().makeCoordinatePoints(arrPolygonCoordinates)
                if arrNewCoordinates.count > 2 {
                    let n = arrNewCoordinates.count - 1
                    for i in 1 ..< n {
                        
                        if intersection == true {
                            break
                        }
                        
            for j in 0 ..< i-1 {
             intersection = proxy.sharedProxy().intersectionBetweenSegmentsCL(arrNewCoordinates[i] , p1: arrNewCoordinates[i+1] , p2: arrNewCoordinates[j+1], p3: arrNewCoordinates[j] )
                if intersection == true  {
                // do whatever you want with `intersection`
                   print("Error: Intersection @ \(intersection)")
                    proxy.sharedProxy().displayStatusCodeAlert("Error: Invalid polygon structure")
                    break
                   }
                  }
                      
                }
            }
                if intersection == true {
                     self.isSelfIntersecting = true
                }else{
                
                     self.isSelfIntersecting = false
                }
                self.zoneCreateModal.zones = arrTempDrawPolygon as NSArray
                self.arrEventsList.replaceObject(at: (selectedIndexPath as NSIndexPath).row, with: self.zoneCreateModal)
                if self.arrEventsList.count > 0 {
                    self.tableViewEventList.reloadData()
                }
 
                self.drawPloygon(arrTempDrawPolygon, strTitle: zoneCreateModal.name, strZoneId: "\(annotation!.info)", willShowAnnotaion: true,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:false)
                
                
                
            }else if view.annotation!.isKind(of: DividerAnnotation.self){
                let annoatationDivider = view.annotation as! DividerAnnotation
                let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annoatationDivider.info)) as! NSMutableArray
                let coord = (view.annotation?.coordinate)! as CLLocationCoordinate2D
                view.dragState = .none
                view.isSelected = false
                let dict =  NSMutableDictionary()
                dict.setObject("\(coord.latitude)", forKey: "lat" as NSCopying)
                dict.setObject("\(coord.longitude)", forKey: "longt" as NSCopying)
                let minimum = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
                let max = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                dict.setObject("\(minimum * 3.2808)", forKey: "min_alt" as NSCopying)
                dict.setObject("\(max * 3.2808)", forKey: "max_alt" as NSCopying)
                let index = Int(annoatationDivider.prevIndex)!
                arrTempDrawPolygon.insert(dict, at:( index + 1))
                self.dictMainEventList.setObject(arrTempDrawPolygon, forKey: "\(annoatationDivider.info)" as NSCopying)
                 self.drawPloygon(arrTempDrawPolygon, strTitle: zoneCreateModal.name, strZoneId: "\(annoatationDivider.info)", willShowAnnotaion: true,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:false)
              
                //Delete annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annoatationDivider.info)"
                    if someAnnotation.isKind(of: AnnotationModal.self) {
                        let annotaion = someAnnotation as! AnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annoatationDivider.info)"
                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annoatationDivider.info)"
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        if strTitle == zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                }
                
                //Delete center coordinates between edges
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annoatationDivider.info)"
                    if someAnnotation.isKind(of: DividerAnnotation.self) {
                        let annotaion = someAnnotation as! DividerAnnotation
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }

                //check current polygon with other polygons
                var isIntersectionFound = false
                var isHeightIntersected = false
                
                if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
                    let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                    let current_min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
                    let current_max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                    for i in 0..<self.arrEventsList.count{
                        let modalEvent  = self.arrEventsList[i] as! ZoneCreateModal
                        if zoneCreateModal.id != modalEvent.id {
                            let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                            if arrTempOther.count > 0 {
                                let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                                let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                                let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalEvent.zones).object(forKey: "minimum_height") as! Float
                                let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalEvent.zones).object(forKey: "maximum_height") as! Float
                                
                                //Find Height intersection
                                //case 0:
                                if current_min_height >= min_height  && current_max_height <= min_height{
                                    isHeightIntersected = true
                                }
                                //case 1:
                                if current_min_height <= min_height && current_max_height >= max_height {
                                    isHeightIntersected = true
                                }
                                
                                
                                
                                if somePolygon!.pointCount > 0 {
                                    if  isHeightIntersected == true {
                                        isIntersectionFound = true
                                         break
                                    }
                                   
                                }
                            }
                        }
                    }
                }
                
                if isIntersectionFound == true{
                    isOverLapped = true
                }else{
                    isOverLapped = false
                }
                
               var intersection = Bool()
                let arrPolygonCoordinates = proxy.sharedProxy().getCllocationCoordinate2d(arrTempDrawPolygon)
                let arrNewCoordinates = proxy.sharedProxy().makeCoordinatePoints(arrPolygonCoordinates)
                if arrNewCoordinates.count > 2 {
                    let n = arrNewCoordinates.count - 1
                    for i in 1 ..< n {
                        if intersection == true {
                            break
                        }
                        for j in 0 ..< i-1 {
                             intersection = proxy.sharedProxy().intersectionBetweenSegmentsCL(arrNewCoordinates[i] , p1: arrNewCoordinates[i+1] , p2: arrNewCoordinates[j+1], p3: arrNewCoordinates[j] )
                            if intersection == true  {
                                // do whatever you want with `intersection`
                                print("Error: Intersection @ \(intersection)")
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Invalid polygon structure")
                                break
                            }
                        }
                    }
                }
                
                if intersection == true {
                    self.isSelfIntersecting = true
                }else{
                    self.isSelfIntersecting = false
                }
                
                self.drawPloygon(arrTempDrawPolygon, strTitle: zoneCreateModal.name, strZoneId: "\(annoatationDivider.info)", willShowAnnotaion: true,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:false)
                
                self.zoneCreateModal.zones = arrTempDrawPolygon as NSArray
                self.arrEventsList.replaceObject(at: (selectedIndexPath as NSIndexPath).row, with: self.zoneCreateModal)
                if self.arrEventsList.count > 0 {
                    self.tableViewEventList.reloadData()
                }
                
            }
            break
        default: break
        }
        
    }
    
    
    //MARK:- DELETE ANNOTATION
    func deleteAnnotation(_ strAnnotation:String) {
        //Delete annotation
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            if someAnnotation.isKind(of: AnnotationModal.self) {
                let annotaion = someAnnotation as! AnnotationModal
                if annotaion.info == strAnnotation {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
    }
    
    func deleteCenterCoordinates(_ strAnnotation:String) {
        //Delete center coordinates
         let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                let annotaion = someAnnotation as! ZoneNameAnnotationModal
                if annotaion.info == strAnnotation {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
    }
    
    func deleleteOverlayPoints(_ name:String)  {
        //Remove overlay
        for overlay in self.mapVw.overlays {
            if overlay.isKind(of: MKPolygon.self) {
                let strTitle = String(validatingUTF8: overlay.title!!)!
                if strTitle == name {
                    self.mapVw.remove(overlay)
                }
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let imgView = UIImageView()
        if (annotation.isKind(of: MKUserLocation.self)) {
            return nil
        }
        let reuseId = "createZoneArea"
        if (annotation.isKind(of: AnnotationModal.self)) {
            imgView.frame = CGRect(x: 15, y: 15, width: 30, height: 30)
            imgView.image =  UIImage(named: "ic_circle_mark")
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            let cpa = annotation as! AnnotationModal
                let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
                altitudeVw.backgroundColor = UIColor.clear
                altitudeVw.addSubview(imgView)
            let circle = CAShapeLayer()
            let radius = 30.0
            circle.path = UIBezierPath(roundedRect: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(2.0 * radius), height: CGFloat(2.0 * radius)), cornerRadius: CGFloat(radius)).cgPath
            // Configure the apperence of the circle
            circle.fillColor = UIColor.clear.cgColor
            circle.strokeColor = UIColor(red: 240.0/255, green: 240.0/255, blue: 240.0/255, alpha: 0.70).cgColor
            circle.lineDashPattern = [2, 3]
            circle.lineWidth = 4.0
            // Add to parent layer
            altitudeVw.layer.addSublayer(circle)
                let lblTitle = UILabel(frame: CGRect(x: 15, y: 15, width: 30, height: 30))
                lblTitle.font = lblTitle.font.withSize(13)
                lblTitle.text = cpa.index
                lblTitle.textAlignment = NSTextAlignment.center
                lblTitle.textColor = UIColor.white
                altitudeVw.addSubview(lblTitle)
                anView.addSubview(altitudeVw)
                anView.tag = Int(cpa.index)!
                anView.canShowCallout = false
                if self.isDragPin == true {
                    anView.isEnabled = true
                    anView.isSelected = true
                    anView.isUserInteractionEnabled = true
                    anView.isDraggable = true
                }else{
                    anView.isDraggable = false
                    anView.isEnabled = false
                    anView.isUserInteractionEnabled = false
                }
                anView.rightCalloutAccessoryView = nil
                anView.frame = CGRect(x: 0, y: 0, width: 60, height: 60)
                anView.centerOffset = CGPoint(x: 0,y: 0)
                return anView
            }
     
        if annotation.isKind(of: LandingPointAnnotationModal.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "landingPoints")
            let annotationInfo = annotation as! LandingPointAnnotationModal
            imgView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
            imgView.image =  #imageLiteral(resourceName: "ic_home")
            anView.isDraggable = false
            anView.isEnabled = false
            anView.isUserInteractionEnabled = false
            anView.tag = Int(annotationInfo.index)!
            anView.addSubview(imgView)
            anView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
            anView.centerOffset = CGPoint(x: 0,y: -15)
            return anView
        }
        
        if annotation.isKind(of: ZoneNameAnnotationModal.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "zoneNameInMiddle")
            let ann = annotation as! ZoneNameAnnotationModal
            let height = 30
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: height))
            let lblTitle = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: height))
            lblTitle.font = lblTitle.font.withSize(10)
            lblTitle.text = ann.title
            lblTitle.numberOfLines = 10
            lblTitle.textAlignment = NSTextAlignment.center
            lblTitle.textColor = UIColor.black
            lblTitle.backgroundColor = UIColor.clear
            altitudeVw.layer.cornerRadius = 6.0
            altitudeVw.layer.borderWidth = 1.0
            altitudeVw.layer.borderColor = UIColor.black.cgColor
            altitudeVw.backgroundColor =  UIColor(red: 255.0/255, green: 255.0/255, blue: 255.0/255, alpha: 0.70)
            altitudeVw.addSubview(lblTitle)
            anView.addSubview(altitudeVw)
            return anView
        }
        
        if annotation.isKind(of: DroneAnnotation.self) {
          let  annoView = DJIAircraftAnnotationView.init(annotation: annotation, reuseIdentifier: "Aircraft_Annotation")
            (annotation as! DroneAnnotation).annotationView = annoView
             return annoView
        }
        
        if annotation.isKind(of: UserAnnotation.self) {
            let  annoView = UserAnnotationView.init(annotation: annotation, reuseIdentifier: "User_Annotation")
            let imgView = UIImageView()
            imgView.frame = CGRect(x: 15, y: 15, width: 30, height: 30)
            imgView.image =  #imageLiteral(resourceName: "ic_drop_orange")
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
            altitudeVw.backgroundColor = UIColor.clear
            let circle = CAShapeLayer()
            let radius = 30.0
            circle.path = UIBezierPath(roundedRect: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(2.0 * radius), height: CGFloat(2.0 * radius)), cornerRadius: CGFloat(radius)).cgPath
            // Configure the apperence of the circle
            circle.fillColor = UIColor.clear.cgColor
            circle.strokeColor = UIColor.white.cgColor
            circle.lineDashPattern = [2, 3]
            circle.lineWidth = 4.0
            // Add to parent layer
            altitudeVw.layer.addSublayer(circle)
            annoView.frame =  CGRect(x: 0, y: 0, width: 60, height: 60)
            altitudeVw.addSubview(imgView)
            annoView.addSubview(altitudeVw)

           (annotation as! UserAnnotation).annotationView = annoView
            return annoView
        }
        
        if annotation.isKind(of: DividerAnnotation.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "dividerPoint")
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            altitudeVw.backgroundColor = UIColor.clear
            imgView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            altitudeVw.addSubview(imgView)
            imgView.image =  UIImage(named: "ic_plus_circle")
            anView.addSubview(altitudeVw)
            anView.canShowCallout = false
            if self.isDragPin == true {
                anView.isEnabled = true
                anView.isSelected = true
                anView.isUserInteractionEnabled = true
                anView.isDraggable = true
            }else{
                anView.isDraggable = false
                anView.isEnabled = false
                anView.isUserInteractionEnabled = false
            }
            anView.rightCalloutAccessoryView = nil
            anView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            anView.centerOffset = CGPoint(x: 0,y: 0)
            return anView
        }
        
        if annotation.isKind(of: WaypointAnnotation.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "landingPoints")
            let annotationInfo = annotation as! WaypointAnnotation
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 25, height: 25))
            altitudeVw.backgroundColor = UIColor.clear
            imgView.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
            altitudeVw.addSubview(imgView)
            if annotationInfo.isSelected == true {
                 imgView.image =  UIImage(named: "ic_green_marker")
            }else{
               
                imgView.image =  UIImage(named: "ic_red_marker")
            }
            anView.addSubview(altitudeVw)
            anView.canShowCallout = false
            anView.isDraggable = false
            anView.isEnabled = false
            anView.isUserInteractionEnabled = false
            anView.rightCalloutAccessoryView = nil
            anView.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
            anView.centerOffset = CGPoint(x: 0,y: 0)
            return anView
        }
        
        if annotation.isKind(of: GridAnnotationStart.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "grid_start")
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 22))
            altitudeVw.backgroundColor = UIColor.clear
            imgView.frame = CGRect(x: 0, y: 0, width: 50, height: 22)
            altitudeVw.addSubview(imgView)
            imgView.image =  #imageLiteral(resourceName: "ic_start")
            anView.addSubview(altitudeVw)
            anView.canShowCallout = false
            anView.isDraggable = false
            anView.isEnabled = false
            anView.isUserInteractionEnabled = false
            anView.rightCalloutAccessoryView = nil
            anView.frame = CGRect(x: 0, y: 0, width: 50, height: 22)
            anView.centerOffset = CGPoint(x: 5,y: 0)
            return anView
        }
        
        if annotation.isKind(of: GridAnnotationEnd.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "grid_end")
            let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 22))
            altitudeVw.backgroundColor = UIColor.clear
            imgView.frame = CGRect(x: 0, y: 0, width: 50, height: 22)
            altitudeVw.addSubview(imgView)
            imgView.image =  #imageLiteral(resourceName: "ic_end")
            anView.addSubview(altitudeVw)
            anView.canShowCallout = false
            anView.isDraggable = false
            anView.isEnabled = false
            anView.isUserInteractionEnabled = false
            anView.rightCalloutAccessoryView = nil
            anView.frame = CGRect(x: 0, y: 0, width: 50, height: 22)
            anView.centerOffset = CGPoint(x: 5,y: 0)
            return anView
        }
        return nil
    }
    
    func buttonAction(_ sender: UIButton!) {
       let btnsendtag: UIButton = sender
       print("index: \(btnsendtag.tag)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    

   //MARK: - MAPVIEW DELEGATE
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
         mapVw.deselectAnnotation(selectedAnnotationVw.annotation, animated: true)
        vwSeparateAltitude.isHidden = true
           }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor(red: 255.0/255, green: 244.0/255, blue: 52.0/255, alpha: 0.70)
            polylineRenderer.lineWidth = 1.0
            return polylineRenderer
        }
        
        if let overlay = overlay as? MKCircle {
        let circleRenderer = MKCircleRenderer(circle: overlay)
            circleRenderer.strokeColor = UIColor.clear
            circleRenderer.fillColor = UIColor.clear
            circleRenderer.lineWidth = 0
        return circleRenderer
        }else{
        let polygonView = MKPolygonRenderer(overlay: overlay)
       
        polygonView.lineWidth = 2
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        let strUserId = "\(userId)"
        if strUserId == polygonView.polygon.subtitle {
        polygonView.fillColor = UIColor(red: 15.0/255, green: 125.0/255, blue: 239.0/255, alpha: 0.10)
            if isSelfIntersecting == true {
               polygonView.strokeColor = UIColor(red: 255.0/255, green: 42.0/255, blue: 34.0/255, alpha: 0.4)
            }else{
            polygonView.strokeColor = UIColor(red: 71.0/255, green: 194.0/255, blue: 19.0/255, alpha: 1)
            }
            
        }else{
        polygonView.fillColor = UIColor(red: 47.0/255, green: 48.0/255, blue: 47.0/255, alpha: 0.30)
             polygonView.strokeColor = UIColor(red: 71.0/255, green: 194.0/255, blue: 19.0/255, alpha: 1)
        }
        
        if isOverLapped == true {
            polygonView.fillColor = UIColor(red: 206.0/255, green: 38.0/255, blue: 35.0/255, alpha: 0.50)
        }
        return polygonView
       
        }
        
    }
    

    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView){
        selectedAnnotationVw = view
        
        //Handle separate action
        if !((view.annotation?.isKind(of: MKUserLocation.self))!) {
            
            view.isSelected = true
            if (isDragToPoint == false && isLandingPointsToBeDeleted == false && isPinPointsToBeDeleted == false){
                if isCompleted == true {
                    if view.annotation!.isKind(of: AnnotationModal.self) {
                        
                        let annotation = view.annotation as? AnnotationModal
                        let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation?.info)!) as! NSArray
                        vwChooseAltitude.isHidden = true
                        let dictShowAltitude = arrTempDrawPolygon[view.tag-1] as! NSMutableDictionary
                        txtFldSeperateMin.text = dictShowAltitude.value(forKey: "min_alt") as? String
                        txtFldSeperateMax.text = dictShowAltitude.value(forKey: "max_alt") as? String
                        vwSeparateAltitude.isHidden = false
                        let mainScreenWidth = UIScreen.main.bounds.size.width
                        let mainScreenHeight = UIScreen.main.bounds.size.height
                        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
                        if UIDevice.current.orientation.isLandscape {
                            //  Landscape
                            if view.frame.origin.x >= mainScreenWidth-250 {
                                cnstVwSeparateOriginX.constant = view.frame.origin.x - 600
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }else{
                                cnstVwSeparateOriginX.constant = view.frame.origin.x-350
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }
                        } else if UIDevice.current.orientation.isPortrait  {
                            //Portrait
                            if view.frame.origin.x >= mainScreenWidth-250 {
                                cnstVwSeparateOriginX.constant = view.frame.origin.x-500
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-520
                                }
                            }else{
                                cnstVwSeparateOriginX.constant = abs(view.frame.origin.x)-250
                                
                                if view.frame.origin.y >= mainScreenHeight-100 {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-520
                                }
                            }
                        }else{
                            //  Landscape
                            if view.frame.origin.x >= mainScreenWidth-250 {
                                cnstVwSeparateOriginX.constant = view.frame.origin.x - 600
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }else{
                                cnstVwSeparateOriginX.constant = view.frame.origin.x-350
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }
                        }
                        lblSeparateAltitudes.text = " Separate Altitudes(\(view.tag))"
                    }
                }
            }
        }
    }
    
   //MARK: - AUTOROTATION METHOD
    
    override var shouldAutorotate: Bool{
            return false;
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return [UIInterfaceOrientationMask.landscape]
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView){
        if view.annotation!.isKind(of: AnnotationModal.self) {
            let annotation = view.annotation as? AnnotationModal
            mapView.deselectAnnotation(annotation, animated: true)
        }
        
    }
    
    
    // MARK: - Navigation
   
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "droneControl" {
//            let arrTemp = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray
//            if arrTemp?.count > 0 {
//            let droneVC = segue.destination as! DroneControlVC
//            droneVC.arrFlyzone  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
//            droneVC.zoneModal = zoneCreateModal
//            }else{
//                proxy.sharedProxy().displayStatusCodeAlert("Please create zone to fly drone ")
//            }
//        }
//    }

    
    //MARK: - INITIAL UI SETUP
    func setUpManager() {
        virtualStickLeft.isHidden = false
        virtualStickRight.isHidden = false
        vwDataFromDrone.isHidden = false
        btnZonesList.isHidden = true
        vwEventsLists.isHidden = true
        btnSettingsZone.isHidden = true
        cnstVwSettings.constant = 0
        vwChooseAltitude.isHidden = true
        vwCollectiveAltitudes.isHidden = true
        vwSeparateAltitude.isHidden = true
        self.registerApp(isReigster: willRegisterApp)
    }
    
    //MARK: - VERTICAL AND ROLL/PITCH CONTROL
    func positionControllerVertical(_ distanceToMinAltitude: Float,distanceToMaxAltitude:Float, actualVerticalSpeed:Float
        ,verticalValue:Float) -> Float {
        var joystickValueVertical = verticalValue
        var setMaxSpeedVertical = Float()
        var setMinSpeedVertical = Float()
        let K_Vertical = Float(self.txtField_K_Vertical.text!)
        let D_Vertical = Float(self.txtField_D_Vertical.text!)
        setMaxSpeedVertical = K_Vertical! * distanceToMaxAltitude - D_Vertical! * actualVerticalSpeed;
        setMinSpeedVertical = K_Vertical! * distanceToMinAltitude - D_Vertical! * actualVerticalSpeed;
        
        
        /* Limit speed to match the maximum speed, defined the constants of dji */
        if(setMaxSpeedVertical >  4.0) {
            setMaxSpeedVertical =  4.0
        }
        if(setMaxSpeedVertical < 0.0){
            setMaxSpeedVertical = 0.0
        }
        
        if(setMinSpeedVertical >  0.0) {
            setMinSpeedVertical =  0.0
        }
        if(setMinSpeedVertical < -4.0) {
            setMinSpeedVertical = -4.0
        }
        
        self.lblSetMinAndMaxSpeed.text = "Set Min Speed: \(setMinSpeedVertical) m/s                            Set Max Speed: \(setMaxSpeedVertical) m/s"
        
        /* Values from joystick are limited and then send to drone */
        if(joystickValueVertical > setMaxSpeedVertical){
            joystickValueVertical = setMaxSpeedVertical
        }
        if(joystickValueVertical < setMinSpeedVertical){
            joystickValueVertical = setMinSpeedVertical
        }
        
        
        return joystickValueVertical
    }
    
    func positionControllerRollPitch(_ distanceToBoundary_X:Float, distanceToBoundary_Y:Float,actualSpeedPitch:Float,actualSpeedRoll:Float) -> NSDictionary {
        let K_Pitch = Float(txtField_K_Pitch.text!)
        let D_Pitch = Float(txtField_D_Pitch.text!)
        let K_Roll = Float(txtField_K_Roll.text!)
        let D_Roll = Float(txtField_D_Roll.text!)
        var setMaxSpeedPitch = Float()
        var setMaxSpeedRoll = Float()
        
        setMaxSpeedPitch = K_Pitch! * distanceToBoundary_Y - D_Pitch! * actualSpeedPitch
        setMaxSpeedRoll = K_Roll! * distanceToBoundary_X - D_Roll! * actualSpeedRoll
        
        
        /* Limit speeds to match the maximum speed, defined the constants of dji */
        if(setMaxSpeedPitch > 15.0){
            setMaxSpeedPitch =  15.0
        }
        if(setMaxSpeedPitch < -15.0){
            setMaxSpeedPitch = -15.0
        }
        
        
        /* Limit speeds to match the maximum speed, defined the constants of dji */
        if(setMaxSpeedRoll > 15.0) {
            setMaxSpeedRoll =  15.0
        }
        if(setMaxSpeedRoll < -15.0) {
            setMaxSpeedRoll = -15.0
        }
        
        let dictData = NSMutableDictionary()
        dictData.setObject(setMaxSpeedPitch, forKey: "pitch" as NSCopying)
        dictData.setObject(setMaxSpeedRoll, forKey: "roll" as NSCopying)
        
        return dictData as NSDictionary
    }
    
    
    
    func updateVirtualStick() {
       var ctrlData = DJIVirtualStickFlightControlData()
        ctrlData.pitch = self.mYVelocity
        ctrlData.roll = self.mXVelocity
        ctrlData.yaw = self.mYaw
        ctrlData.verticalThrottle = self.mThrottle
        let fc = DroneUtility.fetchFlightController()
        if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
            fc?.send(ctrlData, withCompletion: { (error) in
                if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                }
            })
        }
    }
    
    
    
    func setXVelocity(_ x: Float, andYVelocity y: Float) {
        self.mXVelocity = x * DJIVirtualStickRollPitchControlMaxVelocity
        self.mYVelocity = y * DJIVirtualStickRollPitchControlMaxVelocity
        
        let velocity_y = ((self.mYVelocity/15) * Float(39))
        if self.mYVelocity > 0 {
            cnstYPositiveStickRight.constant = CGFloat(velocity_y)
            cnstYNegativeStickRight.constant = 0
        }else{
        cnstYNegativeStickRight.constant = abs(CGFloat(velocity_y))
        cnstYPositiveStickRight.constant = 0
        }
         let velocity_x = ((self.mXVelocity/15) * Float(39))
        if self.mXVelocity > 0 {
            cnstXPositiveStickRight.constant = CGFloat(velocity_x)
            cnstXNegativeStickRight.constant = 0
        }else{
        cnstXNegativeStickRight.constant = abs( CGFloat(velocity_x))
            cnstXPositiveStickRight.constant = 0
        }
        
        if switchRollPitch.isOn == true {
           
            let dictDataRollPitch = positionControllerRollPitch(distanceInMeters, distanceToBoundary_Y: distanceInMeters, actualSpeedPitch: current_PitchY, actualSpeedRoll: current_RollX)
            let rollX = dictDataRollPitch.object(forKey: "roll") as! Float
            let pitchY = dictDataRollPitch.object(forKey: "pitch") as! Float
            var ctrlData = DJIVirtualStickFlightControlData()
            ctrlData.pitch = pitchY
            ctrlData.roll = rollX
            ctrlData.yaw = self.mYaw
            ctrlData.verticalThrottle = self.mThrottle
            let fc = DroneUtility.fetchFlightController()
            if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                fc?.send(ctrlData, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }
                })
            }
        }else{
            var ctrlData = DJIVirtualStickFlightControlData()
            ctrlData.pitch = self.mYVelocity
            ctrlData.roll = self.mXVelocity
            ctrlData.yaw = self.mYaw
            ctrlData.verticalThrottle = self.mThrottle
            let fc = DroneUtility.fetchFlightController()
            if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                fc?.send(ctrlData, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }
                })
            }

        }
    }
    
    func setThrottle(_ y: Float, andYaw x: Float) {
        self.mThrottle = y * -4
        self.mYaw = x * 100
        let yaw = x * 100
        let throttle = y * -4
         let position_x = ((yaw/100) * Float(36.5))
        if yaw > 0 {
            cnstXPositiveStickLeft.constant = CGFloat(position_x)
            cnstXNegativeStickLeft.constant = 0
        }else{
            cnstXPositiveStickLeft.constant = 0
            cnstXNegativeStickLeft.constant = abs(CGFloat(position_x))
        }
        let position_y = ((throttle/4) * Float(39))
        if throttle > 0{
            cnstYPositiveStickLeft.constant = CGFloat(position_y)
            cnstYNegativeStickLeft.constant = 0
        }else{
         cnstYPositiveStickLeft.constant = 0
        cnstYNegativeStickLeft.constant = abs(CGFloat(position_y))
        }
        
        if switchVertical.isOn == true {
          
            self.min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
            let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
            let distanceToMinAltitude =   self.min_height - current_altitude
            let distanceToMaxAltitude =   max_height - current_altitude
            
            let throttle = self.positionControllerVertical(distanceToMinAltitude,distanceToMaxAltitude:distanceToMaxAltitude, actualVerticalSpeed: current_vertical_speed,verticalValue:  Float(y * -4))
            
            var ctrlData = DJIVirtualStickFlightControlData()
            ctrlData.pitch = self.mYVelocity
            ctrlData.roll = self.mXVelocity
            
            ctrlData.yaw = self.mYaw
            ctrlData.verticalThrottle = throttle
            let fc = DroneUtility.fetchFlightController()
            if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                fc?.send(ctrlData, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }
                })
            }

        }else{
            var ctrlData = DJIVirtualStickFlightControlData()
            ctrlData.yaw = self.mYaw
            ctrlData.verticalThrottle = self.mThrottle
            let fc = DroneUtility.fetchFlightController()
            if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                fc?.send(ctrlData, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }
                })
            }
        }
    }
    
    //MARK: - DJI SDK DELEGATE
    
    func sdkManagerDidRegisterAppWithError(_ error: Error?) {
        if error == nil {
            #if (arch(i386) || arch(x86_64)) && os(iOS)
                //simulator
                DJISDKManager.enterDebugMode(withDebugId: "192.168.10.185")
            #else
                //device
                 DJISDKManager.startConnectionToProduct()
                // proxy.sharedProxy().displayStatusCodeAlert("DJI SDK Version: \(DJISDKManager.getSDKVersion())")
            #endif
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Registration Error:\(error?.localizedDescription)")
        }
    }
    
    func sdkManagerProductDidChange(from oldProduct: DJIBaseProduct?, to newProduct: DJIBaseProduct?) {
        if newProduct != nil{
            self.product = newProduct!
            proxy.sharedProxy().displayStatusCodeAlert("\(self.product.model!) connected")
            // Do any additional setup after loading the view from its nib.
            let camera: DJICamera? = DroneUtility.fetchAircraft().camera
            if camera != nil {
                camera!.delegate = self
            }
            let aircraft = DroneUtility.fetchAircraft()
            if aircraft != nil {
                aircraft?.remoteController?.delegate = self
                aircraft?.battery?.delegate = self
            }
            
                VideoPreviewer.instance().start()
                adapter = VideoPreviewerSDKAdapter(videoPreviewer: VideoPreviewer.instance())
                adapter?.start()
                VideoPreviewer.instance().setView(self.fpvView)
                UIView.animate(withDuration: Double(0.50), animations: {
                    self.cnstfpvFullScreen.constant = 0.0
                    self.view.layoutIfNeeded()
                    self.fpvTempView.isHidden = false
                    self.btnfpvFullScreenOverlay.isHidden = true
                })
            if let flightController = DroneUtility.fetchFlightController(){
                if flightController.isConnected == true {
                    lblDroneName.text = flightController.product!.model
                }else{
                    lblDroneName.text = "Not Connected"
                    imgRCSignalStrength.image = #imageLiteral(resourceName: "ic_signal_blank")
                    imgCameraSignal.image = #imageLiteral(resourceName: "ic_signal_blank")
                    imgDroneConnected.image = #imageLiteral(resourceName: "ic_drone_not_connected")
                    lblFlyingMode.text = ""
                    lblSateliteCount.text = "0"

                }
                flightController.simulator?.delegate = self
                flightController.delegate = self
                self.lblTransmissionTime.text = "I/O Time: 0.0 sec"
                self.lblTransmissionTime.isHidden = false
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            }
            
        }else{
            imgRCSignalStrength.image = #imageLiteral(resourceName: "ic_signal_blank")
            imgCameraSignal.image = #imageLiteral(resourceName: "ic_signal_blank")
            imgDroneConnected.image = #imageLiteral(resourceName: "ic_drone_not_connected")
            lblFlyingMode.text = ""
            lblSateliteCount.text = "0"
            lblDroneBatteryStatus.text = "\(0)%"
            
           imgDroneBattery.image = #imageLiteral(resourceName: "ic_battery_locator_empty")
            lblDroneName.text = "Not Connected"
            proxy.sharedProxy().displayStatusCodeAlert("Connection lost.")
            self.imgTagRight.image = UIImage(named:"tag_right")
           self.lblTransmissionTime.text = "I/O Time: 0.0 sec"
            self.lblTransmissionTime.isHidden = true
            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
            //Delete home coordinates
            for someAnnotation in annotationsToRemove {
                let strId = "\(zoneCreateModal.id)"
                if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                    let annotaion = someAnnotation as! LandingPointAnnotationModal
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
                
                if someAnnotation.isKind(of: WaypointAnnotation.self) {
                    let annotaion = someAnnotation as! WaypointAnnotation
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
            }
        }
    }
    
    func simulator(_ simulator: DJISimulator, update state: DJISimulatorState) {
        if CLLocationCoordinate2DIsValid(CLLocationCoordinate2DMake(state.latitude, state.longitude)) {
            self.droneLocationCoordinate = CLLocationCoordinate2DMake(state.latitude, state.longitude)
            lblAltitudeX.text =  String(format: "Altitude X: %0.2f m",state.positionX)
            lblAltitudeY.text = String(format: "Altitude Y: %0.2f m",state.positionY)
            lblAltitudeZ.text = String(format: "Altitude Z: %0.2f m",state.positionZ)
        }
    }
    
    func battery(_ battery: DJIBattery, didUpdate batteryState: DJIBatteryState) {
        if battery.isConnected == true {
            lblDroneBatteryStatus.text = "\(batteryState.batteryEnergyRemainingPercent)%"
            let batteryLevel = batteryState.batteryEnergyRemainingPercent
            if batteryLevel < 10  {
                imgDroneBattery.image = #imageLiteral(resourceName: "ic_battery_locator_empty")
            }else if batteryLevel > 10 && batteryLevel <= 25  {
                imgDroneBattery.image = #imageLiteral(resourceName: "ic_battery_locator_one")
            }else if batteryLevel >= 25 && batteryLevel <= 50{
                imgDroneBattery.image = #imageLiteral(resourceName: "ic_battery_locator_two")
            }else if batteryLevel >= 50 && batteryLevel <= 90{
                imgDroneBattery.image = #imageLiteral(resourceName: "ic_battery_locator_three")
            }else {
             imgDroneBattery.image = #imageLiteral(resourceName: "ic_battery_locator_full")
            }
        }
    }
    

    func flightController(_ fc: DJIFlightController, didUpdateSystemState state: DJIFlightControllerCurrentState) {
        
        if fc.isConnected == true {
            imgRCSignalStrength.image = #imageLiteral(resourceName: "ic_signal_five")
            imgCameraSignal.image = #imageLiteral(resourceName: "ic_signal_five")
            
        }else{
            imgRCSignalStrength.image = #imageLiteral(resourceName: "ic_signal_blank")
            imgCameraSignal.image = #imageLiteral(resourceName: "ic_signal_blank")
            
        }
        
        if fc.isConnected == true {
            lblDroneName.text = fc.product!.model
            imgDroneConnected.image = #imageLiteral(resourceName: "ic_drone_up")
        }else{
            lblDroneName.text = "Not Connected"
            imgDroneConnected.image = #imageLiteral(resourceName: "ic_drone_not_connected")
        }

        if self.btnStartGridMission.isSelected == true {
            
           let  targetLocationToReach = self.arrLocationsReal[self.arrLocationsReal.count - 1]
            let loc1: CLLocation = CLLocation(latitude: targetLocationToReach.coordinate.latitude, longitude: targetLocationToReach.coordinate.longitude)
             let loc2: CLLocation = CLLocation(latitude: self.droneLocationCoordinate.latitude, longitude:  self.droneLocationCoordinate.longitude)
            if Float(loc1.distance(from: loc2)) <= 0.5 {
                self.btnStartGridMission.setTitle("Start Mission", for: .normal)
                self.btnStartGridMission.isSelected = false
                self.sliderSpeedWhileWaypointMission.isUserInteractionEnabled = true
                self.sliderAltitudeWhileWaypointMission.isUserInteractionEnabled = true
                self.sliderGridGap.isUserInteractionEnabled = true
                self.sliderRotateGrid.isUserInteractionEnabled = true
            }
        }
        
        lblFlyingMode.text = "\(state.flightModeString)"
        lblSateliteCount.text = "\(state.satelliteCount)"
        
        let methodStart = NSDate()
        let methodFinish = NSDate()
         executionTime = methodFinish.timeIntervalSince(methodStart as Date)
        let executeTime = Float(self.executionTime)
        self.lblTransmissionTime.text =  String(format: "I/O Time: %0.8f sec",executeTime)
        // Set latency signal
        UIView.animate(withDuration: 2.5 , delay: 0.5, options: UIViewAnimationOptions.curveEaseOut, animations: {
            self.imgTagRight.image = UIImage(named:"tag_right")
        }, completion: { (true) in
            self.imgTagRight.image = UIImage(named:"tag_right_blue")
            UIView.animate(withDuration: 2.5 , delay: 0.5, options: UIViewAnimationOptions.curveEaseOut, animations: {
                 self.imgTagRight.image = UIImage(named:"tag_right")
            }, completion: { (true) in
               self.imgTagRight.image = UIImage(named:"tag_right_blue")
            })
        })
        if CLLocationCoordinate2DIsValid(state.aircraftLocation) {
        self.droneLocationCoordinate = state.aircraftLocation
            if btnStartSimulator.isSelected == true {
               
                        let messageDict = NSMutableDictionary()
                        messageDict.setObject(self.droneLocationCoordinate.latitude, forKey: "lat" as NSCopying)
                        messageDict.setObject(self.droneLocationCoordinate.longitude, forKey: "lng" as NSCopying)
                        messageDict.setObject(userId, forKey: "id" as NSCopying)
                        messageDict.setObject(Float(Double(state.attitude.yaw).degreesToRadians), forKey: "heading" as NSCopying)
                        messageDict.setObject(Int(1), forKey: "state_id" as NSCopying)
                        messageDict.setObject(self.isWayPointFromWebStarted, forKey: "isWayPointFromWebStarted" as NSCopying)
                        self.client.publish(messageDict, toChannel: "\(self.zoneCreateModal.name)_for_tracker",
                            compressed: false, withCompletion: { (status) in
                                if !status.isError {
                                }
                                else{
                                    /**
                                     Handle message publish error. Check 'category' property to find
                                     out possible reason because of which request did fail.
                                     Review 'errorData' property (which has PNErrorData data type) of status
                                     object to get additional information about issue.
                                     Request can be resent using: status.retry()
                                     */
                                }
                        })
                
                self.client.publish(messageDict, toChannel: "\(self.modalEventListOnline.name)_drones",
                    compressed: false, withCompletion: { (status) in
                        if !status.isError {
                        }
                        else{
                            /**
                             Handle message publish error. Check 'category' property to find
                             out possible reason because of which request did fail.
                             Review 'errorData' property (which has PNErrorData data type) of status
                             object to get additional information about issue.
                             Request can be resent using: status.retry()
                             */
                        }
                })
                
            }else{
                    let messageDict = NSMutableDictionary()
                    messageDict.setObject(0.0, forKey: "lat" as NSCopying)
                    messageDict.setObject(0.0, forKey: "lng" as NSCopying)
                    messageDict.setObject(userId, forKey: "id" as NSCopying)
                    messageDict.setObject(Float(Double(state.attitude.yaw).degreesToRadians), forKey: "heading" as NSCopying)
                    messageDict.setObject(Int(0), forKey: "state_id" as NSCopying)
                    messageDict.setObject(self.isWayPointFromWebStarted, forKey: "isWayPointFromWebStarted" as NSCopying)
                
                self.client.publish(messageDict, toChannel: "\(self.zoneCreateModal.name)_for_tracker",
                            compressed: false, withCompletion: { (status) in
                                if !status.isError {
                                    // Message successfully published to specified channel.
                                }
                                else{
                                    /**
                                     Handle message publish error. Check 'category' property to find
                                     out possible reason because of which request did fail.
                                     Review 'errorData' property (which has PNErrorData data type) of status
                                     object to get additional information about issue.
                                     
                                     Request can be resent using: status.retry()
                                     */
                                }
                        })
                
                self.client.publish(messageDict, toChannel: "\(self.modalEventListOnline.name)_drones",
                    compressed: false, withCompletion: { (status) in
                        if !status.isError {
                            // Message successfully published to specified channel.
                        }
                        else{
                            /**
                             Handle message publish error. Check 'category' property to find
                             out possible reason because of which request did fail.
                             Review 'errorData' property (which has PNErrorData data type) of status
                             object to get additional information about issue.
                             
                             Request can be resent using: status.retry()
                             */
                        }
                })
                
                
            }
            
        var isDroneInsideTheZone = Bool()
        let droneLocationPoint =   self.mapVw.convert(state.aircraftLocation, toPointTo: self.mapVw)
        lblGPSData.text = "GPS: \(state.aircraftLocation.latitude), \(state.aircraftLocation.longitude)"
        lblDistanceAboveGround.text = "Altitude: \(state.altitude)"
        current_altitude = state.altitude
        current_RollX = state.velocityX
        current_PitchY = state.velocityY
        lblVelocityXStatus.text = String(format: "Velocity X: %0.1f m/s",state.velocityX)
        let velocity_x = ((state.velocityX/15) * Float(38.5))
            if state.velocityX > 0 {
                cnstXPositiveVelocity.constant = CGFloat(velocity_x)
                cnstXNegativeVelocity.constant = 0
            }else{
               cnstXPositiveVelocity.constant = 0
               cnstXNegativeVelocity.constant = abs(CGFloat(velocity_x))
            }
        lblVelocityYStatus.text = String(format: "Velocity Y: %0.1f m/s",state.velocityY)
           let velocity_y = ((state.velocityY/15) * Float(39))
            if state.velocityY > 0 {
               cnstYNegativeVelocity.constant = 0
                cnstYPositiveVelocity.constant = CGFloat(velocity_y)
            }else{
                cnstYNegativeVelocity.constant = abs(CGFloat(velocity_y))
                cnstYPositiveVelocity.constant = 0
            }
            
        self.current_vertical_speed = state.velocityZ
        lblVelocityZStatus.text = String(format: "Velocity Z: %0.1f m/s",state.velocityZ)
             let velocity_z = ((state.velocityZ/4) * Float(39))
            if state.velocityZ > 0 {
                cnstZPositive.constant = CGFloat(velocity_z)
                cnstZNegative.constant = 0
            }else{
                cnstZPositive.constant = 0
                cnstZNegative.constant =  abs(CGFloat(velocity_z))
                
            }
            
         radianYaw = Double(state.attitude.yaw).degreesToRadians
        if aircraftAnnotation != nil {
            UIView.animate(withDuration: 0.2, delay: 0.1, options: UIViewAnimationOptions.curveEaseOut, animations: {
                self.aircraftAnnotation.setNewCoordinate(state.aircraftLocation)
                }, completion: { (true) in
                    self.aircraftAnnotation.updateHeading(Float(self.radianYaw))
            })
        }else{
            aircraftAnnotation = DroneAnnotation.init(coordiante: state.aircraftLocation,title: "drone_id_\(self.zoneCreateModal.id)" as NSString)
            self.mapVw.addAnnotation(aircraftAnnotation!)
            aircraftAnnotation.setNewCoordinate(state.aircraftLocation)
        }
        
    if let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as? MKPolygon{
        if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)) == true{
            lblStatusDroneIsInZone.text = "Drone in zone: YES"
            isDroneInsideTheZone = true
        }else{
            isDroneInsideTheZone = false
            lblStatusDroneIsInZone.text = "Drone in zone: NO"
        }
        
        if CLLocationCoordinate2DIsValid(self.takeOffCoordinates) {
            let coordinate₀ = CLLocation(latitude: self.droneLocationCoordinate
                .latitude, longitude: self.droneLocationCoordinate.longitude)
            let coordinate₁ = CLLocation(latitude: self.takeOffCoordinates.latitude, longitude: self.takeOffCoordinates.longitude)
            let droneDistanceFromCenterOfDrone = coordinate₀.distance(from: coordinate₁)
            if droneDistanceFromCenterOfDrone < 4 {
              
            }else{
             
            }
        }
        
        if CLLocationCoordinate2DIsValid(self.waypointTargetCoordinate) {
            let coordinate₀ = CLLocation(latitude: self.droneLocationCoordinate
                .latitude, longitude: self.droneLocationCoordinate.longitude)
            let coordinate₁ = CLLocation(latitude: self.waypointTargetCoordinate.latitude, longitude: self.waypointTargetCoordinate.longitude)
            let droneDistanceFromCenterOfDrone = coordinate₀.distance(from: coordinate₁)
            if droneDistanceFromCenterOfDrone < 0.5 {
                self.isWaypointMissionStarted = true
                self.isWayPointFromWebStarted = "0"
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                //Delete home coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: WaypointAnnotation.self) {
                        let annotation = someAnnotation as! WaypointAnnotation
                        if annotation.info == strId {
                            let coordinates = annotation.coordinate
                            self.mapVw.removeAnnotation(someAnnotation)
                            let annotation = WaypointAnnotation.init(title: zoneCreateModal.name, coordinate: coordinates, info: "\(zoneCreateModal.id)", isSelected: true)
                            self.mapVw.addAnnotation(annotation)
                            self.waypointTargetCoordinate = kCLLocationCoordinate2DInvalid
                        }
                    }
                }
            }
        }
        
            //IMPLEMENTING DISTANCE FROM EDGES
            //1.Draw lines and convert location to x-y coordinates
            let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
            let arrDroneLivePositionNearestEdges = NSMutableArray()
            if arrTemp.count > 0{
                for i in 0..<arrTemp.count {
                    //GET LOCATION COORDINATES
                    if i < arrTemp.count-1 {
                        let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i] as! NSMutableDictionary)
                        let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i+1] as! NSMutableDictionary)
                        let droneNearestEdgePoint = proxy.sharedProxy().distanceFromPoint(p: droneLocationPoint, toLineSegment: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosA, mapView: self.mapVw), and: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosB, mapView: self.mapVw))
                        arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                    }else{
                        let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[0] as! NSMutableDictionary)
                        let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[arrTemp.count - 1] as! NSMutableDictionary)
                        let droneNearestEdgePoint = proxy.sharedProxy().distanceFromPoint(p: droneLocationPoint, toLineSegment: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosA, mapView: self.mapVw), and: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosB, mapView: self.mapVw))
                        arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                    }
                }
                
                var minimum_edge_distance = (arrDroneLivePositionNearestEdges[0] as! NSDictionary).object(forKey: "minimum_distance") as! CGFloat
                var indexPosition = 0
               
                //2.FIND MINIMUM COORDINATES DISTANCE EDGE
                for i in 0..<arrDroneLivePositionNearestEdges.count{
                    let dictEdgeInfo = arrDroneLivePositionNearestEdges[i] as! NSDictionary
                    let edge_distance = dictEdgeInfo.object(forKey: "minimum_distance") as! CGFloat
                    if edge_distance <= minimum_edge_distance {
                        minimum_edge_distance = edge_distance
                        indexPosition = i
                    }
                }
                
                //3.GET DISTANCE BETWEEN TWO LATITUDE AND LONGITUDE
                let xPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "xPos") as! CGFloat
                let yPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "yPos") as! CGFloat
                let droneNearestPointInCoordinateSytem = CGPoint(x: xPosition, y: yPosition)
                let locationCoordinate = mapVw.convert(droneNearestPointInCoordinateSytem,toCoordinateFrom: mapVw)
                let coordinate₀ = CLLocation(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)
                let coordinate₁ = CLLocation(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude)
                distanceInMeters = Float(proxy.sharedProxy().getDistanceInm(coordinate₀, from: coordinate₁))
               
                if isDroneInsideTheZone == false {
                     self.lblDistanceToNearestBoundary.text = String(format: "Distance to nearest boundary: %0.2f m",-distanceInMeters)
                }else{
                  self.lblDistanceToNearestBoundary.text = String(format: "Distance to nearest boundary: %0.2f m",distanceInMeters)
                }
               
            }
          }
        }
    }
    
    func remoteController(_ rc: DJIRemoteController, didUpdate gpsData: DJIRCGPSData) {
        
    }
    
    func missionManager(_ manager: DJIMissionManager, missionProgressStatus missionProgress: DJIMissionProgressStatus) {
        if (missionProgress is DJIWaypointMissionStatus) {
                        let wpmissionStatus: DJIWaypointMissionStatus = missionProgress as! DJIWaypointMissionStatus
            if wpmissionStatus.isWaypointReached == true {
                if self.btnStartGridMission.isSelected == true {
                  //  self.btnStartGridMission.setTitle("Start Mission", for: .normal)
                 //   self.btnStartGridMission.isSelected = false

                }
           }
        }
    }
    
    //MARK: - CAMERA DELEGATE
    func camera(_ camera: DJICamera, didReceiveVideoData videoBuffer: UnsafeMutablePointer<UInt8>, length size: Int){
       VideoPreviewer.instance().push(videoBuffer, length: Int32(size))
    }
    
    func pubNubClientSetup() {
        // Initialize and configure PubNub client instance
        let configuration = PNConfiguration(publishKey: "pub-c-c7f0f4cd-a093-4792-bb6b-23dd363eba3f", subscribeKey: "sub-c-ac2a3432-cc27-11e6-bb2e-02ee2ddab7fe")
        self.client = PubNub.clientWithConfiguration(configuration)
        self.client.addListener(self)
        self.arrPubNubChannels.removeAll()
            let web_browser = "zone_id_\(self.zoneCreateModal.id)"
            let kinect_chanel = "\(self.zoneCreateModal.name)_kinect"
        
            let multiple_drone_channel = "\(self.modalEventListOnline.name)_drones"
            self.arrPubNubChannels.append(multiple_drone_channel)
            self.arrPubNubChannels.append(self.zoneCreateModal.name)
            self.arrPubNubChannels.append(web_browser)
            self.arrPubNubChannels.append(kinect_chanel)
            self.client.subscribeToChannels(self.arrPubNubChannels, withPresence: false)
//           testingTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self,
//                                            selector: #selector(testingPubNub), userInfo: nil, repeats: true)
    }

    //MARK: - PubNub Delegate
    
    // Handle new message from one of channels on which client has been subscribed.
    func client(_ client: PubNub, didReceiveMessage message: PNMessageResult) {
        // Handle new message stored in message.data.message
        if message.data.channel != message.data.subscription {
            // Message has been received on channel group stored in message.data.subscription.
        }
        else {
            // Message has been received on channel stored in message.data.channel.
            //"\(self.modalEventListOnline.name)_drones"
        }
        

        if message.data.channel == "\(self.modalEventListOnline.name)_drones" {
            if  let receivedMessage = message.data.message as? NSDictionary{
                let lng : CLLocationDegrees! = receivedMessage["lng"] as! Double
                let lat : CLLocationDegrees! = receivedMessage["lat"] as! Double
                let heading_drone  = receivedMessage["heading"] as! Float
                let state_id_drone = (receivedMessage.object(forKey: "state_id") as! NSNumber) as Int
                let str_drone_id = (receivedMessage.object(forKey: "id") as! NSNumber) as Int
                let droneCoordinates = CLLocationCoordinate2DMake(lat, lng)
                if str_drone_id != userId {
                    if state_id_drone == 1 {
//                        print("State Id , Received message: \(message.data.message) on channel \(message.data.channel) " +
//                            "at \(message.data.timetoken)")
                        if dictMultipleDroneList.object(forKey: str_drone_id) != nil {
                            let tracker_annotation = self.dictMultipleDroneList.object(forKey: str_drone_id) as! DroneAnnotation
                            UIView.animate(withDuration: 0.2, delay: 0.1, options: UIViewAnimationOptions.curveEaseOut, animations: {
                                tracker_annotation.setNewCoordinate(droneCoordinates )
                            }, completion: { (true) in
                                tracker_annotation.updateHeading(Float(heading_drone))
                            })
                            
                        }else{
                            let tracker_annotation = DroneAnnotation.init(coordiante: droneCoordinates,title: "\(str_drone_id)" as NSString)
                            self.mapVw.addAnnotation(tracker_annotation)
                            tracker_annotation.setNewCoordinate(droneCoordinates)
                            self.dictMultipleDroneList.setObject(tracker_annotation, forKey: str_drone_id as NSCopying)
                        }
                        
                    }else{
                        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                        for someAnnotation in annotationsToRemove {
                            if someAnnotation.isKind(of: DroneAnnotation.self) {
                                let annotation = someAnnotation as! DroneAnnotation
                                if (annotation.title!) == "\(str_drone_id)" {
                                    self.mapVw.removeAnnotation(annotation)
                                    dictMultipleDroneList.removeObject(forKey: str_drone_id)
                                }
                            }
                        }
                    }
                }
            }
        }
        
        
        if message.data.channel == "\(zoneCreateModal.name)" {
            if  let receivedMessage = message.data.message as? NSDictionary{
                let lng : CLLocationDegrees! = receivedMessage["lng"] as! Double
                let lat : CLLocationDegrees! = receivedMessage["lat"] as! Double
                let heading_tracker  = receivedMessage["heading"] as! Float
                let state_id_tracker = (receivedMessage.object(forKey: "state_id") as! NSNumber) as Int
                let str_tracker_id = receivedMessage["id"] as! String
                let trackerLocation_Coordinates = CLLocationCoordinate2DMake(lat, lng)
                if state_id_tracker == 1 {
                    if dictMultipleTrakerList.object(forKey: str_tracker_id) != nil {
                        let tracker_annotation = self.dictMultipleTrakerList.object(forKey: str_tracker_id) as! UserAnnotation
                        UIView.animate(withDuration: 0.2, delay: 0.1, options: UIViewAnimationOptions.curveEaseOut, animations: {
                            tracker_annotation.setNewCoordinate(trackerLocation_Coordinates )
                        }, completion: { (true) in
                            tracker_annotation.updateHeading(Float(heading_tracker))
                        })
                        
                    }else{
                        let tracker_annotation = UserAnnotation.init(coordiante: trackerLocation_Coordinates,title: "\(str_tracker_id)" as NSString)
                        self.mapVw.addAnnotation(tracker_annotation)
                        tracker_annotation.setNewCoordinate(trackerLocation_Coordinates)
                        self.dictMultipleTrakerList.setObject(tracker_annotation, forKey: str_tracker_id as NSCopying)
                    }

                }else{
                    let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                    for someAnnotation in annotationsToRemove {
                       if someAnnotation.isKind(of: UserAnnotation.self) {
                       let annotation = someAnnotation as! UserAnnotation
                       if (annotation.title!) == str_tracker_id {
                         self.mapVw.removeAnnotation(annotation)
                        dictMultipleTrakerList.removeObject(forKey: str_tracker_id)
                            }
                       }
                   }
                }
                
//                if state_id_tracker == 1 {
//                    self.trackerLocationCoordinates = CLLocationCoordinate2DMake(lat, lng)
//                    if self.trackerAnnotation != nil {
//                        UIView.animate(withDuration: 0.2, delay: 0.1, options: UIViewAnimationOptions.curveEaseOut, animations: {
//                    self.trackerAnnotation.setNewCoordinate(self.trackerLocationCoordinates )
//                        }, completion: { (true) in
//                            self.trackerAnnotation.updateHeading(Float(heading_tracker))
//                        })
//                    }else{
//                        self.trackerAnnotation = UserAnnotation.init(coordiante: trackerLocationCoordinates,title: "\(str_tracker_id)" as NSString)
//                        self.mapVw.addAnnotation(self.trackerAnnotation )
//                        self.trackerAnnotation.setNewCoordinate(trackerLocationCoordinates)
//                    }
//                }else{
//                    let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
//                    //Delete tracker coordinates
//                    for someAnnotation in annotationsToRemove {
//                        if someAnnotation.isKind(of: UserAnnotation.self) {
//                            self.mapVw.removeAnnotation(someAnnotation)
//                            self.trackerAnnotation = nil
//                        }
//                    }
//                }
            }
        }
        
        let web_browser = "zone_id_\(self.zoneCreateModal.id)"
        if message.data.channel == web_browser {
            if  let receivedMessage = message.data.message as? NSDictionary{
                //Delete previous annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                //Delete home coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: WaypointAnnotation.self) {
                        let annotation = someAnnotation as! WaypointAnnotation
                        if annotation.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                let lng : CLLocationDegrees! = receivedMessage["lng"] as! Double
                let lat : CLLocationDegrees! = receivedMessage["lat"] as! Double
                self.waypointTargetCoordinate = CLLocationCoordinate2DMake(lat, lng)
                if let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as? MKPolygon{
                    if isInsideThePolygon(polygon,sampleLocation: self.waypointTargetCoordinate) == true{
                        let annotation = WaypointAnnotation.init(title: zoneCreateModal.name, coordinate: self.waypointTargetCoordinate, info: "\(zoneCreateModal.id)", isSelected: false)
                        self.mapVw.addAnnotation(annotation)
                        self.startWayPointMission(targetLocation: self.waypointTargetCoordinate,isWayPointMissionFromWebStarted:true)
                    }else{
                        proxy.sharedProxy().displayStatusCodeAlert("Please place marker inside the zone.")
                    }
                }
            }
        }
            let kinectChannel = "\(self.zoneCreateModal.name)_kinect"
      //  print("Received message: \(message.data.message) on channel \(message.data.channel) " +
           // "at \(message.data.timetoken)")

            if message.data.channel == kinectChannel {
//                print("Received message: \(message.data.message) on channel \(message.data.channel) " +
//                    "at \(message.data.timetoken)")
            if current_altitude > 0 {
            if  let receivedMessage = message.data.message as? NSDictionary{
         
            /*
                         dictionary.Add("pos_head_x", joints[JointType.Head].Position.X);
                         dictionary.Add("pos_head_y", joints[JointType.Head].Position.Y);
                         dictionary.Add("pos_head_z", joints[JointType.Head].Position.Z);
                         
                         dictionary.Add("pos_rightHand_x", joints[JointType.HandRight].Position.X);
                         dictionary.Add("pos_rightHand_y", joints[JointType.HandRight].Position.Y);
                         dictionary.Add("pos_rightHand_z", joints[JointType.HandRight].Position.Z);
                         
                         dictionary.Add("pos_leftHand_x", joints[JointType.HandLeft].Position.X);
                         dictionary.Add("pos_leftHand_y", joints[JointType.HandLeft].Position.Y);
                         dictionary.Add("pos_leftHand_z", joints[JointType.HandLeft].Position.Z);
                    */
                
                 var mX_Velocity = (receivedMessage.object(forKey: "pos_leftHand_x") as! Float) * DJIVirtualStickRollPitchControlMaxVelocity
                var mY_Velocity = (receivedMessage.object(forKey: "pos_leftHand_z") as! Float) * DJIVirtualStickRollPitchControlMaxVelocity
                
                if mX_Velocity > 15.0{
                
                    mX_Velocity = 15.0
                }
                
                if mX_Velocity < -15.0 {
                    mX_Velocity = -15.0
                }
                
                if mY_Velocity > 15.0{
                    
                    mX_Velocity = 15.0
                }
                
                if mY_Velocity < -15.0 {
                    mX_Velocity = -15.0
                }
                
                
                let delay = 10.0 * Double(NSEC_PER_SEC)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                    
                    let pos_leftHand_y = (receivedMessage.object(forKey: "pos_leftHand_y") as! Float) * 4
                    self.min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
                    let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                    let distanceToMinAltitude =   self.min_height - self.current_altitude
                    let distanceToMaxAltitude =   max_height - self.current_altitude
                    let throttle = self.positionControllerVertical(distanceToMinAltitude,distanceToMaxAltitude:distanceToMaxAltitude, actualVerticalSpeed: self.current_vertical_speed,verticalValue:  pos_leftHand_y)
                    debugPrint(" Calculated throttle: \(throttle)")
                    var ctrlData = DJIVirtualStickFlightControlData()
                    ctrlData.verticalThrottle = throttle
                    ctrlData.pitch = mY_Velocity
                    ctrlData.roll = mX_Velocity
                    let fc = DroneUtility.fetchFlightController()
                    if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                        fc?.send(ctrlData, withCompletion: { (error) in
                            if error?.localizedDescription.characters.count > 0
                            {
                                // proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                            }
                        })
                    }
                    

                }
                
                
                    }
                }
        }
        
        
        
     }
    
    @IBAction func switchActionRollPitch(_ sender: Any) {
        
        
    }
    @IBAction func switchActionVertical(_ sender: Any) {
        
        
    }

    func startWayPointMission(targetLocation:CLLocationCoordinate2D,isWayPointMissionFromWebStarted:Bool){
        
        if let flightController = DroneUtility.fetchFlightController(){
            // Clears previous mission
            self.waypointMission.removeAllWaypoints()
            //1. Find ways points
            let wayPointCoordinate =
                NSMutableArray()
            wayPointCoordinate.add(droneLocationCoordinate)
            wayPointCoordinate.add(targetLocation)
            //2. Prepare mission
            for i in 0..<wayPointCoordinate.count{
                let someLocation = wayPointCoordinate[i] as! CLLocationCoordinate2D
                if CLLocationCoordinate2DIsValid(someLocation) == true{
                    let wayPoint = DJIWaypoint.init(coordinate: someLocation)
                    wayPoint.altitude = current_altitude
                    wayPoint.cornerRadiusInMeters = 2.5
                    self.waypointMission.add(wayPoint)
                }
            }
            //3.Set flight controls
            self.waypointMission.maxFlightSpeed = 15.0
            self.waypointMission.autoFlightSpeed = 12.0
            self.waypointMission.headingMode = .auto
            self.waypointMission.gotoFirstWaypointMode = .pointToPoint
            self.waypointMission.flightPathMode = .normal
            self.waypointMission.finishedAction = .noAction
            //4.Prepare mission
            self.missionManager.prepare(self.waypointMission, withProgress: { (progress) in
            }, withCompletion: { (error) in
                if error?.localizedDescription.characters.count > 0{
                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                }else{
                    self.missionManager.startMissionExecution(completion: { (error) in
                if error?.localizedDescription.characters.count > 0{
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                        }else{
                            proxy.sharedProxy().displayStatusCodeAlert("Waypoint mission started..")
                            self.isWaypointMissionStarted = false
                    if isWayPointMissionFromWebStarted == true{
                            self.isWayPointFromWebStarted = "1"
                        if self.trackerId.characters.count != 0 {
                            let messageDict = NSMutableDictionary()
                            messageDict.setObject(self.droneLocationCoordinate.latitude, forKey: "lat" as NSCopying)
                            messageDict.setObject(self.droneLocationCoordinate.longitude, forKey: "lng" as NSCopying)
                            messageDict.setObject(self.userId, forKey: "id" as NSCopying)
                            messageDict.setObject(Float(self.radianYaw), forKey: "heading" as NSCopying)
                            messageDict.setObject(Int(1), forKey: "state_id" as NSCopying)
                            messageDict.setObject(self.isWayPointFromWebStarted, forKey: "isWayPointFromWebStarted" as NSCopying)
                            self.client.publish(messageDict, toChannel: "\(self.zoneCreateModal.name)_for_tracker",
                                compressed: false, withCompletion: { (status) in
                                    if !status.isError {
                                    }
                                    
                            })
                        }
                    }
                        }
                    })
                }
            })
            
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            self.deleteWaypointAnnotation()
        }
    }

    func deleteWaypointAnnotation() {
        //Delete previous annotation
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        //Delete home coordinates
        for someAnnotation in annotationsToRemove {
            let strId = "\(zoneCreateModal.id)"
            if someAnnotation.isKind(of: WaypointAnnotation.self) {
                let annotation = someAnnotation as! WaypointAnnotation
                if annotation.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
        self.waypointTargetCoordinate = kCLLocationCoordinate2DInvalid
    }
    
    @IBAction func btnActionStartGridMission(_ sender: Any) {
         self.segmentLines.removeAllObjects()
        let viewRotate = UIView.init(frame: self.mapVw.frame)
         viewRotate.rotate(angle: CGFloat(Int32(self.sliderRotateGrid.value)))
         segmentLines = proxy.sharedProxy().getSegmentsRotate(viewRotate, numberOfDivisions: Int32(self.sliderGridGap.value),angle: Double(self.sliderRotateGrid.value),initialView: UIView.init(frame: self.mapVw.frame))
        self.lblRotateGridAtAngle.text = "Rotate Grid Angle:  \(Int32(self.sliderRotateGrid.value))"
        if segmentLines.count > 0{
            let dict1 = segmentLines[0] as! NSMutableDictionary
            let point1 = dict1.object(forKey: "point_p1") as! CGPoint
            let locationCoordinate1 = self.mapVw.convert(point1,toCoordinateFrom: self.mapVw)
            let loc1: CLLocation = CLLocation(latitude: locationCoordinate1.latitude, longitude: locationCoordinate1.longitude)
            let dict2 = segmentLines[1] as! NSMutableDictionary
            let point2 = dict2.object(forKey: "point_p1") as! CGPoint
            let locationCoordinate2 = self.mapVw.convert(point2,toCoordinateFrom: self.mapVw)
            let loc2: CLLocation = CLLocation(latitude: locationCoordinate2.latitude, longitude: locationCoordinate2.longitude)
            let distance = String(format: "Grid Gap:  %0.1f m",loc1.distance(from: loc2))
            self.lblGridGapInMeter.text = distance
        }
        
         self.cnstGridMissionSetup.constant = 4.0
          let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
        let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
        sliderAltitudeWhileWaypointMission.minimumValue = min_height
        sliderAltitudeWhileWaypointMission.maximumValue = max_height
        var arrAnnotation = [MKAnnotation]()
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        if Int32(userId) == zoneCreateModal.create_user_id {
            //Polygon pin points
            for someAnnotation in annotationsToRemove {
                let strId = "\(zoneCreateModal.id)"
                if someAnnotation.isKind(of: AnnotationModal.self) {
                    let annotation = someAnnotation as! AnnotationModal
                    if annotation.info == strId {
                        arrAnnotation.append(annotation)
                    }
                }
            }
            self.mapVw.showAnnotations(arrAnnotation, animated: true)
            let gridDivion = sliderGridGap.value
            self.getGridWayPointMission(Int32(gridDivion),isDrawLines:true)
            self.lblWayPointQty.text = "\(arrLocations.count) PTS"
            

        }
        
    }
    
    func getGridWayPointMission(_ numberOfDivisions:Int32,isDrawLines:Bool) {
        
        if isDrawLines == true {
            //Clear previous shapes
            linePath.removeAllPoints()
            self.vw.removeFromSuperview()
            self.line.removeFromSuperlayer()
            for subView in vw.subviews {
                subView.removeFromSuperview()
            }
        }
        let viewRotate = UIView.init(frame: self.mapVw.frame)
        viewRotate.rotate(angle: CGFloat(Int32(self.sliderRotateGrid.value)))
        self.lblRotateGridAtAngle.text = "Rotate Grid Angle:  \(Int32(self.sliderRotateGrid.value))"
        self.gridView = UIView.init(frame: self.mapVw.frame)
        //let segmentLines = proxy.sharedProxy().getSegments(viewRotate, numberOfDivisions: numberOfDivisions,angle: Double(sliderRotateGrid.value))
        let arrZones = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
        let arrPoints = NSMutableArray()
        var zoneLoc = CLLocationCoordinate2D()
        //Convert lat and longitude to x and y pos of zone
        for i in 0 ..< arrZones.count {
            let dict = arrZones[i] as! NSMutableDictionary
            let lat = dict["lat"] as! String
            let long = dict["longt"] as! String
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            zoneLoc.latitude = Double(newLat)!
            zoneLoc.longitude = Double(newLong)!
            let point = self.mapVw.convert(zoneLoc, toPointTo: self.mapVw)
            let dictPoints = NSMutableDictionary()
            dictPoints.setObject(point, forKey: "pos" as NSCopying)
            arrPoints.add(dictPoints)
        }
        
         print("Polygon points:",arrPoints)
        
        //Get line segments from polygon points
        let polygonSegmentPoints = NSMutableArray()
        for i  in 0..<arrPoints.count {
            if i < arrPoints.count - 1 {
                let dict1 = arrPoints[i] as! NSMutableDictionary
                let dict2 = arrPoints[i+1] as! NSMutableDictionary
                let p1 = dict1.object(forKey: "pos") as! CGPoint
                let p2 = dict2.object(forKey: "pos") as! CGPoint
                let dict =  NSMutableDictionary()
                dict.setObject(p1, forKey: "polygon_p1" as NSCopying)
                dict.setObject(p2, forKey: "polygon_p2" as NSCopying)
                polygonSegmentPoints.add(dict)
            }else{
                let dict1 = arrPoints[0] as! NSMutableDictionary
                let dict2 = arrPoints[arrPoints.count - 1] as! NSMutableDictionary
                let p1 = dict1.object(forKey: "pos") as! CGPoint
                let p2 = dict2.object(forKey: "pos") as! CGPoint
                let dict =  NSMutableDictionary()
                dict.setObject(p1, forKey: "polygon_p1" as NSCopying)
                dict.setObject(p2, forKey: "polygon_p2" as NSCopying)
                polygonSegmentPoints.add(dict)
            }
        }
        
         print("Polygon segments:",polygonSegmentPoints)
        let arrIntersectionpoints = proxy.sharedProxy().getIntersectionOfSegmentAndPolygon(arrLineSegments: segmentLines, arrPolygonCoordinates: polygonSegmentPoints)
        print("Intersecting segments:",arrIntersectionpoints)
       
        let arrPairedLines = NSMutableArray()
        let steps = arrIntersectionpoints.count
        if steps%2 == 0 {
        var  i =  0
        var next = 2
        while i < (arrIntersectionpoints.count/2 ) {
            if i%2 == 0 {
                let dictPair = NSMutableDictionary()
                let dict1 = arrIntersectionpoints[next-2] as! NSMutableDictionary
                let dict2 = arrIntersectionpoints[next-1] as! NSMutableDictionary
                dictPair.setObject(dict1, forKey: "p1" as NSCopying)
                dictPair.setObject(dict2, forKey: "p2" as NSCopying)
                arrPairedLines.add(dictPair)
                next = next + 2
            }else{
                    let dictPair = NSMutableDictionary()
                    let dict1 = arrIntersectionpoints[next-1] as! NSMutableDictionary
                    let dict2 = arrIntersectionpoints[next-2] as! NSMutableDictionary
                    dictPair.setObject(dict1, forKey: "p1" as NSCopying)
                    dictPair.setObject(dict2, forKey: "p2" as NSCopying)
                    arrPairedLines.add(dictPair)
                    next = next + 2
                
    }
            i = i + 1
        }
        print("Final dictionary:",arrPairedLines)
        }else{
        var  i =  0
        var next = 2
        while i < (arrIntersectionpoints.count/2  ){
            if i%2 == 0 {
                let dictPair = NSMutableDictionary()
                let dict1 = arrIntersectionpoints[next-2] as! NSMutableDictionary
                let dict2 = arrIntersectionpoints[next-1] as! NSMutableDictionary
                dictPair.setObject(dict1, forKey: "p1" as NSCopying)
                dictPair.setObject(dict2, forKey: "p2" as NSCopying)
                arrPairedLines.add(dictPair)
                next = next + 2
            }else{
                    let dictPair = NSMutableDictionary()
                    let dict1 = arrIntersectionpoints[next-1] as! NSMutableDictionary
                    let dict2 = arrIntersectionpoints[next-2] as! NSMutableDictionary
                    dictPair.setObject(dict1, forKey: "p1" as NSCopying)
                    dictPair.setObject(dict2, forKey: "p2" as NSCopying)
                    arrPairedLines.add(dictPair)
                    next = next + 2
            }
            i = i + 1
        }
        print("Final dictionary:",arrPairedLines)

    }
      var distance = Float()
        for i in 0..<arrPairedLines.count {
             let dictOuter = arrPairedLines[i] as! NSMutableDictionary
            if i%2 == 0{
                let dict1 = dictOuter.object(forKey: "p1") as! NSMutableDictionary
                let point1 = dict1.object(forKey: "intersection_points") as! CGPoint
                let locationCoordinate1 = mapVw.convert(point1,toCoordinateFrom: mapVw)
                let loc1: CLLocation = CLLocation(latitude: locationCoordinate1.latitude, longitude: locationCoordinate1.longitude)
                 arrLocations.append(loc1)
                arrLocationsReal.append(loc1)
                let dict2 = dictOuter.object(forKey: "p2") as! NSMutableDictionary
                let point2 = dict2.object(forKey: "intersection_points") as! CGPoint
                let locationCoordinate2 = mapVw.convert(point2,toCoordinateFrom: mapVw)
                
                let loc2: CLLocation = CLLocation(latitude: locationCoordinate2.latitude, longitude: locationCoordinate2.longitude)
                arrLocations.append(loc2)
                arrLocationsReal.append(loc2)
                if i+1 < arrPairedLines.count {
                    let dictOuterNext = arrPairedLines[i+1] as! NSMutableDictionary
                    let dict3 = dictOuterNext.object(forKey: "p1") as! NSMutableDictionary
                    let point3 = dict3.object(forKey: "intersection_points") as! CGPoint
                    let locationCoordinate3 = mapVw.convert(point3,toCoordinateFrom: mapVw)
                    
                    let loc3: CLLocation = CLLocation(latitude: locationCoordinate3.latitude, longitude: locationCoordinate3.longitude)
                    arrLocations.append(loc3)
                   // arrLocationsReal.append(loc3)
                }
            }else{
                let dict1 = dictOuter.object(forKey: "p1") as! NSMutableDictionary
                let point1 = dict1.object(forKey: "intersection_points") as! CGPoint
                let locationCoordinate1 = mapVw.convert(point1,toCoordinateFrom: mapVw)
                let loc1: CLLocation = CLLocation(latitude: locationCoordinate1.latitude, longitude: locationCoordinate1.longitude)
                arrLocations.append(loc1)
                 arrLocationsReal.append(loc1)
                let dict2 = dictOuter.object(forKey: "p2") as! NSMutableDictionary
                let point2 = dict2.object(forKey: "intersection_points") as! CGPoint
                let locationCoordinate2 = mapVw.convert(point2,toCoordinateFrom: mapVw)
                
                let loc2: CLLocation = CLLocation(latitude: locationCoordinate2.latitude, longitude: locationCoordinate2.longitude)
                arrLocations.append(loc2)
                arrLocationsReal.append(loc2)
                if i+1 < arrPairedLines.count {
                    let dictOuterNext = arrPairedLines[i+1] as! NSMutableDictionary
                    let dict3 = dictOuterNext.object(forKey: "p1") as! NSMutableDictionary
                    let point3 = dict3.object(forKey: "intersection_points") as! CGPoint
                    let locationCoordinate3 = mapVw.convert(point3,toCoordinateFrom: mapVw)
                   
                    let loc3: CLLocation = CLLocation(latitude: locationCoordinate3.latitude, longitude: locationCoordinate3.longitude)
                    arrLocations.append(loc3)
                    //arrLocationsReal.append(loc3)
                }
                
            }
        }
        if isDrawLines == false {
            if arrLocationsReal.count > 1 {
                self.makePrefixGrid()
            }
            
        }
                let numberOfSteps: Int =  arrLocations.count
                var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
                for index in 0 ..< numberOfSteps
                {
                    let location: CLLocation =  arrLocations[index]
                    points.append(location.coordinate)
                }
                NSLog("ARRAY COORDINATES:%d",points.count)
                let polyline = MKPolyline(coordinates: &points, count: points.count)
        
        if arrLocations.count > 0 {
            
            if isDrawLines == true {
                //Draw Start Annotatio
                let firstLocation =  arrLocations[0]
                let annotationStart = GridAnnotationStart(title: "", coordinate: firstLocation.coordinate, info: "\(zoneCreateModal.id)",index: "\(0)")
                
                self.mapVw.addAnnotation(annotationStart)
                //Draw End Annotation
                let endLocation =  arrLocations[arrLocations.count-1]
                let annotationEnd = GridAnnotationEnd(title: "", coordinate: endLocation.coordinate, info: "\(zoneCreateModal.id)",index: "\(0)")
                self.mapVw.addAnnotation(annotationEnd)
 
            }
            
            distance = 0.0
            for i in 0..<arrLocations.count {
                if i+1 <  arrLocations.count{
                    let location1: CLLocation =  arrLocations[i]
                    let location2: CLLocation =  arrLocations[i+1]
                    distance = Float(location1.distance(from: location2)) + distance
                }
            }
            
            if isDrawLines == true {
                self.mapVw.add(polyline)
            }

            //Flight Time est.
            self.lblFlightTimeEstimate.text = String(format: "%0.1f min.",(Float(distance)/12.0)/60.0)
        }
      
        
    }
    
    @IBAction func btnActionStartWaypointMission(_ sender: Any) {
        
        if arrLocations.count > 0 && arrLocationsReal.count > 0 {
        if self.btnStartGridMission.isSelected == true {
            self.btnStartGridMission.isSelected = false
            self.sliderSpeedWhileWaypointMission.isUserInteractionEnabled = true
            self.sliderAltitudeWhileWaypointMission.isUserInteractionEnabled = true
            self.sliderGridGap.isUserInteractionEnabled = true
            self.sliderRotateGrid.isUserInteractionEnabled = true
           // self.mapVw.isUserInteractionEnabled = true
            self.btnStartGridMission.setTitle("Start Mission", for: .normal)
            if let flightController = DroneUtility.fetchFlightController(){
               self.missionManager.stopMissionExecution(completion: nil)
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                self.deleteWaypointAnnotation()
            }
        }else{
        
            btnStartGridMission.isSelected = true
            btnStartGridMission.setTitle("Stop Mission", for: .normal)
            self.sliderSpeedWhileWaypointMission.isUserInteractionEnabled = false
            self.sliderAltitudeWhileWaypointMission.isUserInteractionEnabled = false
            self.sliderGridGap.isUserInteractionEnabled = false
            self.sliderRotateGrid.isUserInteractionEnabled = false
           // self.mapVw.isUserInteractionEnabled = false
            if let flightController = DroneUtility.fetchFlightController(){
                // Clears previous mission
                self.waypointMission.removeAllWaypoints()
                //2. Prepare mission
                for i in 0..<arrLocationsReal.count{
                    let someLocation = arrLocationsReal[i]
                    if CLLocationCoordinate2DIsValid(someLocation.coordinate) == true{
                        let wayPoint = DJIWaypoint.init(coordinate: someLocation.coordinate)
                        wayPoint.altitude = sliderAltitudeWhileWaypointMission.value
                        wayPoint.cornerRadiusInMeters = 0.5
                        self.waypointMission.add(wayPoint)
                    }
                }
                //3.Set flight controls
                self.waypointMission.maxFlightSpeed = 15.0
                self.waypointMission.autoFlightSpeed = sliderSpeedWhileWaypointMission.value
                self.waypointMission.headingMode = .auto
                self.waypointMission.gotoFirstWaypointMode = .pointToPoint
                self.waypointMission.flightPathMode = .normal
                self.waypointMission.finishedAction = .noAction
                //4.Prepare mission
                self.missionManager.prepare(self.waypointMission, withProgress: { (progress) in
                    
                    proxy.sharedProxy().displayStatusCodeAlert("Uploading mission: \(progress*100)%")
                    
                }, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0{
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }else{
                        self.missionManager.startMissionExecution(completion: { (error) in
                            if error?.localizedDescription.characters.count > 0{
                                proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Waypoint mission started..")
                            }
                        })
                    }
                })
                
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                self.deleteWaypointAnnotation()
            }
        }
        }else{
        
            proxy.sharedProxy().displayStatusCodeAlert("Error: Empty Waypoints")
        }
    
    }
   
    @IBAction func btnActionCloseGridMissionSetup(_ sender: Any) {
        let delay = 0.5 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
             self.segmentLines.removeAllObjects()
            self.cnstGridMissionSetup.constant = -167.0
            //Remove start and stop annotation
            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
            for someAnnotation in annotationsToRemove {
                if someAnnotation.isKind(of: GridAnnotationStart.self) {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
                
                if someAnnotation.isKind(of: GridAnnotationEnd.self) {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
            
            //Remove overlay
            for overlay in self.mapVw.overlays {
                if overlay.isKind(of: MKPolyline.self) {
                    self.mapVw.removeOverlays([overlay])
                }
            }
            
            //Polygon pin points
            for someAnnotation in annotationsToRemove {
                let strId = "\(self.zoneCreateModal.id)"
                if someAnnotation.isKind(of: AnnotationModal.self) {
                    let annotaion = someAnnotation as! AnnotationModal
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
            }
            
            //1.Remove the previous polygon
            //Remove overlay
            for overlay in self.mapVw.overlays {
                if overlay.isKind(of: MKPolygon.self) {
                    let strTitle = String(validatingUTF8: overlay.title!!)!
                    print("Zone Name : \(strTitle)")
                    if strTitle == self.zoneCreateModal.name {
                        self.mapVw.remove(overlay)
                    }
                }
            }
            
            //Remove divider annotation
            for someAnnotation in annotationsToRemove {
                let strId = "\(self.zoneCreateModal.id)"
                if someAnnotation.isKind(of: DividerAnnotation.self) {
                    let annotaion = someAnnotation as! DividerAnnotation
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
            }
            
            //Remove center coordinate
            for someAnnotation in annotationsToRemove {
                let strId = "\(self.zoneCreateModal.id)"
                if someAnnotation.isKind(of: ZoneNameAnnotationModal.self){
                    let annotaion = someAnnotation as! ZoneNameAnnotationModal
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
            }
              let  arrTemp  = self.dictMainEventList.object(forKey: "\(self.zoneCreateModal.id)") as! NSArray
            if arrTemp.count > 0 {
                self.drawPloygon(arrTemp, strTitle: self.zoneCreateModal.name, strZoneId: "\(self.zoneCreateModal.id)", willShowAnnotaion: false,strCreatedUserId: "\(self.zoneCreateModal.create_user_id)",willShowDistance:false)
            }
            self.arrLocations.removeAll()
            self.arrLocationsReal.removeAll()
        }
    }
    
    func makePrefixGrid() {
        //Clear previous shapes
        linePath.removeAllPoints()
        self.vw.removeFromSuperview()
        self.line.removeFromSuperlayer()
        for subView in vw.subviews {
            subView.removeFromSuperview()
        }
        
        vw.frame = CGRect(x: 0, y: 0, width: self.mapVw.frame.size.width, height: self.mapVw.frame.size.height)
        
        var arrPoints = [CGPoint]()
        if arrLocationsReal.count > 0 {
            for i in 0..<arrLocationsReal.count {
                let location: CLLocation =  arrLocationsReal[i]
                let point = self.mapVw.convert(location.coordinate, toPointTo: self.mapVw)
                arrPoints.append(point)
            }
        }
        let firstPos = arrPoints[0]
        linePath.move(to: firstPos)
        //Shape Layer
        line.frame = vw.frame
        for i in 0 ..< arrPoints.count  {
            let pos = arrPoints[i]
            linePath.addLine(to: pos)
        }
       
        let lastPos = arrPoints[arrPoints.count - 1]
        imgStartView = UIImageView.init(frame: CGRect(x:firstPos.x-20,y: firstPos.y-11,width: 50, height: 22))
        imgLastView = UIImageView.init(frame: CGRect(x:lastPos.x-20 ,y: lastPos.y - 11 ,width: 50, height: 22))
        imgStartView.image = #imageLiteral(resourceName: "ic_start")
        imgLastView.image = #imageLiteral(resourceName: "ic_end")
        vw.addSubview(imgStartView)
        vw.addSubview(imgLastView)
        vw.bringSubview(toFront: imgStartView)
        vw.bringSubview(toFront: imgLastView)
        line.lineWidth = 1.0
        line.path = linePath.cgPath
        line.fillColor = UIColor.clear.cgColor
        line.strokeColor = UIColor(red: 255.0/255, green: 244.0/255, blue: 52.0/255, alpha: 0.70).cgColor
        vw.layer.addSublayer(line)
        vw.backgroundColor = UIColor.clear
        self.mapVw.addSubview(vw)
        self.mapVw.bringSubview(toFront: vw)
    }
    
    @IBAction func sliderActionGridGap(_ sender: Any) {
          self.sliderActionStartGridDraw()
    }
    
    
    @IBAction func btnActionCurrentPosition(_ sender: Any) {
        if UserDefaults.standard.object(forKey: "lat") != nil && UserDefaults.standard.object(forKey: "long") != nil{
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
            let span = MKCoordinateSpanMake(0.001, 0.001)
            let region = MKCoordinateRegion(center: userLoc, span: span)
            mapVw.setRegion(region, animated: true)
            mapVw.showsUserLocation = true
            homeLocationOfUser = userLoc
        }
    }
    
    @IBAction func btnActionSwitchMapType(_ sender: Any) {
        let btnMapType = sender as! UIButton
        if btnMapType.isSelected == true {
            btnMapType.isSelected = false
            mapVw.mapType = .satellite
        }else{
        btnMapType.isSelected = true
            if #available(iOS 9.0, *) {
                mapVw.mapType = .hybridFlyover
            } else {
                mapVw.mapType = .hybrid
            }
        }
        
    }
    
    
    @IBAction func sliderActionGetSpeedForGridMission(_ sender: Any) {
        let speed = String(format: "Speed:  %0.1f m/s",sliderSpeedWhileWaypointMission.value)
        self.lblSpeedWhileGridMission.text = speed
        if arrLocations.count > 0 {
            var  distance = Float()
            for i in 0..<arrLocations.count {
                if i+1 <  arrLocations.count{
                    let location1: CLLocation =  arrLocations[i]
                    let location2: CLLocation =  arrLocations[i+1]
                    distance = Float(location1.distance(from: location2)) + distance
                }
            }
            //Flight Time est.
            self.lblFlightTimeEstimate.text = String(format: "%0.1f min.",(Float(distance)/Float(sliderSpeedWhileWaypointMission.value))/60.0)
        }

    }
    
    @IBAction func sliderActionAltitudeWhileGridMission(_ sender: Any) {
         let altitude = String(format: "Altitude:  %0.1f m",sliderAltitudeWhileWaypointMission.value)
        self.lblAltitudeOfEachWaypoint.text = altitude
    }
    
    @IBAction func sliderActionRotateGrid(_ sender: Any) {
        self.sliderActionStartGridDraw()
    }
    
    
    @IBAction func sliderRotateGridEndState(_ sender: Any) {
         self.sliderActionGridPosStateEnd()
    }
    
    @IBAction func sliderActionGripGapEndState(_ sender: Any) {
        self.sliderActionGridPosStateEnd()
    }
  
    //MARK: - SLIDER ACTION
    func sliderActionGridPosStateEnd() {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            let viewRotate = UIView.init(frame: self.mapVw.frame)
            viewRotate.rotate(angle: CGFloat(Int32(self.sliderRotateGrid.value)))
            self.segmentLines.removeAllObjects()
            self.segmentLines = proxy.sharedProxy().getSegmentsRotate(viewRotate, numberOfDivisions: Int32(self.sliderGridGap.value),angle: Double(self.sliderRotateGrid.value),initialView:UIView.init(frame: self.mapVw.frame))
            self.lblRotateGridAtAngle.text = "Rotate Grid Angle:  \(Int32(self.sliderRotateGrid.value))"
            if self.segmentLines.count > 1{
                
                let dict1 = self.segmentLines[0] as! NSMutableDictionary
                let point1 = dict1.object(forKey: "point_p1") as! CGPoint
                let locationCoordinate1 = self.mapVw.convert(point1,toCoordinateFrom: self.mapVw)
                let loc1: CLLocation = CLLocation(latitude: locationCoordinate1.latitude, longitude: locationCoordinate1.longitude)
                let dict2 = self.segmentLines[1] as! NSMutableDictionary
                let point2 = dict2.object(forKey: "point_p1") as! CGPoint
                let locationCoordinate2 = self.mapVw.convert(point2,toCoordinateFrom: self.mapVw)
                let loc2: CLLocation = CLLocation(latitude: locationCoordinate2.latitude, longitude: locationCoordinate2.longitude)
                let distance = String(format: "Grid Gap:  %0.1f m",loc1.distance(from: loc2))
                self.lblGridGapInMeter.text = distance
                
                //Remove start and stop annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                for someAnnotation in annotationsToRemove {
                    if someAnnotation.isKind(of: GridAnnotationStart.self) {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                    
                    if someAnnotation.isKind(of: GridAnnotationEnd.self) {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
                
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolyline.self) {
                        self.mapVw.removeOverlays([overlay])
                    }
                }
                self.arrLocations.removeAll()
                self.arrLocationsReal.removeAll()
                self.getGridWayPointMission(Int32(self.sliderGridGap.value),isDrawLines:true)
                self.lblWayPointQty.text = "\(self.arrLocationsReal.count) PTS"
            }
        }
    }
    
    
    func sliderActionStartGridDraw() {
        
        let delay = 0.1 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            let viewRotate = UIView.init(frame: self.mapVw.frame)
            self.segmentLines.removeAllObjects()
            viewRotate.rotate(angle: CGFloat(Int32(self.sliderRotateGrid.value)))
            // self.segmentLines = proxy.sharedProxy().getSegments(viewRotate, numberOfDivisions: Int32(self.sliderGridGap.value),angle: Double(self.sliderRotateGrid.value),initialView:UIView.init(frame: self.mapVw.frame))
            self.segmentLines = proxy.sharedProxy().getSegmentsRotate(viewRotate, numberOfDivisions: Int32(self.sliderGridGap.value), angle: Double(self.sliderRotateGrid.value), initialView: UIView.init(frame: self.mapVw.frame))
            self.lblRotateGridAtAngle.text = "Rotate Grid Angle:  \(Int32(self.sliderRotateGrid.value))"
            if self.segmentLines.count > 1{
                
                let dict1 = self.segmentLines[0] as! NSMutableDictionary
                let point1 = dict1.object(forKey: "point_p1") as! CGPoint
                let locationCoordinate1 = self.mapVw.convert(point1,toCoordinateFrom: self.mapVw)
                let loc1: CLLocation = CLLocation(latitude: locationCoordinate1.latitude, longitude: locationCoordinate1.longitude)
                let dict2 = self.segmentLines[1] as! NSMutableDictionary
                let point2 = dict2.object(forKey: "point_p1") as! CGPoint
                let locationCoordinate2 = self.mapVw.convert(point2,toCoordinateFrom: self.mapVw)
                let loc2: CLLocation = CLLocation(latitude: locationCoordinate2.latitude, longitude: locationCoordinate2.longitude)
                let distance = String(format: "Grid Gap:  %0.1f m",loc1.distance(from: loc2))
                self.lblGridGapInMeter.text = distance
                
                //Remove start and stop annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                for someAnnotation in annotationsToRemove {
                    if someAnnotation.isKind(of: GridAnnotationStart.self) {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                    
                    if someAnnotation.isKind(of: GridAnnotationEnd.self) {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
                
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolyline.self) {
                        self.mapVw.removeOverlays([overlay])
                    }
                }
                self.arrLocations.removeAll()
                self.arrLocationsReal.removeAll()
                self.getGridWayPointMission(Int32(self.sliderGridGap.value),isDrawLines:false)
                self.lblWayPointQty.text = "\(self.arrLocationsReal.count) PTS"
            }
        }
    }
    
    
}
