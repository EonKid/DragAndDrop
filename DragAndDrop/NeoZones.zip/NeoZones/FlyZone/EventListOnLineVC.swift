//
//  EventListOnLineVC.swift
//  FlyZone
//
//  Created by Dhruv Singh on 02/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

class EventListOnLineVC: UIViewController ,UITableViewDataSource,UITableViewDelegate,createEventDelegate{
    
    
    //MARK:- VARIABLES
    var arrEventOfGroup = NSMutableArray()
    var groupModal = GroupList()
    
    @IBOutlet weak var btnAddEvent: UIButton!
    
    
    @IBOutlet weak var imgAddEvent: UIImageView!
    
    @IBOutlet weak var tableViewEventOnline: UITableView!
    
    //MARK:- IBOUTLET
    @IBOutlet weak var btnMainMenu: UIButton!
    
    @IBOutlet weak var lblGroupName: UILabel!
    @IBOutlet weak var btnJoinGroup: UIButton!
    
    //MARK:- API HIT
    func getEventList()  {
        self.arrEventOfGroup.removeAllObjects()
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kGetEventByGroup)" + "\(groupModal.id)"
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    let arrTemp = responseDict["list"] as! NSArray
                    for i in 0 ..< arrTemp.count{
                        var dict = NSDictionary()
                        dict = arrTemp[i] as! NSDictionary
                        let eventModal = EventListOnline()
                        eventModal.id = Int32(((dict["id"] as! NSNumber).intValue))
                        eventModal.group_id = Int32(((dict["group_id"] as! NSNumber).intValue))
                        eventModal.name = dict["name"] as! String
                        eventModal.group_name = dict["group_name"] as! String
                        eventModal.create_time = dict["create_time"] as! String
                        eventModal.from_date = dict["from_date"] as! String
                        eventModal.to_date = dict["to_date"] as! String
                        eventModal.create_user_id = Int32(((dict["create_user_id"] as! NSNumber).intValue))
                        eventModal.create_user_name = dict["create_user_name"] as! String
                        eventModal.zones = dict["zones"] as! NSArray
                        let strLocation =  dict["location"] as! String
                        if strLocation.characters.count > 0 {
                            eventModal.location = strLocation
                        }else{
                            eventModal.location = ""
                        }
                        self.arrEventOfGroup.add(eventModal)
                    }
                    if self.arrEventOfGroup.count > 0{
                            self.tableViewEventOnline.reloadSections([0], with: .fade)
                    }
                    
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
            }) { (error) in
                if error.localizedDescription.characters.count > 0{
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.getEventList()
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                       }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }
    
    //MARK:- DELEGATE CREATE EVENT
    func createEvent(){
        self.getEventList()
    }
    //MARK:- UITABLEVIEW DATA SOURCE AND DELEGATE
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return arrEventOfGroup.count
    }
    
    
    @IBAction func btnBack(_ sender: AnyObject) {
       _ = self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellEventListOnline", for: indexPath) as! EventListOnLineTVC
        let modalObject = arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
        cell.lblEventName.text = modalObject.name
        if modalObject.location == "" {
            cell.lblEventLocation.text = ""
        cell.imgTempLoc.isHidden = true
        }else{
        cell.lblEventLocation.text = modalObject.location
            cell.imgTempLoc.isHidden = false
        }
        
        if modalObject.from_date == "0000-00-00" || modalObject.to_date == "0000-00-00"{
            cell.lblEventBetweenDates.text = ""
        }else{
        
        cell.lblEventBetweenDates.text = "\(proxy.sharedProxy().getTimeString(modalObject.from_date))" + " - " + "\(proxy.sharedProxy().getTimeString(modalObject.to_date))"
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if arrEventOfGroup.count > 0 {
            let userId  = UserDefaults.standard.object(forKey: "id") as! Int
            if groupModal.is_followed == 1 || groupModal.create_user_id == Int32(userId){
                let createZoneVC = storyboard?.instantiateViewController(withIdentifier: "CreateZoneOnlineVC") as! CreateZoneOnlineVC
                let modalObject = arrEventOfGroup[(indexPath as NSIndexPath).row] as! EventListOnline
                createZoneVC.modalEventListOnline = modalObject
                createZoneVC.isFromOnlineGroup = true
                self.navigationController?.pushViewController(createZoneVC, animated: true)
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please join group")
            }
        }
    }
    
    
    //MARK:- VIEWCONTROLLER LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        btnMainMenu.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        btnMainMenu.layer.borderWidth = 1
        btnJoinGroup.layer.borderColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 1).cgColor
        btnJoinGroup.layer.borderWidth = 1
        if groupModal.is_followed == 1 {
            btnJoinGroup.setTitle("Joined", for: UIControlState())
            btnJoinGroup.isUserInteractionEnabled = false
        }else {
            btnJoinGroup.setTitle("Join Group", for: UIControlState())
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        lblGroupName.text = groupModal.name
        self.navigationController?.isNavigationBarHidden = true
        let userId  = UserDefaults.standard.object(forKey: "id") as! Int
        if groupModal.create_user_id == Int32(userId){
            btnJoinGroup.isHidden = true
            btnAddEvent.isHidden = false
            imgAddEvent.isHidden = false
            
        }else{
            if groupModal.is_followed == 1 {
                btnJoinGroup.setTitle("Joined", for: UIControlState())
                btnJoinGroup.isUserInteractionEnabled = false
                
            }else {
                btnJoinGroup.setTitle("Join Group", for: UIControlState())
                btnJoinGroup.isHidden = false
                btnAddEvent.isHidden = true
                imgAddEvent.isHidden = true
            }
        }
        self.getEventList()
    }
    
    func joinGroupApi(_ groupModal: GroupList,index: Int)  {
        let authCode: String = proxy.sharedProxy().authNil()
        if((authCode == "" ))
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please login.")
        }else{
            let apiURL = "\(KServerUrl)"+"\(kJoinGroup)" + "\(groupModal.id)"
            WebServiceRequest.getData(url: apiURL, success: { (responseDict) in
                if (responseDict["status"]! as AnyObject).isEqual("OK") {
                    proxy.sharedProxy().displayStatusCodeAlert("Group joined successfully")
                    groupModal.is_followed = 1
                    self.btnJoinGroup.setTitle("Joined", for: UIControlState())
                    self.btnJoinGroup.isUserInteractionEnabled = false
                    self.btnAddEvent.isHidden = false
                    self.imgAddEvent.isHidden = false
                    
                }else if (responseDict["status"]! as AnyObject).isEqual("NOK") {
                    proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
                }
                
            }) { (error) in
               
                if error.localizedDescription.characters.count > 0{
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.joinGroupApi(groupModal, index: index)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - ACTION
    
    @IBAction func btnPrssJoinGroup(_ sender: AnyObject) {
        
        if groupModal.is_followed == 0{
            joinGroupApi(groupModal, index: 0)
        }else{
            let userId  = UserDefaults.standard.object(forKey: "id") as! Int
            if groupModal.create_user_id == Int32(userId){
                btnJoinGroup.isHidden = true
            }else{
                btnJoinGroup.isHidden = false
            }
        }
    }
    
    @IBAction func btnPrssMainMenu(_ sender: AnyObject) {
        KAppDelegate.gotoMainMenu()
    }
    
    @IBAction func btnPrssAddEvent(_ sender: AnyObject) {
        let createGroupVC = storyboard?.instantiateViewController(withIdentifier: "CreateEventVC") as! CreateEventVC
        protocolCreateEvent = self
        createGroupVC.groupID = "\(groupModal.id)"
        createGroupVC.modalTransitionStyle = .crossDissolve
        createGroupVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createGroupVC, animated: true, completion: nil)
        
    }
    
    
    /*
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
