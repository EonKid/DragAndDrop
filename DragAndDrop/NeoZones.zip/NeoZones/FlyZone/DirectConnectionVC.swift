//
//  DirectConnectionVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 01/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit

protocol directConnectionDelegate {
    func directConnectionDone(_ dictEventInfo:NSDictionary)
}
var protocolDirectConnection: directConnectionDelegate?

class DirectConnectionVC: UIViewController {
    
    //MARK:- VARIABLE
    
    
    @IBOutlet weak var txtNameOfEvent: UITextField!
    //MARK:- IBOUTLET
    
    @IBOutlet weak var txtFieldPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnOK(_ sender: AnyObject) {
        
        self.view.endEditing(true)
        if txtNameOfEvent.text!.isEmpty
            
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Name of Event")
        }
            
        else if txtFieldPassword.text!.isEmpty
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
        }
        else
        {
            let url = "\(KServerUrl)"+"\(kDirectConnection)"
            let param = [
                " Event[name]" : "\(txtNameOfEvent.text!)",
                "Event[password]" : "\(txtFieldPassword.text!)"
            ]
            directEvent(url, parameters: param as Dictionary<String, AnyObject>)
            
        }
        
    }
    
    //MARK:- API REQUEST
    
    func directEvent(_ url: String,parameters: Dictionary<String, AnyObject>) {
        WebServiceRequest.postNormalData(parameters, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK"){
                 let dictEvent = responseDict["detail"] as! NSDictionary
               // proxy.sharedProxy().displayStatusCodeAlert("Event created successfully.")
                self.dismiss(animated: true, completion: {
                    protocolDirectConnection?.directConnectionDone(dictEvent)
                })

            }else{
                proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
            }
            
            }, failure: { (error) in
                let errorMessage = "\(error.localizedDescription)"
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                
                let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                    action in
                    self.directEvent(url, parameters: parameters)
                    }
                )
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                    }
                )
                alertController.addAction(retryAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
                
        })
        
    }

    
    //MARK:- ACTION
    @IBAction func btnCancel(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
