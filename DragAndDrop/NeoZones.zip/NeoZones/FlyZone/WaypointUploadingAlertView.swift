//
//  WaypointUploadingAlertView.swift
//  FlyZone
//
//  Created by Dhruv Singh on 28/02/17.
//  Copyright © 2017 toxsl. All rights reserved.
//

import UIKit

class WaypointUploadingAlertView: UIView {

    @IBOutlet weak var progressUpload: UIProgressView!
    @IBOutlet weak var lblProgressWaypoints: UILabel!

 
    
        /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
