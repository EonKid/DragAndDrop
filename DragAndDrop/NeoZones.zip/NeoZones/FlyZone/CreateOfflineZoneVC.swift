//
//  CreateZoneOnlineVC.swift
//  FlyZone
//
//  Created by Dhruv Narayan Singh on 04/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import MapKit
import Alamofire
import CoreLocation
import GLKit
import DJISDK

fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l > r
    default:
        return rhs < lhs
    }
}

fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l <= r
    default:
        return !(rhs < lhs)
    }
}

class CreateOfflineZoneVC: UIViewController,MKMapViewDelegate, UIGestureRecognizerDelegate,CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource,UISearchControllerDelegate,UISearchBarDelegate,setLocationDelegateOffline,DJISDKManagerDelegate,UINavigationControllerDelegate,DJIFlightControllerDelegate,DJISimulatorDelegate,DJIRemoteControllerDelegate,DJIMissionManagerDelegate{


    //MARK:- VARIABLE
    var zone_id  = Int32()
    var zone_name = String()
    var zone_array = NSArray()
    //Flight control
    var dictCenterCoordinatesPolygons = NSMutableDictionary()
    var product = DJIBaseProduct()
    var mXVelocity = Float()
    var mYVelocity = Float()
    var mYaw = Float()
    var mThrottle = Float()
    var droneLocationCoordinate = CLLocationCoordinate2D()
    var aircraftAnnotation:DroneAnnotation!
    var homeLocationOfUser = CLLocationCoordinate2D()
    var missionManager = DJIMissionManager()
    var waypointMission = DJIWaypointMission()
    var counter_max_radius = 0
    var takeOffCoordinates = CLLocationCoordinate2D()
    var isTypeOffLandingHomePoint  = Bool()
    var distanceXPos = Float()
    var heightOfDrone = Float()
    var arrMinMaxHeightDictionary = NSMutableArray()
    //Simulator control
    @IBOutlet weak var vwSimulatorControl: UIView!
    @IBOutlet weak var btnEnterVSMode: UIView!
    @IBOutlet weak var btnExitVSMode: UIButton!
    @IBOutlet weak var btnStartSimulator: UIButton!
    @IBOutlet weak var btnTakeOff: UIButton!
    
    @IBOutlet weak var btnLandDrone: UIButton!
    
    @IBOutlet weak var imgTagRight: UIImageView!
    @IBOutlet weak var lblTransmissionTime: UILabel!
    @IBOutlet weak var btnIsEnteredLandingRegion: UIButton!
    
    @IBOutlet weak var vwImageRight: UIView!
    @IBOutlet weak var vwImageLeft: UIView!
    @IBOutlet weak var imgTagLeft: UIImageView!
    var selectedAnnotationVw = MKAnnotationView()
    var strEventId = String()
    var isFromOnlineGroup = Bool()
    var modalEventListOnline = EventListOnline()
    var firstModal = EventOffline()
    var locationArray = NSMutableArray()
    var hitURL = String()
    var isUpdate = Bool()
    var isDragToPoint = Bool()
    var arrEventsList = NSMutableArray()
    var str_Min_Altitude = String()
    var str_Max_Altitude = String()
    var dictUpdateBools = NSMutableDictionary()
    var zoneCreateModal = EventOffline()
    let MERCATOR_OFFSET = 268435456.0
    let MERCATOR_RADIUS = 85445659.44705395
    let DEGREES = 180.0
    var isDragPin  = Bool()
    var isFromOfflineEventList = Bool()
   
    var isLandingPointsToBeMarked = Bool()
    var line = CAShapeLayer()
    var isLandingPointsOutside = Bool()
    var landingCircle = MKCircle()
    var isShowDistance = Bool()
    //Multiple zones creation
    var isPlacePolygon = Bool()
    var isAltitude = Bool()
    var isDrawPolygon  = Bool()
    var isDeletePolygon = Bool()
    var selectedIndexPath = IndexPath()
    var dictPolygon = NSMutableDictionary()
    var  vw = UIView()
    var linePath = UIBezierPath()
    var strZoneIdUpdate = String()
    var isOverLapped = Bool()
    //Main array
    var dictMainEventList = NSMutableDictionary()
    var strCurrentEventId = String()
    
    //Delete landing points
    var isLandingPointsToBeDeleted = Bool()
    var isPinPointsToBeDeleted = Bool()
    
    //MARK:- IBOUTLET
    //Delete points
    
    @IBOutlet weak var vwDeletePoints: UIView!
    
    @IBOutlet weak var cnstXDeleteView: NSLayoutConstraint!
    
    @IBOutlet weak var cnstYDeleteView: NSLayoutConstraint!
    
    
    //Flight control outlets
    //Constraints
    
    //helipad pops
    @IBOutlet weak var cnstHelipadPops: NSLayoutConstraint!
    
    
    
    
    //Stick left
    @IBOutlet weak var cnstYPositiveStickLeft: NSLayoutConstraint!
    
    @IBOutlet weak var cnstYNegativeStickLeft: NSLayoutConstraint!
    
    
    @IBOutlet weak var cnstXNegativeStickLeft: NSLayoutConstraint!
    
    @IBOutlet weak var cnstXPositiveStickLeft: NSLayoutConstraint!
    //Stick right
    
    @IBOutlet weak var cnstYPositiveStickRight: NSLayoutConstraint!
    
    @IBOutlet weak var cnstYNegativeStickRight: NSLayoutConstraint!
    
    @IBOutlet weak var cnstXNegativeStickRight: NSLayoutConstraint!
    
    
    @IBOutlet weak var cnstXPositiveStickRight: NSLayoutConstraint!
    //Aircraft velocity
    
    @IBOutlet weak var cnstYPositiveVelocity: NSLayoutConstraint!
    
    @IBOutlet weak var cnstYNegativeVelocity: NSLayoutConstraint!
    
    @IBOutlet weak var cnstXNegativeVelocity: NSLayoutConstraint!
    
    @IBOutlet weak var cnstXPositiveVelocity: NSLayoutConstraint!
    //aircraft distance from the ground
    @IBOutlet weak var cnstZPositive: NSLayoutConstraint!
    
    
    @IBOutlet weak var cnstZNegative: NSLayoutConstraint!
    
    
    //setup label
    @IBOutlet weak var lblYPositiveLeftStick: UILabel!
    
    
    @IBOutlet weak var lblXPosPositionLeftStick: UILabel!
    
    @IBOutlet weak var lblYPosRight: UILabel!
    
    @IBOutlet weak var lblXPosRight: UILabel!
    
    @IBOutlet weak var lblYAircraftVelocity: UILabel!
    
    @IBOutlet weak var lblZAboveGround: UILabel!
    @IBOutlet weak var lblXAircraftVelocity: UILabel!
    
    @IBOutlet weak var lblDistanceToNearestBoundary: UILabel!
    
    @IBOutlet weak var lblStatusDroneIsInZone: UILabel!
    
    
    @IBOutlet weak var lblGPSData: UILabel!
    
    @IBOutlet weak var lblDistanceAboveGround: UILabel!
    
    @IBOutlet weak var lblVelocityXStatus: UILabel!
    
    @IBOutlet weak var lblVelocityYStatus: UILabel!
    
    @IBOutlet weak var lblVelocityZStatus: UILabel!
    
    @IBOutlet weak var lblAltitudeX: UILabel!
    
    @IBOutlet weak var lblAltitudeY: UILabel!
    
    @IBOutlet weak var lblAltitudeZ: UILabel!
    
    
    //other
    @IBOutlet weak var vwChooseAltitude: UIView!
    @IBOutlet weak var vwCollectiveAltitudes: UIView!
    @IBOutlet weak var mapVw: MKMapView!
    @IBOutlet weak var txtFldCollectiveMin: UITextField!
    @IBOutlet weak var txtFldCollectiveMax: UITextField!
    @IBOutlet weak var txtFldSeperateMin: UITextField!
    @IBOutlet weak var txtFldSeperateMax: UITextField!
    @IBOutlet weak var vwSeparateAltitude: UIView!
    @IBOutlet weak var btnSettingsZone: UIButton!
    @IBOutlet weak var tableViewPlaces: UITableView!
    @IBOutlet weak var btnEditOutlet: UIButton!
    @IBOutlet weak var cnstVwSeparateOriginY: NSLayoutConstraint!
    @IBOutlet weak var vwAddEvent: UIView!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnDeleteZone: UIButton!
    @IBOutlet weak var cnstVwSeparateOriginX: NSLayoutConstraint!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblSeparateAltitudes: UILabel!
    @IBOutlet weak var btnPrssSetPinPositions: UIButton!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblOnlineGroupName: UILabel!
    @IBOutlet weak var tableViewEventList: UITableView!
    @IBOutlet weak var vwEventsLists: UIView!
    @IBOutlet weak var cnstVwSettingsBottom: NSLayoutConstraint!
    @IBOutlet weak var btnZonesList: UIButton!
    
    @IBOutlet weak var btnReadyToFly: UIButton!
    
    @IBOutlet weak var virtualStickRight: VirtualStickView!
    
    @IBOutlet weak var virtualStickLeft: VirtualStickView!
    
    @IBOutlet weak var vwDataFromDrone: UIView!
    
    
    @IBOutlet weak var btnHelipad: UIButton!
    
    @IBOutlet weak var btnDrawOnPop: UIButton!
    
    
    
    //MARK:- VARIABLE
    var latitudePick = Float64()
    var longitudePick = Float64()
    var setRegionBool = Bool()
    
    var annotationAry = [MKAnnotation]()
    var counter = Int32()
    var isCompleted = Bool()
    let locationManager = CLLocationManager()
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    var arrDrawArea = NSMutableArray()
    var mapPolyline = MKPolyline()
    var tapGesture =  UITapGestureRecognizer()
    var showPin = Bool()
    //MARK:- IBOUTLET
    @IBOutlet weak var btnDrawEdit: UIButton!
    @IBOutlet weak var vwSearchBar: UIView!
    
    @IBOutlet weak var cnstVwSettings: NSLayoutConstraint!
    //MARK:- Map Methd
    var userLoc = CLLocationCoordinate2D()

    @IBAction func btnPrssActionLandingPoints(_ sender: AnyObject) {
        isDragToPoint = true
        isCompleted = false
        vwChooseAltitude.isHidden = true
        showPin = true
        counter = 0
        isLandingPointsToBeMarked = false
        //Place polygon
      
            isDragToPoint = true
            if (self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray)?.count > 0 {
                showPin = false
                isLandingPointsToBeMarked = false
                isDragToPoint = true
                isCompleted = false
                
                //1.Setting the correct home point
                if let fc = DroneUtility.fetchFlightController(){
                    //1. Enter virtual stick mode
                    fc.yawControlMode = .angularVelocity
                    fc.rollPitchControlMode = .angle
                    fc.rollPitchCoordinateSystem = .ground
                    fc.enableVirtualStickControlMode(completion: { (error) in
                        if error?.localizedDescription.characters.count > 0
                        {
                            proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                        }else{
                            
                            //2.Start simulator
                            if CLLocationCoordinate2DIsValid(self.homeLocationOfUser){
                                fc.simulator?.start(withLocation: self.homeLocationOfUser, updateFrequency: 20, gpsSatellitesNumber: 10, withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0
                                    {
                                        proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                                    }else{
                                        self.btnStartSimulator.isSelected = true
                                        self.btnStartSimulator.setTitle("Stop", for: .normal)
                                        
                                        //3.Display home point
                                        let polygon = self.dictPolygon.object(forKey: "\(self.zoneCreateModal.id)") as! MKPolygon
                                        if self.isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)) == true{
                                            self.isDragPin = false
                                            let annotation = LandingPointAnnotationModal(title: self.zoneCreateModal.name, coordinate: CLLocationCoordinate2D(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude), info: "\(self.zoneCreateModal.id)",index: "\(self.counter)")
                                            self.mapVw.addAnnotation(annotation)
                                            let landing_circle = MKCircle.init(center: self.homeLocationOfUser, radius: 4)
                                            self.landingCircle = landing_circle
                                            self.mapVw.add(landing_circle)
                                            
                                            //2.Set flight failsafe operation
                                            let failsafeOperation = DJIFlightFailsafeOperation.goHome
                                            fc.setFlightFailsafeOperation(failsafeOperation, withCompletion: { (error) in
                                                if error?.localizedDescription.characters.count > 0{
                                                    //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                                }else{
                                                    
                                                    fc.setGoHomeBatteryThreshold(25, withCompletion: { (error) in
                                                        if error?.localizedDescription.characters.count > 0{
                                                            //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                                        }
                                                    })
                                                }
                                            })
                                            
                                        }else{
                                            proxy.sharedProxy().displayStatusCodeAlert("You cannot place landing point outside of polygon ")
                                        }
                                    }
                                })
                                
                            }else{
                                
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to fetch home location")
                            }
                        }
                    })
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }
        }
    
    func registerApp(isReigster:Bool) {
        if isReigster == true {
            let strId = NSString(format: "7e438c239538748342a26574")
            debugPrint("strid : ",strId)
            DJISDKManager.registerApp(strId as String, with: self)
            self.missionManager = DJIMissionManager.sharedInstance()!
        }
        
    }
    
    
    //MARK:- ACTION
    //Virtual stick mode
    @IBAction func btnActionEnterVirtualStick(_ sender: AnyObject) {
      
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.yawControlMode = .angularVelocity
            flightController.rollPitchControlMode = .angle
            flightController.rollPitchCoordinateSystem = .ground
            flightController.enableVirtualStickControlMode(completion: { (error) in
                if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Vitual stick mode enabled")
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    @IBAction func btnActionExitVSMode(_ sender: AnyObject) {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.disableVirtualStickControlMode(completion: { (error) in
                if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Exit Virtual Stick Mode: \(error!.localizedDescription)")
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Vitual stick mode disabled")
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    @IBAction func btnActionStartStopSimulator(_ sender: AnyObject) {
        var userLoc = CLLocationCoordinate2D()
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
        }
        
        let aircraft = DroneUtility.fetchAircraft()
        if aircraft != nil {
            aircraft?.remoteController?.delegate = self
        }
        
        if btnStartSimulator.isSelected == true {
            if let flightController = DroneUtility.fetchFlightController(){
                flightController.simulator?.stop(completion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator error: \(error!.localizedDescription)")
                    }else{
                        
                        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                      
                            for someAnnotation in annotationsToRemove {
                                let strId = "\(self.zoneCreateModal.id)"
                                if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                                    let annotaion = someAnnotation as! LandingPointAnnotationModal
                                    if annotaion.info == strId {
                                        self.mapVw.removeAnnotation(someAnnotation)
                                    }
                                }
                            }
                        
                        
                        self.btnStartSimulator.isSelected = false
                        self.btnStartSimulator.setTitle("Start", for: .normal)
                        proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator succeeded.")
                    }
                })
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            }
            
        }else{
            if let flightController = DroneUtility.fetchFlightController(){
                flightController.simulator?.start(withLocation: userLoc, updateFrequency: 20, gpsSatellitesNumber: 10, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0
                    {
                        proxy.sharedProxy().displayStatusCodeAlert("Start flight error: \(error!.localizedDescription)")
                    }else{
                        self.btnStartSimulator.isSelected = true
                        self.btnStartSimulator.setTitle("Stop", for: .normal)
                        proxy.sharedProxy().displayStatusCodeAlert("Start Simulator succeeded.")
                        self.setLandingPointHome()
                        //2.Set flight failsafe operation
                        let failsafeOperation = DJIFlightFailsafeOperation.goHome
                        flightController.setFlightFailsafeOperation(failsafeOperation, withCompletion: { (error) in
                            if error?.localizedDescription.characters.count > 0{
                                //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                
                            }else{
                                flightController.setGoHomeBatteryThreshold(25, withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0{
                                        //proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                    }else{
                                        
                                        let delay = 0.1 * Double(NSEC_PER_SEC)
                                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                                            
                                            if CLLocationCoordinate2DIsValid(self.droneLocationCoordinate){
                                                let location_coordinate = self.droneLocationCoordinate
                                              
                                                //3.Display home point
                                                let polygon = self.dictPolygon.object(forKey: "\(self.zoneCreateModal.id)") as! MKPolygon
                                                if self.isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: location_coordinate.latitude, longitude: location_coordinate.longitude)) == true{
                                                    self.isDragPin = false
                                                    let annotation = LandingPointAnnotationModal(title: self.zoneCreateModal.name, coordinate: CLLocationCoordinate2D(latitude: location_coordinate.latitude, longitude: location_coordinate.longitude), info: "\(self.zoneCreateModal.id)",index: "0")
                                                    self.mapVw.addAnnotation(annotation)
       
                                                    let landing_circle = MKCircle.init(center: location_coordinate, radius: 4)
                                                    self.landingCircle = landing_circle
                                                    self.mapVw.add(landing_circle)
                                                    
                                                }else{
                                                    proxy.sharedProxy().displayStatusCodeAlert("You cannot place landing point outside of polygon ")
                                                }
                                            }
                                        }
                                    }
                                })
                            }
                        })
                    }
                })
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            }
        }
    }
    @IBAction func btnActionTakeOff(_ sender: AnyObject) {
        self.btnIsEnteredLandingRegion.isHidden = false
        self.initialFlightSetup()
    }

    func initialFlightSetup()  {
        if let flightController = DroneUtility.fetchFlightController(){
            if CLLocationCoordinate2DIsValid(self.droneLocationCoordinate) {
                let min_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: zoneCreateModal.zones).object(forKey: "minimum_height") as! Float
                self.takeOffCoordinates = self.droneLocationCoordinate
                proxy.sharedProxy().displayStatusCodeAlert("Take off succeeded...")
                let max_height = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                
                let stepsToGo = DJIGoToStep.init(coordinate: self.droneLocationCoordinate, altitude: min_height)
                let customMission = DJICustomMission.init(steps: [stepsToGo!])
                DJIMissionManager.sharedInstance()!.prepare(customMission!, withProgress: { (value) in
                }, withCompletion: { (error) in
                    if error?.localizedDescription.characters.count > 0{
                        proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                    }else{
                        DJIMissionManager.sharedInstance()!.startMissionExecution(completion: { (error) in
                            if error?.localizedDescription.characters.count > 0{
                                //  proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                            }else{
                                
                                flightController.flightLimitation?.setMaxFlightHeight(max_height, withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0{
                                        //  proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                    }else{
                                        flightController.setFlightOrientationMode(.courseLock, withCompletion: { (error) in
                                            if error?.localizedDescription.characters.count > 0{
                                                // proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }
                })
                
                
                
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to fetch current location")
            }
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    func setLandingPointHome() {
        if   let fc = DroneUtility.fetchFlightController()
        {
            var userLoc = CLLocationCoordinate2D()
            
            if UserDefaults.standard.object(forKey: "lat") != nil && UserDefaults.standard.object(forKey: "long") != nil{
                let lat =  UserDefaults.standard.object(forKey: "lat") as! String
                let long = UserDefaults.standard.object(forKey: "long") as! String
                userLoc.latitude = CDouble(lat)!
                userLoc.longitude = CDouble(long)!
                fc.setHomeLocation(userLoc, withCompletion: { (error) in
                    // proxy.sharedProxy().displayStatusCodeAlert("Unable to set home location: \(error?.localizedDescription)")
                })
            }
        }
    }
    
    
    //MARK: - LAND TO PARTICULAR POSITION
    
    func landToParticularPosition(_ landingPoints: CLLocationCoordinate2D,dronelocation_coord:CLLocationCoordinate2D)  {
        //Disable maximum flight distance
        if let fc = DroneUtility.fetchFlightController(){
            //1.Set home location with aircraft current location
            fc.getHomeLocation(completion: { (aircraftHomeLocation, error) in
                if error?.localizedDescription.characters.count > 0{
                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                }else{
                    //2.Set maximum altitude for the zone
                    let converted_max_ht = proxy.sharedProxy().getAltitudeDictionary(arrTemp: self.zoneCreateModal.zones).object(forKey: "maximum_height") as! Float
                    fc.setGoHomeAltitude(converted_max_ht, withCompletion: { (error) in
                        if error?.localizedDescription.characters.count > 0 {
                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                        }else{
                            //3.Varify go home set or not
                            fc.getGoHomeAltitude(completion: { (minimum_altitude, error) in
                                if error?.localizedDescription.characters.count > 0{
                                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                }else{
                                    fc.goHome(completion: { (error) in
                                        if error?.localizedDescription.characters.count > 0{
                                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                        }else{
                                            proxy.sharedProxy().displayStatusCodeAlert("Landing started...")
                                        }
                                    })
                                }
                            })
                        }
                    })
                }
            })
    
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
        
    }
    
    
    @IBAction func btnActionLandDrone(_ sender: AnyObject) {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            if Int(self.heightOfDrone) != 0{
                if CLLocationCoordinate2DIsValid(self.takeOffCoordinates){
                    self.landToParticularPosition(self.takeOffCoordinates,dronelocation_coord: self.droneLocationCoordinate)
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("You cannnot land drone without takeoff")
            }
        }
        
    }
    
    
    @IBAction func btnActionPopDrawAndHelipad(_ sender: AnyObject) {
        
        isLandingPointsToBeDeleted = false
        
        if self.btnDrawEdit.isSelected == true {
            self.btnDrawEdit.isSelected = false
            self.cnstHelipadPops.constant = 156.0
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstHelipadPops.constant = 0.0
                self.view.layoutIfNeeded()
            })
            
        }else{
            self.btnDrawEdit.isSelected = true
            self.cnstHelipadPops.constant = 0.0
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstHelipadPops.constant = 156.0
                self.view.layoutIfNeeded()
            })
        }
        
        
    }
    
    
    func StopSimulatorDrone() {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.simulator?.stop(completion: { (error) in
                if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator error: \(error!.localizedDescription)")
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Stop Simulator succeeded.")
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    
    func autolandStarted()  {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.goHome(completion: { (error) in
                if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("error: \(error!.localizedDescription)")
                    self.StopSimulatorDrone()
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Landing Started..")
                    self.StopSimulatorDrone()
                    
                }
            })
            
            
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
        
    }
    
    @IBAction func btnPrssActionReadyToFly(_ sender: AnyObject) {
        
    
            
            if btnReadyToFly.isSelected == true {
                btnReadyToFly.isSelected = false
                btnReadyToFly.setTitle("Ready to Fly", for: .normal)
                self.autolandStarted()
                virtualStickLeft.isHidden = true
                virtualStickRight.isHidden = true
                vwDataFromDrone.isHidden = true
                btnZonesList.isHidden = false
                vwEventsLists.isHidden = false
                btnSettingsZone.isHidden = false
                cnstVwSettings.constant = 0
                vwChooseAltitude.isHidden = true
                vwCollectiveAltitudes.isHidden = true
                vwSeparateAltitude.isHidden = true
                vwSimulatorControl.isHidden = true
                vwSearchBar.isHidden = false
            }else{
                
                let arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray
                if arrTemp?.count > 0 {
                    
                    //1.Draw lines and convert location to x-y coordinates
                    let  arrEdges  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
                    var checkIfDistanceIsGreater = false
                    if arrEdges.count > 0{
                        
                        for i in 0..<arrEdges.count {
                            //GET LOCATION COORDINATES
                            let edgeLocation = proxy.sharedProxy().getLocationFromDictionary(arrEdges[i] as! NSMutableDictionary)
                            if CLLocationCoordinate2DIsValid(self.homeLocationOfUser) {
                                let coordinate₀ = CLLocation(latitude: edgeLocation.latitude, longitude: edgeLocation.longitude)
                                let coordinate₁ = CLLocation(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)
                                let distanceInMeters = Float(proxy.sharedProxy().getDistanceInm(coordinate₀, from: coordinate₁))
                                if distanceInMeters >= 500.0 {
                                    checkIfDistanceIsGreater = true
                                    break
                                }
                            }
                        }
                    }
                    if checkIfDistanceIsGreater == false {
                        
                        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                        for someAnnotation in annotationsToRemove {
                            let strId = "\(zoneCreateModal.id)"
                            if someAnnotation.isKind(of: AnnotationModal.self) {
                                let annotaion = someAnnotation as! AnnotationModal
                                if annotaion.info == strId {
                                    self.mapVw.removeAnnotation(someAnnotation)
                                }
                            }
                        }
                        
                        for someAnnotation in annotationsToRemove {
                            let strId = "\(zoneCreateModal.id)"
                            if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                                let annotaion = someAnnotation as! LandingPointAnnotationModal
                                if annotaion.info == strId {
                                    //  self.mapVw.removeAnnotation(someAnnotation)
                                }
                            }
                        }
                        
                        
                        
                        //Set max flight radius
                        if let flightController = DroneUtility.fetchFlightController(){
                            
                            //Set settings
                            self.btnSettingsZone.isSelected = false
                            self.cnstVwSettingsBottom.constant = 118
                            self.cnstVwSettings.constant = 500.0
                            self.view.layoutIfNeeded()
                            
                            UIView.animate(withDuration: Double(0.50), animations: {
                                self.cnstVwSettings.constant = 0
                                self.cnstVwSettingsBottom.constant = 60
                                self.view.layoutIfNeeded()
                            })
                            
                            self.btnReadyToFly.isSelected = true
                            self.btnReadyToFly.setTitle("Exit", for: .normal)
                            self.vwSearchBar.isHidden = true
                            self.vwSimulatorControl.isHidden = false
                            self.cnstHelipadPops.constant = 0
                            self.setUpManager()
                            flightController.flightLimitation?.setMaxFlightRadiusLimitationEnabled(true, withCompletion: { (error) in
                                if error?.localizedDescription.characters.count > 0
                                {
                                    // proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                }else{
                                    flightController.yawControlMode = .angularVelocity
                                    flightController.rollPitchControlMode = .angle
                                    flightController.rollPitchCoordinateSystem = .ground
                                    flightController.enableVirtualStickControlMode(completion: { (error) in
                                        if error?.localizedDescription.characters.count > 0
                                        {
                                            proxy.sharedProxy().displayStatusCodeAlert("Virtual Stick Mode: \(error!.localizedDescription)")
                                        }else{
                                            // proxy.sharedProxy().displayStatusCodeAlert("Vitual stick mode enabled")
                                        }
                                    })
                                }
                            })
                        }else{
                            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                        }
                    }else{
                        
                        proxy.sharedProxy().displayStatusCodeAlert("Please make sure that location of each edge point of polygon should be less than 500.0 m distance from drone location")
                    }
                    
                    
                    
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Please create zone before connecting to drone")
                }
            }
            
        
    }
    
    
    @IBAction func btnAction3DView(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        let vc  = storyboard?.instantiateViewController(withIdentifier: "ThreeDViewController") as! ThreeDViewController
        vc.strTitle = self.modalEventListOnline.name
        let arrTempAllZones = NSMutableArray()
        if arrEventsList.count > 0 {
            for eventObject  in arrEventsList {
                let event = eventObject as! EventOffline
                let dictEvent = NSMutableDictionary()
                dictEvent.setObject(event.name, forKey: "name" as NSCopying)
                dictEvent.setObject(event.zones, forKey: "zones" as NSCopying)
                dictEvent.setObject(event.id.hashValue, forKey: "id" as NSCopying)
                arrTempAllZones.add(dictEvent)
            }
            print("Array passed : ",arrTempAllZones)
            vc.arrAllZones = arrTempAllZones as [AnyObject]
            self.navigationController?.pushViewController(vc, animated: false)
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone to view 3D zone")
        }
    }
    
    @IBAction func btnPrssAddEvents(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        //Delete annotation
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            let strId = "\(zoneCreateModal.id)"
            if someAnnotation.isKind(of: AnnotationModal.self) {
                let annotaion = someAnnotation as! AnnotationModal
                if annotaion.info == strId {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
        let createZoneVC = storyboard?.instantiateViewController(withIdentifier: "CreateZonePopupVC") as! CreateZonePopupVC
        protocolObjectOfflineZone = self
        createZoneVC.modalTransitionStyle = .crossDissolve
        createZoneVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(createZoneVC, animated: true, completion: nil)
    }
    @IBAction func btnPrssCloseEvents(_ sender: AnyObject) {
        if self.btnZonesList.isSelected == true {
            self.btnZonesList.isSelected = false
            vwEventsLists.isHidden = true
        }else{
            self.btnZonesList.isSelected = true
            vwEventsLists.isHidden = false
        }
    }
    
    @IBAction func btnEditClose(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        vwChooseAltitude.isHidden = true
        isDragToPoint = true
    }
    @IBAction func btnPrssSetPinPosition(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        showPin = false
        vwChooseAltitude.isHidden = true
        isDragToPoint = true
        isCompleted = false
        if zoneCreateModal.zones.count == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
        }
    }
    
    
    @IBAction func btnPrssSeparateDone(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        if txtFldSeperateMin.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Minimum Altitude")
        }else if txtFldSeperateMax.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Maximum Altitude")
        }else {
            let min_height = Int32(txtFldSeperateMin.text!)
            let max_height = Int32(txtFldSeperateMax.text!)
            
            if Float(max_height!)/3.2808 <= 500.00{
                if min_height <= max_height {
                    let annotation = selectedAnnotationVw.annotation as? AnnotationModal
                    let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation!.info)) as! NSMutableArray
                    let dict = arrTempDrawPolygon[selectedAnnotationVw.tag-1] as! NSMutableDictionary
                    dict["max_alt"] = txtFldSeperateMax.text!
                    dict["min_alt"] = txtFldSeperateMin.text!
                    arrTempDrawPolygon.replaceObject(at: selectedAnnotationVw.tag-1, with: dict)
                    self.dictMainEventList.setObject(arrTempDrawPolygon, forKey: "\(annotation!.info)" as NSCopying)
                    let str_id = annotation!.info
                    for i in 0 ..< arrEventsList.count{
                        let modalObject = arrEventsList[i] as! EventOffline
                        if modalObject.id == Int32(str_id) {
                            modalObject.zones = arrTempDrawPolygon
                            arrEventsList.replaceObject(at: i, with: modalObject)
                            tableViewEventList.reloadData()
                        }
                    }
                    vwSeparateAltitude.isHidden = true
                    mapVw.deselectAnnotation(selectedAnnotationVw.annotation, animated: true)
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Minimum Height should be less than Maximum Height")
                }
            }else{
                
                proxy.sharedProxy().displayStatusCodeAlert("Maximum height should be less than or equals to 500")
            }
            vwSeparateAltitude.isHidden = true
        }
    }
    

    @IBAction func btnPrssSettings(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0
        btnDrawEdit.isSelected = false
        
        isLandingPointsToBeMarked = false
        if self.btnSettingsZone.isSelected == true {
            self.btnSettingsZone.isSelected = false
            self.cnstVwSettingsBottom.constant = 118
            self.cnstVwSettings.constant = 500.0
            self.view.layoutIfNeeded()
            
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstVwSettings.constant = 0
                self.cnstVwSettingsBottom.constant = 60
                self.view.layoutIfNeeded()
            })
            
        }else{
            self.btnSettingsZone.isSelected = true
            self.cnstVwSettings.constant = 0.0
            self.cnstVwSettingsBottom.constant = 60
            self.view.layoutIfNeeded()
            UIView.animate(withDuration: Double(0.50), animations: {
                self.cnstVwSettings.constant = 500
                self.cnstVwSettingsBottom.constant = 118
                self.view.layoutIfNeeded()
            })
        }
    }
    
    @IBAction func btnPrssSeparateClose(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        mapVw.deselectAnnotation(selectedAnnotationVw.annotation, animated: true)
        vwSeparateAltitude.isHidden = true
    }
    
    @IBAction func btnBack(_ sender: AnyObject) {
        _ =  self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCollectiveAction(_ sender: AnyObject) {
        isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        vwChooseAltitude.isHidden = true
        
        if  zoneCreateModal.id == 0{
            if zoneCreateModal.zones.count == 0 {
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }else{
                vwCollectiveAltitudes.isHidden = false
            }
        }else{
            vwCollectiveAltitudes.isHidden = false
            
        }
    }
    
    @IBAction func btnSeperateAction(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        let annotation = selectedAnnotationVw.annotation as? AnnotationModal
        if annotation != nil {
            vwChooseAltitude.isHidden = true
            vwSeparateAltitude.isHidden = false
            let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation?.info)!) as! NSArray
            if arrTempDrawPolygon.count > 0 {
                isCompleted = true
                showPin = false;
            }
            vwChooseAltitude.isHidden = true
            let dictShowAltitude = arrTempDrawPolygon[selectedAnnotationVw.tag-1] as! NSMutableDictionary
            txtFldSeperateMin.text = dictShowAltitude.value(forKey: "min_alt") as? String
            txtFldSeperateMax.text = dictShowAltitude.value(forKey: "max_alt") as? String
            vwSeparateAltitude.isHidden = false
            let mainScreenWidth = UIScreen.main.bounds.size.width
            let mainScreenHeight = UIScreen.main.bounds.size.height
            UIDevice.current.beginGeneratingDeviceOrientationNotifications()
            if UIDevice.current.orientation.isLandscape {
                //  Landscape
                if selectedAnnotationVw.frame.origin.x >= mainScreenWidth-250 {
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x - 600
                    
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }else{
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x-350
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }
                //isPortrait
                
            } else  if UIDevice.current.orientation.isPortrait {
                
                //Portrait
                if view.frame.origin.x >= mainScreenWidth-250 {
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x-500
                    if view.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-520
                    }
                }else{
                    cnstVwSeparateOriginX.constant = abs(selectedAnnotationVw.frame.origin.x)-250
                    
                    if view.frame.origin.y >= mainScreenHeight-100 {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-520
                    }
                    
                }
            }else{
                if selectedAnnotationVw.frame.origin.x >= mainScreenWidth-250 {
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x - 600
                    
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }else{
                    cnstVwSeparateOriginX.constant = selectedAnnotationVw.frame.origin.x-350
                    if selectedAnnotationVw.frame.origin.y >= mainScreenHeight {
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-420
                    }else{
                        cnstVwSeparateOriginY.constant = selectedAnnotationVw.frame.origin.y-320
                    }
                }
            }
            lblSeparateAltitudes.text = " Separate Altitudes(\(selectedAnnotationVw.tag))"
        }else{
            if zoneCreateModal.zones.count == 0 {
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone pins")
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please select zone from Zones list")
            }
        }
        vwChooseAltitude.isHidden = true
    }
    @IBAction func btnCollectiveCross(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        vwCollectiveAltitudes.isHidden = true
    }
    @IBAction func btnCollectiveDone(_ sender: AnyObject) {
        isLandingPointsToBeMarked = false
        isDragToPoint = false
        if txtFldCollectiveMin.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0 {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Minimum Altitude")
        }else if txtFldCollectiveMax.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Maximum Altitude")
        }else {
            let min_height = Int32(txtFldCollectiveMin.text!)
            let max_height = Int32(txtFldCollectiveMax.text!)
            if zoneCreateModal.id != 0 {
                
            let arrTempDrawPolygon = (self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray) .mutableCopy() as! NSMutableArray
                if Float(max_height!)/3.2808 <= 500.00 {
                    if min_height < max_height {
                        if arrTempDrawPolygon.count == 0 {
                            vwCollectiveAltitudes.isHidden = true
                            proxy.sharedProxy().displayStatusCodeAlert("Please select points on Map to create zones")
                        }else{
                            for i in 0 ..< arrTempDrawPolygon.count {
                                let dictUpdateAltitude = arrTempDrawPolygon[i] as! NSMutableDictionary
                                dictUpdateAltitude.setObject(txtFldCollectiveMin.text!, forKey: "min_alt" as NSCopying)
                                dictUpdateAltitude.setObject(txtFldCollectiveMax.text!, forKey: "max_alt" as NSCopying)
                                arrTempDrawPolygon.replaceObject(at: i, with: dictUpdateAltitude)
                            }
                            self.dictMainEventList.setObject(arrTempDrawPolygon, forKey: "\(zoneCreateModal.id)" as NSCopying)
                            
                            let str_id = zoneCreateModal.id
                            for i in 0 ..< arrEventsList.count{
                                let modalObject = arrEventsList[i] as! EventOffline
                                if modalObject.id == str_id {
                                    modalObject.zones = arrTempDrawPolygon
                                    arrEventsList.replaceObject(at: i, with: modalObject)
                                    tableViewEventList.reloadData()
                                }
                            }
                            
                            vwCollectiveAltitudes.isHidden = true
                        }
                    }else{
                        proxy.sharedProxy().displayStatusCodeAlert("Minimum Height should be less than Maximum Height")
                    }
                }else{
                    proxy.sharedProxy().displayStatusCodeAlert("Maximum height must be less than or equal to 500")
                }
            }
        }
    }
    
    @IBAction func btnEditAction(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0.0
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isAltitude = true
        isPlacePolygon = false
        isDrawPolygon = false
        isDeletePolygon = false
        vwChooseAltitude.isHidden = false
       
            vwCollectiveAltitudes.isHidden = true
            vwSeparateAltitude.isHidden = true
        
        
    }
    
    @IBAction func btnPrssDragPolygon(_ sender: AnyObject) {
        
      
            let arrZones = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
            if arrZones.count > 0 {
                vw.frame = CGRect(x: 0, y: 0, width: self.mapVw.frame.size.width, height: self.mapVw.frame.size.height)
                //Delete annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                for someAnnotation in annotationsToRemove {
                    let strId = "\(self.zoneCreateModal.id)"
                    if someAnnotation.isKind(of: AnnotationModal.self) {
                        let annotaion = someAnnotation as! AnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            // self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                    
                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        print("Zone Name : \(strTitle)")
                        if strTitle == self.zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                        
                    }
                }
                
                let arrPoints = NSMutableArray()
                
                //Convert lat and longitude to x and y pos of zone
                for i in 0 ..< arrZones.count {
                    var zoneLoc = CLLocationCoordinate2D()
                    let dict = (arrZones[i] as! NSDictionary) .mutableCopy() as! NSMutableDictionary
                    let lat = dict["lat"] as! String
                    let long = dict["longt"] as! String
                    let min_height = Int32((dict["min_alt"] as! NSString) as String)
                    let max_height = Int32((dict["max_alt"] as! NSString) as String)
                    let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                    let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                    zoneLoc.latitude = Double(newLat)!
                    zoneLoc.longitude = Double(newLong)!
                    let point = self.mapVw.convert(zoneLoc, toPointTo: self.mapVw)
                    let dictPoints = NSMutableDictionary()
                    dictPoints.setObject(vw.frame.origin.x+point.x, forKey: "xPos" as NSCopying)
                    dictPoints.setObject(vw.frame.origin.y+point.y, forKey: "yPos" as NSCopying)
                    dictPoints.setObject("\(min_height)", forKey: "min_alt" as NSCopying)
                    dictPoints.setObject("\(max_height)", forKey: "max_alt" as NSCopying)
                    arrPoints.add(dictPoints)
                }
                
                var firstPos = CGPoint()
                let dictPos = arrPoints.object(at: 0) as! NSMutableDictionary
                firstPos.x = CGFloat(Float(dictPos["xPos"] as! NSNumber))
                firstPos.y = CGFloat(Float(dictPos["yPos"] as! NSNumber))
                linePath.move(to: firstPos)
                
                //Shape Layer
                line.frame = vw.frame
                
                for i in 1 ..< arrPoints.count {
                    var posTemp = CGPoint()
                    let dictPos = arrPoints.object(at: i) as! NSMutableDictionary
                    posTemp.x = CGFloat(Float(dictPos["xPos"] as! NSNumber))
                    posTemp.y = CGFloat(Float(dictPos["yPos"] as! NSNumber))
                    linePath.addLine(to: posTemp)
                    
                }
                
                linePath.close()
                line.lineWidth = 5.0
                line.path = linePath.cgPath
                line.fillColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 0.50).cgColor
                line.strokeColor = UIColor(red: 71.0/255, green: 194.0/255, blue: 19.0/255, alpha: 1).cgColor
                vw.layer.addSublayer(line)
                vw.backgroundColor = UIColor.clear
                self.mapVw.addSubview(vw)
                self.mapVw.bringSubview(toFront: vw)
                let panGR = UIPanGestureRecognizer(target: self, action: #selector(CreateZoneOnlineVC.didPan(_:)))
                vw.addGestureRecognizer(panGR)
                print("coordinates x: \(vw.frame.origin.x) y: \(vw.frame.origin.y)")
                vwChooseAltitude.isHidden = true
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please create polygon first")
            }
        }

    
    
    @IBAction func btnPrssClear(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0.0
        isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isDeletePolygon = true
        isPlacePolygon = false
        isAltitude = false
        isDrawPolygon = false
        
     
            if zoneCreateModal.id != 0 {
                let alertController = UIAlertController(title: "", message: "Are you sure to delete \"\(zoneCreateModal.name)\" zone?", preferredStyle: .alert)
                let deleteAction = UIAlertAction(title: "Delete", style: .default, handler: {
                    action in
                    
                    self.showPin = false
                    self.counter = 0
                    self.isCompleted = false
                    self.isDragToPoint = true
                    
                    //Delete annotation
                    let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                    for someAnnotation in annotationsToRemove {
                        let strId = "\(self.zoneCreateModal.id)"
                        if someAnnotation.isKind(of: AnnotationModal.self) {
                            let annotaion = someAnnotation as! AnnotationModal
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                        if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                            let annotaion = someAnnotation as! LandingPointAnnotationModal
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                        
                        if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                            let annotaion = someAnnotation as! ZoneNameAnnotationModal
                            if annotaion.info == strId {
                                self.mapVw.removeAnnotation(someAnnotation)
                            }
                        }
                    }
                    
                    //Remove overlay
                    for overlay in self.mapVw.overlays {
                        if overlay.isKind(of: MKPolygon.self){
                            let strTitle = String(validatingUTF8: overlay.title!!)!
                            print("Zone Name : \(strTitle)")
                            if strTitle == self.zoneCreateModal.name {
                                self.mapVw.remove(overlay)
                            }
                        }
                    }
                    
                    let  arrTemp  = NSMutableArray()
                    self.dictMainEventList.setObject(arrTemp, forKey: "\(self.zoneCreateModal.id)" as NSCopying)
                    self.vwChooseAltitude.isHidden = true
                    self.vwCollectiveAltitudes.isHidden = true
                    self.annotationAry.removeAll()
                    self.vwSeparateAltitude.isHidden = true
                    self.vwChooseAltitude.isHidden = true
                    if self.arrEventsList.count > 0 {
                        self.arrEventsList.removeObject(at: self.selectedIndexPath.row)
                        self.tableViewEventList.reloadData()
                        
                    }
                    self.dictMainEventList.removeObject(forKey: "\(self.zoneCreateModal.id)")
                    self.zoneCreateModal = EventOffline()
                    let enteriesQuery = NSString(format: "DELETE FROM 'OfflineTBL' WHERE id=\(self.zoneCreateModal.id) " as NSString )
                    DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
                    proxy.sharedProxy().displayStatusCodeAlert("Zone Deleted successfully")

                  
                   
                                        
                })
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                    action in
                }
                )
                alertController.addAction(deleteAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
            
        }
        


    @IBAction func btnPrssDraw(_ sender: AnyObject) {
        cnstHelipadPops.constant = 0
        isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isDrawPolygon = true
        isPlacePolygon = false
        isAltitude = false
        isDeletePolygon = false
        self.showPin = false
      
            //Draw Polygon
            isDragToPoint = true
            counter = 0
            isCompleted = false
            if let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray{
                if arrTemp.count  < 3 {
                    proxy.sharedProxy().displayStatusCodeAlert("Please select atleast 3 points to draw a region")
                }else{
//                     let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
//                    if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)) == true || isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)) == true{
//                             isLandingPointsOutside = false
//                    }else{
//                    
//                        isLandingPointsOutside = true
//                    }
//                    
//                    if isLandingPointsOutside == true {
//                        proxy.sharedProxy().displayStatusCodeAlert("Please place landing points inside the polygon")
//                    }else{
                        if isCompleted == false {
                            // vwChooseAltitude.isHidden = false
                            self.zoneCreateModal.zones = arrTemp
                            self.arrEventsList.replaceObject(at: (selectedIndexPath as NSIndexPath).row, with: self.zoneCreateModal)
                            if self.arrEventsList.count > 0 {
                                self.tableViewEventList.reloadData()
                            }
                            
                            
                            //check current polygon with other polygons
                            
                            var isIntersectionFound = false
                            
                            if  self.dictPolygon.object(forKey: "\(zoneCreateModal.id)")  != nil{
                                let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                                for i in 0..<self.arrEventsList.count{
                                    let modalEvent  = self.arrEventsList[i] as! EventOffline
                                    if zoneCreateModal.id != modalEvent.id {
                                        let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                                        let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                                        if somePolygon!.pointCount > 0 {
                                            isIntersectionFound = true
                                            break
                                        }
                                    }
                                }
                            }
                            
                            var strIsUpdate = String()
                            strIsUpdate = self.dictUpdateBools.object(forKey: "\(zoneCreateModal.id)") as! String
                            if  strIsUpdate == "1"{
                                //check overlay
                                var isOverlayDraw = false
                                for overlay in self.mapVw.overlays {
                                    if overlay.isKind(of: MKPolygon.self) {
                                        let strTitle = String(validatingUTF8: overlay.title!!)!
                                        if strTitle == zoneCreateModal.name {
                                            isOverlayDraw = true
                                        }
                                    }
                                    
                                }
                                
                                if isOverlayDraw == false {
                                    self.isDragPin = true
                                    if isIntersectionFound == true{
                                        isOverLapped = true
                                    }else{
                                        isOverLapped = false
                                        
                                    }
                                    
                                    let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                                    //Polygon pin points
                                    for someAnnotation in annotationsToRemove {
                                        let strId = "\(zoneCreateModal.id)"
                                        if someAnnotation.isKind(of: AnnotationModal.self) {
                                            let annotaion = someAnnotation as! AnnotationModal
                                            if annotaion.info == strId {
                                                self.mapVw.removeAnnotation(someAnnotation)
                                            }
                                        }
                                    }
                                    
                                    
                                    self.drawPloygon(arrTemp, strTitle: "\(zoneCreateModal.name)", strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true,strCreatedUserId: "",willShowDistance:true)
                                }
                                
                                if isIntersectionFound == false{
                                    self.updateEvent("\(zoneCreateModal.id)")
                                }else{
                                    proxy.sharedProxy().displayStatusCodeAlert("Please place zone outside of other zone")
                                }
                                
                            }else{
                                self.isDragPin = true
                                if isIntersectionFound == true{
                                    isOverLapped = true
                                }else{
                                    isOverLapped = false
                                }
                                
                                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                                //Polygon pin points
                                for someAnnotation in annotationsToRemove {
                                    let strId = "\(zoneCreateModal.id)"
                                    if someAnnotation.isKind(of: AnnotationModal.self) {
                                        let annotaion = someAnnotation as! AnnotationModal
                                        if annotaion.info == strId {
                                            self.mapVw.removeAnnotation(someAnnotation)
                                        }
                                    }
                                }
                                
                                
                                self.drawPloygon(arrTemp, strTitle: "\(zoneCreateModal.name)", strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true,strCreatedUserId: "",willShowDistance:true)
                                
                                if isIntersectionFound == false {
                                    var jsonString : NSString = ""
                                    do
                                    {
                                        let arrJson = try JSONSerialization.data(withJSONObject: arrTemp, options: JSONSerialization.WritingOptions.prettyPrinted)
                                        let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
                                        jsonString = string! as NSString
                                        
                                    }
                                    catch let error as NSError
                                    {
                                        print(error.description)
                                    }
                                    let arrLandingPoints = self.dictMainEventList["\(zoneCreateModal.id)"] as! NSArray
                                    let jsonStringLandingPoints = getJSONString(arrLandingPoints)
                                    
                                      //set bool variables
                                     self.dictUpdateBools.setObject("1", forKey: "\(self.zoneCreateModal.id)" as NSCopying)
                                       self.isDragPin = true
                                        self.isUpdate = true
                                    let enteriesQuery = NSString(format: "INSERT OR REPLACE INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",zoneCreateModal.id, zoneCreateModal.name,jsonStringLandingPoints)
                                    DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
                                    proxy.sharedProxy().displayStatusCodeAlert("Zone Updated successfully")
                                    
                                }else{
                                    
                                    proxy.sharedProxy().displayStatusCodeAlert("Please place zone outside the other zone")
                                }
                                
                            }
                        }
                        
                    
                    
                    
                    //this is end
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone ")
            }
            
        }

    
    //MARK:- API HIT
    func updateEvent(_ strId:String) {
        var jsonString : NSString = ""
        do
        {
            let arrJson = try JSONSerialization.data(withJSONObject: self.dictMainEventList.object(forKey: strId) as! NSArray, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
        }
        catch let error as NSError
        {
            print(error.description)
        }
        let arrLandingPoints = self.dictMainEventList[strId] as! NSArray
        let jsonStringLandingPoints = getJSONString(arrLandingPoints)
        
        //set bool variables
        self.dictUpdateBools.setObject("1", forKey: strId as NSCopying)
        
        let enteriesQuery = NSString(format: "INSERT OR REPLACE INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",zoneCreateModal.id, zoneCreateModal.name,jsonStringLandingPoints)
        DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
        proxy.sharedProxy().displayStatusCodeAlert("Zone Updated successfully")
       
    }
    
    
    
    
    //MARK: - Search Action
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar){
        isLandingPointsToBeMarked = false
        // mapVw.removeGestureRecognizer(tapGesture)
        searchBar.text = ""
        self.tableViewPlaces.isHidden = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let delay = 0.1 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            let phrase =  self.searchBar.text!
            // range will be nil if no letters is found
            if  proxy.sharedProxy().containsOnlyLetters(phrase) == true {
                // print("letters found")
                self.search_API(phrase)
            }
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        self.searchBar.showsCancelButton = true
        let delay = 0.5 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            let phrase =  self.searchBar.text!
            // range will be nil if no letters is found
            if  proxy.sharedProxy().containsOnlyLetters(phrase) == true {
                self.search_API(phrase)
            }
            else {
            }
        }
    }
    
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.text = ""
        self.searchBar.showsCancelButton = false
        self.tableViewPlaces.isHidden = true
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar){
        let delay = 1.0 * Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
            self.searchBar.text = ""
            self.searchBar.showsCancelButton = false
            searchBar.resignFirstResponder()
            self.tableViewPlaces.isHidden = true
        }
    }
    
    
    //MARK: - JSON STRING
    func getJSONString(_ arrTemp:NSArray) -> NSString {
        var jsonString : NSString = ""
        do
        {
            let arrJson = try JSONSerialization.data(withJSONObject: arrTemp, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
            return jsonString
            
        }
        catch _ as NSError
        {
            return jsonString
        }
        
    }
    
    //MARK: - DELEGATE CREATE ZONE
    func setLocationOfEventOffline(_ strName:String){
    
        let  arrTemp = NSArray()
        
        let arrTempEvents = DBManager.sharedDatabase().getMessage("SELECT * FROM OfflineTBL order by id ASC")
        let  strZone = "[]"
        var modalObject: EventOffline?
        if arrEventsList.count > 0 {
            modalObject = arrEventsList.lastObject as? EventOffline
        }else{
            modalObject = EventOffline()
            modalObject?.id = 1
            modalObject?.name = strName
            modalObject?.zones = NSArray()
        }
        
        
        if arrTempEvents.count > 0 {
            let enteriesQuery = NSString(format: "INSERT INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",modalObject!.id+1, strName,strZone)
            DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
            //set bool variables
            self.dictUpdateBools.setObject("0", forKey: "\(modalObject!.id+1)" as NSCopying)
            //Set Main dictionary list
            self.dictMainEventList.setObject(arrTemp, forKey: "\(modalObject!.id+1)" as NSCopying)
            let modalNewZone = EventOffline()
            modalNewZone.id = modalObject!.id+1
            modalNewZone.name = strName
            modalNewZone.zones = NSArray()
            arrEventsList.add(modalNewZone)
            if  arrEventsList.count > 0 {
                DispatchQueue.main.async(execute: {
                    self.tableViewEventList.delegate = self
                    self.tableViewEventList.dataSource = self
                    self.tableViewEventList.reloadData()
                })
            }
            
        }else{
            let enteriesQuery = NSString(format: "INSERT INTO 'OfflineTBL' VALUES (%ld,'%@','%@')",1, strName,strZone)
            DBManager.sharedDatabase().executeQuery(enteriesQuery as String)
            //set bool variables
            self.dictUpdateBools.setObject("0", forKey: "\(modalObject!.id)" as NSCopying)
            //Set Main dictionary list
            self.dictMainEventList.setObject(arrTemp, forKey: "\(modalObject!.id)" as NSCopying)
            let modalNewZone = EventOffline()
            modalNewZone.id = modalObject!.id
            modalNewZone.name = strName
            modalNewZone.zones = NSArray()
            arrEventsList.add(modalNewZone)
            if  arrEventsList.count > 0 {
                DispatchQueue.main.async(execute: {
                    self.tableViewEventList.delegate = self
                    self.tableViewEventList.dataSource = self
                    self.tableViewEventList.reloadData()
                })
            }
        }
        
        KAppDelegate.hideActivityIndicator()
        proxy.sharedProxy().displayStatusCodeAlert("Zone created successfully")
    }
    
    
    
    //MARK:- DRAW POLYGON
    func drawPloygon(_ arrDrawAreaZones:NSArray,strTitle:String,strZoneId: String,willShowAnnotaion: Bool,strCreatedUserId: String,willShowDistance: Bool)  {
        let arrDrawAreaCoordinate = NSMutableArray()
        var annotationArrayTemp = [MKAnnotation]()
        let arrTemp = arrDrawAreaZones
        let event_id = strZoneId
        let event_name = strTitle
        var userLoc1 = CLLocationCoordinate2D()
        for i in 0 ..< arrTemp.count{
            var dict = NSDictionary()
            dict = arrTemp[i] as! NSDictionary
            let lat = dict["lat"] as! String
            let long = dict["longt"] as! String
            let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            userLoc1.latitude = Double(newLat)!
            userLoc1.longitude = Double(newLong)!
            if willShowDistance == true {
                let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "",isShowDistance: willShowDistance)
                let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
                if willShowAnnotaion == true {
                    
                }
                annotationArrayTemp.append(annotation)
                arrDrawAreaCoordinate.add(loc)
                
            }else{
                let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "",isShowDistance: willShowDistance)
                let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
                if willShowAnnotaion == true {
                    
                }
                annotationArrayTemp.append(annotation)
                arrDrawAreaCoordinate.add(loc)
                
                
            }
        }
        if arrDrawAreaCoordinate.count > 0
        {
            debugPrint("Coordinate: ",arrDrawAreaCoordinate)
            self.annotationAry = annotationArrayTemp
            let numberOfSteps: Int =  arrDrawAreaCoordinate.count
            var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
            let firstLocation =  arrDrawAreaCoordinate[0] as! CLLocation
            for index in 0 ..< numberOfSteps
            {
                let location: CLLocation =  arrDrawAreaCoordinate[index] as! CLLocation
                points.append(location.coordinate)
            }
            NSLog("ARRAY COORDINATES:%d",points.count)
            points.append(firstLocation.coordinate)
            let polygon = MKPolygon(coordinates: &points, count: points.count)
            polygon.title = strTitle
            print("Polygon name : \(polygon.title!) and center coordinate: \(polygon.coordinate)")
            
            polygon.subtitle = ""
            mapVw.add(polygon)
            self.dictPolygon.setObject(polygon, forKey: strZoneId as NSCopying)
            let centerCoordinate = proxy.sharedProxy().getCenterCoord(points)
            if homeLocationOfUser.latitude == 0.0 && homeLocationOfUser.longitude == 0.0 {
                homeLocationOfUser = self.mapVw.userLocation.coordinate
            }
            
            if CLLocationCoordinate2DIsValid(homeLocationOfUser) {
                if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)) == true{
                    if willShowDistance == true {
                        self.isShowDistance = true
                    }
                    
                }else{
                    self.isShowDistance = false
                }
            }
            
            points.removeLast()
            
            for i in 0 ..< points.count
            {
                let location: CLLocation =  arrDrawAreaCoordinate[i] as! CLLocation
                let coordinate₀ = CLLocation(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)
                let coordinate₁ = CLLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
                let distanceInMeters = Float(proxy.sharedProxy().getDistanceInm(coordinate₀, from: coordinate₁))
                let distance =  String(format: "%0.2f m",distanceInMeters)
                debugPrint("Distance from home location:",distance)
                if willShowDistance == true {
                    let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "\(distance)",isShowDistance: willShowDistance)
                    if willShowAnnotaion == true {
                        mapVw.addAnnotation(annotation)
                    }
                }else{
                    let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "\(distance)",isShowDistance: willShowDistance)
                    if willShowAnnotaion == true {
                        mapVw.addAnnotation(annotation)
                    }
                }
            }
            
            
            
            
            self.dictCenterCoordinatesPolygons.setObject(centerCoordinate, forKey: strZoneId as NSCopying)
            
            let annotation = ZoneNameAnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: centerCoordinate.latitude, longitude: centerCoordinate.longitude ), info: "\(event_id)",index: "")
            self.mapVw.addAnnotation(annotation)
            showPin = false
            isCompleted = true
            debugPrint("Center point coordinates: ",dictCenterCoordinatesPolygons)
        }else{
            var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
            let polygon = MKPolygon(coordinates: &points, count: points.count)
            self.dictPolygon.setObject(polygon, forKey: strZoneId as NSCopying)
            self.dictCenterCoordinatesPolygons.setObject(kCLLocationCoordinate2DInvalid, forKey: strZoneId as NSCopying)
        }
    }
    
    
    //MARK: - API Hit
    func search_API( _ searchText:String){
        let trimmedText = searchText.replacingOccurrences(of: " ", with: "%20")
        let apiAddress = "\(googleBaseURL)"+"place/textsearch/json?query="
        // let apiAddress = "\(googleBaseURL)"
        let searchAddress = apiAddress + trimmedText + apiKey
        hitURL =  "SearchPlace"
        NSLog("searchAdd %@", searchAddress)
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            // KAppDelegate.showActivityIndicator()
            request(searchAddress, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:nil)
                .responseJSON { response in
                    do {
                        // KAppDelegate.hideActivityIndicator()
                        if(response.response?.statusCode == 200) {
                            if let JSON = response.result.value as? NSDictionary{
                                self.serviceResponsePlace(JSON .mutableCopy() as! NSMutableDictionary)
                            }else{
                                proxy.sharedProxy().displayStatusCodeAlert("Error Unable to response from server")
                            }
                            
                        }else {
                            proxy.sharedProxy().stautsHandler(searchAddress, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                        }
                    } catch let error as NSError {
                        // KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().displayStatusCodeAlert(error.description)
                    }
            }
        }else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponsePlace(_ JSON:NSMutableDictionary) {
        if(hitURL ==  "SearchPlace") {
            if (JSON["status"]! as AnyObject).isEqual("OK")
            {
                let resultsArray = JSON["results"] as! NSArray
                //   NSLog("Address %@", resultsArray)
                self.locationArray.removeAllObjects()
                for i in 0 ..< resultsArray.count {
                    var dict = NSMutableDictionary()
                    dict = (resultsArray[i] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                    let locationDict = NSMutableDictionary()
                    locationDict.setValue("\(dict["formatted_address"]!)", forKey: "sub_Address" )
                    locationDict.setValue("\(dict["formatted_address"]!)", forKey: "name" )
                    let strlat = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lat") as! NSNumber
                    let strlong = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lng") as! NSNumber
                    locationDict.setValue(strlat, forKey: "lat")
                    locationDict.setValue(strlong, forKey: "lng")
                    self.locationArray.add(locationDict)
                }
                let delay = 0.1 * Double(NSEC_PER_SEC)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                    if self.locationArray.count > 0 {
                        self.tableViewPlaces.reloadData()
                    }
                    self.hitURL =  ""
                }
            }
            else
            {
                let errorMessage = JSON["status"] as! String
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
            }
        }
    }
    
    
    func getEventZone()  {

        if UserDefaults.standard.object(forKey: "lat") != nil {
                let lat =  UserDefaults.standard.object(forKey: "lat") as! String
                let long = UserDefaults.standard.object(forKey: "long") as! String
                var userLoc = CLLocationCoordinate2D()
                userLoc.latitude = CDouble(lat)!
                userLoc.longitude = CDouble(long)!
                let span = MKCoordinateSpanMake(0.02, 0.02)
                let region = MKCoordinateRegion(center: userLoc, span: span)
                mapVw.setRegion(region, animated: true)
                mapVw.showsUserLocation = true
                homeLocationOfUser = userLoc
            }
       
        let arrTemp  = zone_array
        if arrTemp.count > 0 {
          
            //set bool variables
            var userLoc = CLLocationCoordinate2D()
            let dict = arrTemp.object(at: 0)
            let lat =  (dict as AnyObject).object(forKey: "lat") as! String
            let long = (dict as AnyObject).object(forKey: "longt") as! String
            let newLat1 = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let newLong2 = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            if newLat1.characters.count > 0 && newLong2.characters.count > 0 {
                userLoc.latitude = Double(newLat1)!
                userLoc.longitude = Double(newLong2)!
            }
            
            let span = MKCoordinateSpanMake(0.02, 0.02)
            let region = MKCoordinateRegion(center: userLoc, span: span)
            mapVw.setRegion(region, animated: true)
            mapVw.showsUserLocation = true
            self.dictUpdateBools.setObject("1", forKey: "\(zone_id)" as NSCopying)
        }else{
           
            //set bool variables
            self.dictUpdateBools.setObject("0", forKey: "\(zone_id)" as NSCopying)
        }
        //Set Main dictionary list
        self.dictMainEventList.setObject(zone_array, forKey: "\(zone_id)" as NSCopying)
        self.drawPloygon(arrTemp, strTitle: zone_name, strZoneId: "\(zone_id)", willShowAnnotaion: false,strCreatedUserId: "",willShowDistance:false)
        if zone_id != 0 {
            let modalObject = EventOffline()
            modalObject.id = zone_id
            modalObject.name = zone_name
            modalObject.zones = zone_array
            arrEventsList.add(modalObject)
            self.zoneCreateModal = modalObject
            firstModal = modalObject
            if arrEventsList.count > 0 {
                tableViewEventList.reloadData()
            }
        }
       

        if zone_array.count > 0 {
              self.drawPloygon(arrTemp, strTitle: zone_name, strZoneId: "\(zone_id)", willShowAnnotaion: false,strCreatedUserId: "",willShowDistance:false)
        }
        
    }

    func setUpUI()  {
        vwSimulatorControl.isHidden = true
        vwSimulatorControl.layer.cornerRadius = 8
//        vwDeletePoints.layer.cornerRadius = 8
//        vwDeletePoints.isHidden = true
        vwDataFromDrone.layer.cornerRadius = 8.0
        cnstHelipadPops.constant = 0
        virtualStickLeft.isHidden = true
        virtualStickRight.isHidden = true
        vwDataFromDrone.isHidden = true
        
        //Initail left stick
        lblYPositiveLeftStick.layer.borderWidth = 1.0
        lblYPositiveLeftStick.layer.borderColor = UIColor.black.cgColor
        lblXPosPositionLeftStick.layer.borderWidth = 1.0
        lblXPosPositionLeftStick.layer.borderColor = UIColor.black.cgColor
        
        //Initial right stick
        lblYPosRight.layer.borderWidth = 1.0
        lblYPosRight.layer.borderColor = UIColor.black.cgColor
        lblXPosRight.layer.borderWidth = 1.0
        lblXPosRight.layer.borderColor = UIColor.black.cgColor
        
        //Initial velocity
        lblYAircraftVelocity.layer.borderWidth = 1.0
        lblYAircraftVelocity.layer.borderColor = UIColor.black.cgColor
        lblXAircraftVelocity.layer.borderWidth = 1.0
        lblXAircraftVelocity.layer.borderColor = UIColor.black.cgColor
        //Initial z above ground
        lblZAboveGround.layer.borderWidth = 1.0
        lblZAboveGround.layer.borderColor = UIColor.black.cgColor
    }
    
    
    
    //MARK: - ViewController lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        imgTagRight.isHidden = true
        imgTagLeft.isHidden = true
        vwImageLeft.isHidden = true
        self.lblTransmissionTime.text = "I/O Time: 0.0 sec"
        self.lblTransmissionTime.isHidden = true
        btnIsEnteredLandingRegion.isHidden = true
        self.droneLocationCoordinate = kCLLocationCoordinate2DInvalid
        isLandingPointsToBeDeleted = false
        isPinPointsToBeDeleted = false
        self.setUpUI()
        self.flightControlSetup()
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = true
        cnstVwSettings.constant = 0
        cnstVwSettingsBottom.constant = 30
        isCompleted = false
        
        //For TapGesture Recognization
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(CreateZoneOnlineVC.recognizeTapGesture(_:)))
        mapVw.addGestureRecognizer(tapGesture)
        tapGesture.delegate = self
        self.showPin = false
        if #available(iOS 9.0, *) {
            mapVw.mapType = .hybridFlyover
        } else {
            mapVw.mapType = .hybrid
        }
        self.mapVw.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
            let span = MKCoordinateSpanMake(0.025, 0.025)
            let region = MKCoordinateRegion(center: userLoc, span: span)
            mapVw.setRegion(region, animated: true)
            mapVw.showsUserLocation = true
        }
        isLandingPointsOutside = false
        self.getEventZone()
    }
    
    func flightControlSetup() {
        //Flight control setUp
        virtualStickLeft.layer.cornerRadius = 64
        virtualStickRight.layer.cornerRadius = 64
        
        btnReadyToFly.layer.cornerRadius = 5
        btnReadyToFly.layer.borderWidth = 1
        btnReadyToFly.layer.borderColor = UIColor.white.cgColor
        
        NotificationCenter.default.addObserver(self, selector: #selector(CreateZoneOnlineVC.onStickChanged(notification:)) , name: NSNotification.Name(rawValue: "StickChanged"), object: nil)
        
        
    }
    
    
    func onStickChanged(notification:NSNotification) {
        let dict = notification.userInfo! as NSDictionary
        let vdir = dict.object(forKey: "dir") as! NSValue
        let dir = vdir.cgPointValue
        if let  virtualStick = (notification.object! as? VirtualStickView){
            if virtualStick == self.virtualStickLeft {
                self.setThrottle(Float(dir.y), andYaw: Float(dir.x))
            }
            else {
                self.setXVelocity(-(Float)(dir.y), andYVelocity: Float(dir.x))
            }
            
            
        }
    }
    
    @IBAction func btnPrssActionDone(_ sender: AnyObject) {
        isLandingPointsToBeDeleted = false
        isLandingPointsToBeMarked = false
        vwEventsLists.isHidden = false
        btnZonesList.isSelected = true
        isPlacePolygon = true
        isAltitude = false
        isDrawPolygon = false
        isDeletePolygon = false
        //Place polygon
        
        if UserDefaults.standard.object(forKey: "lat") != nil &&  UserDefaults.standard.object(forKey: "long") != nil{
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            var userLoc = CLLocationCoordinate2D()
            userLoc.latitude = CDouble(lat)!
            userLoc.longitude = CDouble(long)!
            if CLLocationCoordinate2DIsValid(userLoc){
                let span = MKCoordinateSpanMake(0.001, 0.001)
                let region = MKCoordinateRegion(center: userLoc, span: span)
                mapVw.setRegion(region, animated: true)
                mapVw.showsUserLocation = true
            }
        }
     
            isDragToPoint = true
            isLandingPointsToBeMarked = false
            if zoneCreateModal.id != 0 {
                let arrTemp = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
                if arrTemp.count == 0 {
                    showPin = true
                    counter = 0
                }else{
                    showPin = false
                    counter = 0
                }
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please create zone")
            }
        
    }
    
    @IBOutlet weak var btnPrssDone: UIButton!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
       
        self.registerApp(isReigster: willRegisterApp)
        
        if(UIDevice.current.orientation == .landscapeLeft || UIDevice.current.orientation == .landscapeRight || UIDevice.current.orientation == .unknown || UIDevice.current.orientation == .faceUp || UIDevice.current.orientation == .faceDown)
        {
            debugPrint("landscape")
        }else{
            UIDevice.current.setValue(UIInterfaceOrientation.landscapeLeft.rawValue, forKey: "orientation")
        }
        vwEventsLists.isHidden = true
        
        //set bool variable
        self.navigationController?.isNavigationBarHidden = true
        isPlacePolygon = false
        isAltitude = false
        isDrawPolygon = false
        isDeletePolygon = false
        self.view.bringSubview(toFront: vwSeparateAltitude)
        tableViewPlaces.backgroundColor = UIColor.clear
        tableViewPlaces.dataSource=self
        tableViewPlaces.delegate=self
        self.tableViewPlaces.isHidden = true
        self.view.bringSubview(toFront: tableViewPlaces)
        selectedIndexPath = IndexPath(row: 0, section: 0)
        isDragToPoint = true
        isUpdate = false
        self.isDragPin = false
        
        //bool set
        lblUserName.text = modalEventListOnline.create_user_name
        lblOnlineGroupName.text = modalEventListOnline.group_name
        lblEventName.text = modalEventListOnline.name
        
        //set images
        btnDrawEdit.setImage(UIImage(named: "path_heli"), for: UIControlState())
        btnEditOutlet.setImage(UIImage(named: "altitude"), for: UIControlState())
        btnDone.setImage(UIImage(named: "tickSettings"), for: UIControlState())
        btnDeleteZone.setImage(UIImage(named: "deleteZone"), for: UIControlState())
        strCurrentEventId = "\(modalEventListOnline.id)"
        vwSeparateAltitude.isHidden = true
        vwChooseAltitude.isHidden = true
        vwCollectiveAltitudes.isHidden = true
        counter = 0
        
        
        
    }
    
    
    func checkShortestDistanceBetweenToPoints() {
        
        userLoc = CLLocationCoordinate2DMake(30.713314,  76.709398)
        let droneLocationPoint =   self.mapVw.convert(userLoc, toPointTo: self.mapVw)
        //1.Draw lines and convert location to x-y coordinates
        let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
        let arrDroneLivePositionNearestEdges = NSMutableArray()
        if arrTemp.count > 0{
            
            for i in 0..<arrTemp.count {
                //GET LOCATION COORDINATES
                
                if i < arrTemp.count-1 {
                    let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i] as! NSMutableDictionary)
                    let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i+1] as! NSMutableDictionary)
                    let droneNearestEdgePoint = proxy.sharedProxy().distanceFromPoint(p: droneLocationPoint, toLineSegment: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosA, mapView: self.mapVw), and: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosB, mapView: self.mapVw))
                    arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                    
                }else{
                    let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[0] as! NSMutableDictionary)
                    let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[arrTemp.count - 1] as! NSMutableDictionary)
                    let droneNearestEdgePoint = proxy.sharedProxy().distanceFromPoint(p: droneLocationPoint, toLineSegment: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosA, mapView: self.mapVw), and: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosB, mapView: self.mapVw))
                    arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                }
            }
            
            
            
            
            var minimum_edge_distance = (arrDroneLivePositionNearestEdges[0] as! NSDictionary).object(forKey: "minimum_distance") as! CGFloat
            var indexPosition = 0
            
            //2.FIND MINIMUM COORDINATES DISTANCE EDGE
            for i in 0..<arrDroneLivePositionNearestEdges.count{
                let dictEdgeInfo = arrDroneLivePositionNearestEdges[i] as! NSDictionary
                let edge_distance = dictEdgeInfo.object(forKey: "minimum_distance") as! CGFloat
                if edge_distance <= minimum_edge_distance {
                    minimum_edge_distance = edge_distance
                    indexPosition = i
                }
            }
            
            //3.GET DISTANCE BETWEEN TWO LATITUDE AND LONGITUDE
            let xPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "xPos") as! CGFloat
            let yPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "yPos") as! CGFloat
            let droneNearestPointInCoordinateSytem = CGPoint(x: xPosition, y: yPosition)
            let locationCoordinate = mapVw.convert(droneNearestPointInCoordinateSytem,toCoordinateFrom: mapVw)
            let coordinate₀ = CLLocation(latitude: self.userLoc.latitude, longitude: self.userLoc.longitude)
            
            let coordinate₁ = CLLocation(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude)
            let distanceInMeters = coordinate₀.distance(from: coordinate₁)
            debugPrint("shortest distance :",distanceInMeters)
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        if self.product.isConnected == true {
            DJISDKManager.stopConnectionToProduct()
            
        }
        
    }
    
    func convertedPoints(_ containingPoint:CGPoint,containerView:UIView) -> CGPoint {
        print("Previuos point: \(containingPoint)")
        let point = self.mapVw.convert(containingPoint, from: containerView)
        print("Next point: \(point)")
        return point
    }
    
    func didPan(_ panGR: UIPanGestureRecognizer) {
        self.mapVw.bringSubview(toFront: self.vw)
        //Set transformation
        var translation = panGR.translation(in: self.mapVw)
        translation = translation.applying(self.mapVw.transform)
        self.vw.center.x += translation.x
        self.vw.center.y += translation.y
        panGR.setTranslation(CGPoint.zero, in: self.mapVw)
        print("coordinates x: \(vw.frame.origin.x) y: \(vw.frame.origin.y)")
        
        self.mapVw.isUserInteractionEnabled = false;
        
        if panGR.state == .ended {
            self.mapVw.isUserInteractionEnabled = true;
            let arrZones = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
            let arrPoints = NSMutableArray()
            let arrLocationCoordinates = NSMutableArray()
            var zoneLoc = CLLocationCoordinate2D()

            //Convert lat and longitude to x and y pos of zone
            for i in 0 ..< arrZones.count {
                let dict = (arrZones[i] as! NSDictionary) .mutableCopy() as! NSMutableDictionary
                let lat = dict["lat"] as! String
                let long = dict["longt"] as! String
                let min_height = Int32(((dict["min_alt"] as! NSString).intValue))
                let max_height = Int32(((dict["max_alt"] as! NSString).intValue))
                let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                zoneLoc.latitude = Double(newLat)!
                zoneLoc.longitude = Double(newLong)!
                let point = self.mapVw.convert(zoneLoc, toPointTo: self.mapVw)
                let dictPoints = NSMutableDictionary()
                dictPoints.setObject(vw.frame.origin.x+point.x, forKey: "xPos" as NSCopying)
                dictPoints.setObject(vw.frame.origin.y+point.y, forKey: "yPos" as NSCopying)
                dictPoints.setObject("\(min_height)", forKey: "min_alt" as NSCopying)
                dictPoints.setObject("\(max_height)", forKey: "max_alt" as NSCopying)
                arrPoints.add(dictPoints)
            }
            
            //convert x and y position to coordinates
            for i in 0 ..< arrPoints.count {
                let dict = arrPoints[i] as! NSMutableDictionary
                let xPos =  Int32(Float(dict["xPos"] as! NSNumber))
                let yPos =  Int32(Float(dict["yPos"] as! NSNumber))
                let min_height = Int32(((dict["min_alt"] as! NSString).intValue))
                let max_height = Int32(((dict["max_alt"] as! NSString).intValue))
                let point = CGPoint(x: CGFloat(xPos), y: CGFloat(yPos))
                let locationCoordinate = mapVw.convert(point,toCoordinateFrom: mapVw)
                let dictCoordinates = NSMutableDictionary()
                dictCoordinates.setObject("\(locationCoordinate.latitude)", forKey: "lat" as NSCopying)
                dictCoordinates.setObject("\(locationCoordinate.longitude)", forKey: "longt" as NSCopying)
                dictCoordinates.setObject("\(min_height)", forKey: "min_alt" as NSCopying)
                dictCoordinates.setObject("\(max_height)", forKey: "max_alt" as NSCopying)
                arrLocationCoordinates.add(dictCoordinates)
            }
            
           
            linePath.removeAllPoints()
            
            self.dictMainEventList.setObject(arrLocationCoordinates, forKey: "\(zoneCreateModal.id)" as NSCopying)
            
            //make new polygon
            let arrPolygonPoints = proxy.sharedProxy().getCllocationCoordinate2d(arrLocationCoordinates)
            var pointsPolygon = proxy.sharedProxy().makeCoordinatePoints(arrPolygonPoints)
            //check is inside
            let firstLocation =  arrPolygonPoints[0] as! CLLocation
            pointsPolygon.append(firstLocation.coordinate)
            let polygon = MKPolygon(coordinates: &pointsPolygon, count: pointsPolygon.count)
            self.dictPolygon.setObject(polygon, forKey: "\(zoneCreateModal.id)" as NSCopying)
            
            let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
            var isIntersectionFound = false
            for i in 0..<self.arrEventsList.count{
                
                let modalEvent  = self.arrEventsList[i] as! EventOffline
                if zoneCreateModal.id != modalEvent.id {
                    let arrZonesOther = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                    if arrZonesOther.count > 0 {
                        let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                        
                        // let somePolygon = currrent_polygon.fromDifference(with: other_polygon)
                        let somePolygon =  MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                        if somePolygon!.pointCount > 0 {
                            isIntersectionFound = true
                            break
                        }
                    }
                }
            }
            
            if isIntersectionFound == true{
                isOverLapped = true
            }else{
                isOverLapped = false
            }
            
            self.drawPloygon(arrLocationCoordinates, strTitle: zoneCreateModal.name, strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: true, strCreatedUserId: "",willShowDistance:true)
            self.vw.removeFromSuperview()
            self.line.removeFromSuperlayer()
            for subView in vw.subviews {
                subView.removeFromSuperview()
            }
        }
    }
    
    //MARK:- TapGesture Recognizer
    func openImage(_ sender: UITapGestureRecognizer)
    {
        let point = sender.view
        print("index: \(point?.tag)")
    }
    
    func recognizeTapGesture(_ gestureReconizer: UITapGestureRecognizer) {
        if showPin == true {
            counter+=1
            let touchLocation = gestureReconizer.location(in: mapVw)
            let locationCoordinate = mapVw.convert(touchLocation,toCoordinateFrom: mapVw)
            
            print("Tapped index \(counter) lat: \(locationCoordinate.latitude) long: \(locationCoordinate.longitude)")
            print("Counter : ",counter)
            print("Location x: and y:",touchLocation.x,touchLocation.y)
            
            if isLandingPointsToBeMarked == true {
                if  zoneCreateModal.id != 0 {
                }
            }else{
                if  zoneCreateModal.id != 0 {
                        if counter <= 20 {
                            
                            
                            
                            self.isShowDistance = false
                            let annotation = AnnotationModal(title: zoneCreateModal.name, coordinate: CLLocationCoordinate2D(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude), info: "\(zoneCreateModal.id)",index: "\(counter)",distnaceFromHomeLocation: "",isShowDistance: false)
                            mapVw.addAnnotation(annotation)
                            let dictZoneInfo = NSMutableDictionary()
                            dictZoneInfo.setObject("\(locationCoordinate.latitude)", forKey: "lat" as NSCopying)
                            dictZoneInfo.setObject(" \(locationCoordinate.longitude)", forKey: "longt" as NSCopying)
                            dictZoneInfo.setObject("66", forKey: "min_alt" as NSCopying)
                            dictZoneInfo.setObject("70", forKey: "max_alt" as NSCopying)
                            let arrSome = self.dictMainEventList["\(zoneCreateModal.id)"] as! NSArray
                            let arrTemp  = NSMutableArray(array: arrSome)
                            arrTemp.add(dictZoneInfo)
                            self.dictMainEventList.setObject(arrTemp, forKey: "\(zoneCreateModal.id)" as NSCopying)
                            annotationAry.append(annotation)
                        }else{
                            
                            proxy.sharedProxy().displayStatusCodeAlert("You have reached the maximum number of points to place polygon")
                        }
                    
                }
            }
        }
    }
    
    //MARK: - VALIDATE POINTS
    func isInsideThePolygon(_ polygon:MKPolygon,sampleLocation:CLLocationCoordinate2D) -> Bool {
        let mapPoint = MKMapPointForCoordinate(sampleLocation)
        let mapPointAsCGP = CGPoint(x: CGFloat(mapPoint.x),y: CGFloat(mapPoint.y))
        var isInside = false
        let mpr = CGMutablePath()
        let polygonPoints = polygon.points()
        for p in 0..<polygon.pointCount {
            let mp = polygonPoints[p]
            if p == 0 {
                mpr.move(to: CGPoint(x: CGFloat(mp.x), y: CGFloat(mp.y)))
            }
            else {
                mpr.addLine(to: CGPoint(x: CGFloat(mp.x), y: CGFloat(mp.y)))
            }
        }
        
        if mpr.contains(mapPointAsCGP) {
            isInside = true
        }
        
        return isInside
    }
    
    //MARK:- DELEGATE
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tableViewEventList {
            tableViewEventList.estimatedRowHeight = 70
            return UITableViewAutomaticDimension
        }else{
            tableViewPlaces.estimatedRowHeight = 60
            return UITableViewAutomaticDimension
        }
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tableViewEventList {
            let  cell = tableView.dequeueReusableCell(withIdentifier: "cellEventList", for: indexPath) as! EventListOnLineTVC
            let modalObject = arrEventsList[(indexPath as NSIndexPath).row] as! EventOffline
            cell.lblZoneName.text = modalObject.name
            let converted_max_ht = proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalObject.zones).object(forKey: "maximum_height") as! Float
            let converted_min_ht =  proxy.sharedProxy().getAltitudeDictionary(arrTemp: modalObject.zones).object(forKey: "minimum_height") as! Float
            cell.lblMaxMinimumHeight.text = "\(Int32(converted_min_ht)) " + "/" + "\(Int32(converted_max_ht))" + " m"
            cell.lblCreatedUserName.text = ""
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cellLocation", for: indexPath) as! SearchLocationTVC
            let locDict = locationArray[(indexPath as NSIndexPath).row] as! NSDictionary
            cell.lblPlaces.text = locDict["name"] as? String
            return cell
        }
    }
    
    //MARK: Map Conversion Methods
    fileprivate func longitudeToPixelSpaceX(_ longitude:Double)->Double{
        return round(MERCATOR_OFFSET + MERCATOR_RADIUS * longitude * M_PI / DEGREES)
    }
    
    fileprivate func latitudeToPixelSpaceY(_ latitude:Double)->Double{
        return round(MERCATOR_OFFSET - MERCATOR_RADIUS * log((1 + sin(latitude * M_PI / DEGREES)) / (1 - sin(latitude * M_PI / DEGREES))) / 2.0)
    }
    
    fileprivate func pixelSpaceXToLongitude(_ pixelX:Double)->Double{
        return ((round(pixelX) - MERCATOR_OFFSET) / MERCATOR_RADIUS) * DEGREES / M_PI
        
    }
    
    fileprivate func pixelSpaceYToLatitude(_ pixelY:Double)->Double{
        return (M_PI / 2.0 - 2.0 * atan(exp((round(pixelY) - MERCATOR_OFFSET) / MERCATOR_RADIUS))) * DEGREES / M_PI
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath){
        
        if arrEventsList.count > 0 {
            isLandingPointsToBeMarked = false
            let modalEvent  = self.arrEventsList[indexPath.row] as! EventOffline
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                var annotationIsDeleted = false
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                            annotationIsDeleted = true
                        }
                    }
                }
            
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        isLandingPointsToBeMarked = false
        if tableView == tableViewEventList {
            
            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
            let modalEvent  = self.arrEventsList[indexPath.row] as! EventOffline
            if modalEvent.zones.count > 0 {
                
            }
                
                //Polygon pin points
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: AnnotationModal.self) {
                        let annotaion = someAnnotation as! AnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //1.Remove the previous polygon
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        print("Zone Name : \(strTitle)")
                        if strTitle == self.zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                }
                
                //Remove center coordinate
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self){
                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                if zoneCreateModal.id != 0  {
                    //Create previuos polygon
                    let  arrTempPrev  = self.dictMainEventList.object(forKey: "\(self.zoneCreateModal.id)") as! NSArray
                    if arrTempPrev.count > 0 {
                        self.isOverLapped = false
                        self.drawPloygon(arrTempPrev, strTitle: "\(zoneCreateModal.name)", strZoneId: "\(zoneCreateModal.id)", willShowAnnotaion: false,strCreatedUserId: "",willShowDistance:false)
                    }
                }
                
                //other polygon
                self.zoneCreateModal = modalEvent
                selectedIndexPath = indexPath
                
                //Updating polygon
                for someAnnotation in annotationsToRemove {
                    let strId = "\(zoneCreateModal.id)"
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                
                isDragPin = true
                let  arrTemp  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                var isOverlayDraw = false
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        if strTitle == modalEvent.name {
                            isOverlayDraw = true
                        }
                    }
                }
                
                var isIntersectionFound = false
                let  arrTempCurrent  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                if arrTempCurrent.count > 0 {
                    let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                    for i in 0..<self.arrEventsList.count{
                        let modalEvent  = self.arrEventsList[i] as! EventOffline
                        if zoneCreateModal.id != modalEvent.id {
                            let  arrTempOther  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                            if arrTempOther.count > 0 {
                                let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                                let somePolygon = MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                                if somePolygon!.pointCount > 0 {
                                    isIntersectionFound = true
                                    break
                                }
                            }
                        }
                    }
                }
                
                
                //2.Remove second overlay
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        print("Zone Name : \(strTitle)")
                        if strTitle == self.zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                }
                
                if isIntersectionFound == true{
                    isOverLapped = true
                }else{
                    isOverLapped = false
                }
                
                if arrTemp.count > 0 {
                    self.drawPloygon(arrTemp, strTitle: zoneCreateModal.name, strZoneId: "\(modalEvent.id)", willShowAnnotaion: true,strCreatedUserId: "",willShowDistance:true)
                }
                
                
                let arrDrawAreaCoordinate = NSMutableArray()
                var annotationArrayTemp = [MKAnnotation]()
                let event_id = modalEvent.id
                let event_name = modalEvent.name
                var userLoc1 = CLLocationCoordinate2D()
                for i in 0 ..< arrTemp.count{
                    var dict = NSDictionary()
                    dict = arrTemp[i] as! NSDictionary
                    let lat = dict["lat"] as! String
                    let long = dict["longt"] as! String
                    let newLat = lat.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                    let newLong = long.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
                    userLoc1.latitude = Double(newLat)!
                    userLoc1.longitude = Double(newLong)!
                    let annotation = AnnotationModal(title: event_name, coordinate: CLLocationCoordinate2D(latitude: userLoc1.latitude, longitude: userLoc1.longitude ), info: "\(event_id)",index: "\(i+1)",distnaceFromHomeLocation: "",isShowDistance: false)
                    let loc: CLLocation = CLLocation(latitude: userLoc1.latitude, longitude: userLoc1.longitude)
                    // mapVw.addAnnotation(annotation)
                    annotationArrayTemp.append(annotation)
                    arrDrawAreaCoordinate.add(loc)
                }
                
                if arrDrawAreaCoordinate.count > 0
                {
                    showPin = false
                    isCompleted = true
                }
                
                let  arrZones  = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSArray
                if arrZones.count > 0 {
                    let numberOfSteps: Int =  arrDrawAreaCoordinate.count
                    var points: [CLLocationCoordinate2D] = [CLLocationCoordinate2D]()
                    let firstLocation =  arrDrawAreaCoordinate[0] as! CLLocation
                    for index in 0 ..< numberOfSteps
                    {
                        let location: CLLocation =  arrDrawAreaCoordinate[index] as! CLLocation
                        points.append(location.coordinate)
                    }
                    NSLog("ARRAY COORDINATES:%d",points.count)
                    points.append(firstLocation.coordinate)
                    let centerCoordinates = proxy.sharedProxy().getCenterCoord(points)
                    let span = MKCoordinateSpanMake(0.02, 0.02)
                    let region = MKCoordinateRegion(center: centerCoordinates, span: span)
                    mapVw.setRegion(region, animated: true)
                }
            
        }else{
            //Search locations
            self.searchBar.text = ""
            self.searchBar.showsCancelButton = false
            searchBar.resignFirstResponder()
            if locationArray.count > 0 {
                let locDict = locationArray[(indexPath as NSIndexPath).row] as! NSDictionary
                let Lat = locDict.value(forKey: "lat") as! Float64
                let Long = locDict.value(forKey: "lng") as! Float64
                if locDict.value(forKey: "lat") != nil  &&  locDict.value(forKey: "lng") != nil{
                    let lat =  Lat
                    let long = Long
                    var userLoc = CLLocationCoordinate2D()
                    userLoc.latitude = CDouble(lat)
                    userLoc.longitude = CDouble(long)
                    let span = MKCoordinateSpanMake(0.025, 0.025)
                    let region = MKCoordinateRegion(center: userLoc, span: span)
                    mapVw.setRegion(region, animated: true)
                    mapVw.showsUserLocation = true
                    tableViewPlaces.isHidden = true
                    tableViewPlaces.deselectRow(at: indexPath, animated: false)
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableViewEventList {
            return self.arrEventsList.count
        }else{
            return locationArray.count
        }
    }
    
    //MARK: - OTHER DELEGATE
    
    //MARK:- GESTURERECOGNIZER AND MAPKIT DELEGATE
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool{
        return true
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, didChange newState: MKAnnotationViewDragState, fromOldState oldState: MKAnnotationViewDragState) {
        switch (newState) {
        case .ending :
            let annotation = view.annotation as? AnnotationModal
            if view.annotation!.isKind(of: AnnotationModal.self) {
                let arrTempDrawPolygon = (self.dictMainEventList.object(forKey: (annotation!.info)) as! NSArray) .mutableCopy() as! NSMutableArray
                let coord = (view.annotation?.coordinate)! as CLLocationCoordinate2D
                view.dragState = .none
                view.isSelected = false
                let dict = (arrTempDrawPolygon[view.tag-1] as! NSDictionary) .mutableCopy() as! NSMutableDictionary
                dict["lat"] = "\(coord.latitude)"
                dict["longt"] = "\(coord.longitude)"
                arrTempDrawPolygon.replaceObject(at: view.tag-1, with: dict)
                
                //Delete annotation
                let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: AnnotationModal.self) {
                        let annotaion = someAnnotation as! AnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                        let annotaion = someAnnotation as! ZoneNameAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Delete center coordinates
                for someAnnotation in annotationsToRemove {
                    let strId = "\(annotation!.info)"
                    if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                        let annotaion = someAnnotation as! LandingPointAnnotationModal
                        if annotaion.info == strId {
                            self.mapVw.removeAnnotation(someAnnotation)
                        }
                    }
                }
                
                //Remove overlay
                for overlay in self.mapVw.overlays {
                    if overlay.isKind(of: MKPolygon.self) {
                        let strTitle = String(validatingUTF8: overlay.title!!)!
                        if strTitle == zoneCreateModal.name {
                            self.mapVw.remove(overlay)
                        }
                    }
                }
                
                //Get landing points locations
                var isLandingPointsInside = true
                
                self.dictMainEventList.setObject(arrTempDrawPolygon, forKey: "\(annotation!.info)" as NSCopying)
                let currrent_polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
                var isIntersectionFound = false
                for i in 0..<self.arrEventsList.count{
                    let modalEvent  = self.arrEventsList[i] as! EventOffline
                    if zoneCreateModal.id != modalEvent.id {
                        let arrTempZones = self.dictMainEventList.object(forKey: "\(modalEvent.id)") as! NSMutableArray
                        if arrTempZones.count > 0 {
                            let other_polygon = self.dictPolygon.object(forKey: "\(modalEvent.id)") as! MKPolygon
                            let somePolygon = MKPolygon.init(currrent_polygon, intersectedWithSecondPolygon: other_polygon)
                            if somePolygon!.pointCount > 0 {
                                isIntersectionFound = true
                                break
                            }
                        }
                    }
                }
                
                if isIntersectionFound == true{
                    isOverLapped = true
                }else{
                    isOverLapped = false
                    
                }
                
//                let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as! MKPolygon
//                if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)) == true  {
//                    isLandingPointsInside = true
//                }else{
//                    
//                    isLandingPointsInside = false
//                }
                
                self.drawPloygon(arrTempDrawPolygon, strTitle: zoneCreateModal.name, strZoneId: "\(annotation!.info)", willShowAnnotaion: true,strCreatedUserId: "",willShowDistance:false)
               
                if let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as? MKPolygon{
                    if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)) == true{
                      
                        //1.Draw lines and convert location to x-y coordinates
                        let  arrEdges  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
                        var checkIfDistanceIsGreater = false
                        if arrEdges.count > 0{
                            
                            for i in 0..<arrEdges.count {
                            let dict = (arrEdges[i] as! NSDictionary) .mutableCopy() as! NSMutableDictionary
                        //GET LOCATION COORDINATES
            let edgeLocation = proxy.sharedProxy().getLocationFromDictionary(dict)
                        if CLLocationCoordinate2DIsValid(self.homeLocationOfUser) {
                                    let coordinate₀ = CLLocation(latitude: edgeLocation.latitude, longitude: edgeLocation.longitude)
                                    let coordinate₁ = CLLocation(latitude: self.homeLocationOfUser.latitude, longitude: self.homeLocationOfUser.longitude)
                                    let distanceInMeters = Float(proxy.sharedProxy().getDistanceInm(coordinate₀, from: coordinate₁))
                                    if distanceInMeters >= 500.0 {
                                        checkIfDistanceIsGreater = true
                                        break
                                    }
                                }
                            }
                        }
                        
                        if checkIfDistanceIsGreater == true {
                            proxy.sharedProxy().displayStatusCodeAlert("Please make sure that location of each edge point of polygon should be less than 500.0 m distance from drone location")
                        }
                    }
                }
                
                
//                if isLandingPointsInside == true{
//                    isLandingPointsOutside = false
//                    
//                }else{
//                    isLandingPointsOutside = true
//                    proxy.sharedProxy().displayStatusCodeAlert("Please place polygon points so that all landing points are inside the polygon")
//                }
                
            }else{
                let annoatationLanding = view.annotation as! LandingPointAnnotationModal
                if ((view.annotation!.isKind(of: LandingPointAnnotationModal.self)) ) {
                }
            }
            break
        default: break
        }
        
    }
    

    //MARK:- DELETE ANNOTATION
    func deleteAnnotation(_ strAnnotation:String) {
        //Delete annotation
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            if someAnnotation.isKind(of: AnnotationModal.self) {
                let annotaion = someAnnotation as! AnnotationModal
                if annotaion.info == strAnnotation {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
    }
    
    func deleteCenterCoordinates(_ strAnnotation:String) {
        //Delete center coordinates
        let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
        for someAnnotation in annotationsToRemove {
            if someAnnotation.isKind(of: ZoneNameAnnotationModal.self) {
                let annotaion = someAnnotation as! ZoneNameAnnotationModal
                if annotaion.info == strAnnotation {
                    self.mapVw.removeAnnotation(someAnnotation)
                }
            }
        }
    }
    
    func deleleteOverlayPoints(_ name:String)  {
        //Remove overlay
        for overlay in self.mapVw.overlays {
            if overlay.isKind(of: MKPolygon.self) {
                let strTitle = String(validatingUTF8: overlay.title!!)!
                if strTitle == name {
                    self.mapVw.remove(overlay)
                }
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let imgView = UIImageView()
        imgView.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        imgView.image =  UIImage(named: "location")
        if (annotation.isKind(of: MKUserLocation.self)) {
            return nil
        }
        let reuseId = "createZoneArea"
        if (annotation.isKind(of: AnnotationModal.self)) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            let cpa = annotation as! AnnotationModal
            if self.isShowDistance == true {
                
                let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 70))
                altitudeVw.backgroundColor = UIColor.clear
                altitudeVw.addSubview(imgView)
                let lblTitle = UILabel(frame: CGRect(x: 10, y: 2, width: 30, height: 30))
                lblTitle.font = lblTitle.font.withSize(15)
                lblTitle.text = cpa.index
                lblTitle.textAlignment = NSTextAlignment.center
                lblTitle.textColor = UIColor.white
                
                //Distance from center
                let lblDistanceFromCenter = UILabel(frame: CGRect(x: 0, y: 52, width: 50, height: 20))
                lblDistanceFromCenter.layer.borderColor = UIColor.black.cgColor
                lblDistanceFromCenter.layer.borderWidth = 1.0
                lblDistanceFromCenter.layer.cornerRadius = 6.0
                lblDistanceFromCenter.backgroundColor = UIColor.white
                debugPrint("Distance from home point: \(cpa.distnaceFromHomeLocation)")
                lblDistanceFromCenter.text = "\(cpa.distnaceFromHomeLocation)"
                lblDistanceFromCenter.textAlignment = .center
                lblDistanceFromCenter.clipsToBounds = true
                lblDistanceFromCenter.font = lblTitle.font.withSize(8)
                altitudeVw.addSubview(lblDistanceFromCenter)
                altitudeVw.addSubview(lblTitle)
                anView.addSubview(altitudeVw)
                anView.tag = Int(cpa.index)!
                anView.canShowCallout = false
                
                if self.isDragPin == true {
                    anView.isEnabled = true
                    anView.isSelected = true
                    anView.isUserInteractionEnabled = true
                    anView.isDraggable = true
                }else{
                    anView.isDraggable = false
                    anView.isEnabled = false
                    anView.isUserInteractionEnabled = false
                }
                anView.rightCalloutAccessoryView = nil
                anView.frame = CGRect(x: 0, y: 0, width: 50, height: 70)
                anView.centerOffset = CGPoint(x: 0,y: -35)
            }else{
                
                let altitudeVw = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
                altitudeVw.backgroundColor = UIColor.clear
                altitudeVw.addSubview(imgView)
                let lblTitle = UILabel(frame: CGRect(x: 10, y: 2, width: 30, height: 30))
                lblTitle.font = lblTitle.font.withSize(15)
                lblTitle.text = cpa.index
                lblTitle.textAlignment = NSTextAlignment.center
                lblTitle.textColor = UIColor.white
                altitudeVw.addSubview(lblTitle)
                anView.addSubview(altitudeVw)
                anView.tag = Int(cpa.index)!
                anView.canShowCallout = false
                if self.isDragPin == true {
                    anView.isEnabled = true
                    anView.isSelected = true
                    anView.isUserInteractionEnabled = true
                    anView.isDraggable = true
                }else{
                    anView.isDraggable = false
                    anView.isEnabled = false
                    anView.isUserInteractionEnabled = false
                }
                anView.rightCalloutAccessoryView = nil
                anView.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
                anView.centerOffset = CGPoint(x: 0,y: -25)
                return anView
            }
            if annotation.isKind(of: LandingPointAnnotationModal.self) {
                let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "landingPoints")
                let annotationInfo = annotation as! LandingPointAnnotationModal
                imgView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
                imgView.image =  UIImage(named: "helipad")
                //            if self.isDragPin == true {
                //                anView.isEnabled = true
                //                anView.isSelected = true
                //                anView.isUserInteractionEnabled = true
                //                anView.isDraggable = true
                //            }else{
                anView.isDraggable = false
                anView.isEnabled = false
                anView.isUserInteractionEnabled = false
                anView.tag = Int(annotationInfo.index)!
                anView.addSubview(imgView)
                anView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
                anView.centerOffset = CGPoint(x: 0,y: -15)
                
            }
            
            return anView
        }
        if annotation.isKind(of: LandingPointAnnotationModal.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "landingPoints")
            let annotationInfo = annotation as! LandingPointAnnotationModal
            imgView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
            imgView.image =  UIImage(named: "helipad")
            //            if self.isDragPin == true {
            //                anView.isEnabled = true
            //                anView.isSelected = true
            //                anView.isUserInteractionEnabled = true
            //                anView.isDraggable = true
            //            }else{
            anView.isDraggable = false
            anView.isEnabled = false
            anView.isUserInteractionEnabled = false
            //  }
            anView.tag = Int(annotationInfo.index)!
            anView.addSubview(imgView)
            anView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
            anView.centerOffset = CGPoint(x: 0,y: -15)
            return anView
        }
        
        if annotation.isKind(of: ZoneNameAnnotationModal.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "zoneNameInMiddle")
            let ann = annotation as! ZoneNameAnnotationModal
            let lblTitle = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
            lblTitle.font = lblTitle.font.withSize(20)
            lblTitle.text = ann.title
            lblTitle.numberOfLines = 10
            lblTitle.textAlignment = NSTextAlignment.center
            lblTitle.textColor = UIColor(red: 64/255.0 ,green: 160/255.0, blue: 215/255.0,alpha: 1.0)
            anView.addSubview(lblTitle)
            return anView
        }
        
        if annotation.isKind(of: DroneAnnotation.self) {
            let  annoView = DJIAircraftAnnotationView.init(annotation: annotation, reuseIdentifier: "Aircraft_Annotation")
            (annotation as! DroneAnnotation).annotationView = annoView
            return annoView
        }
        
        return nil
    }
    
    func buttonAction(_ sender: UIButton!) {
        let btnsendtag: UIButton = sender
        print("index: \(btnsendtag.tag)")
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    //MARK: - MAPVIEW DELEGATE
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
        mapVw.deselectAnnotation(selectedAnnotationVw.annotation, animated: true)
        vwSeparateAltitude.isHidden = true
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        if let overlay = overlay as? MKCircle {
            let circleRenderer = MKCircleRenderer(circle: overlay)
            circleRenderer.strokeColor = UIColor.clear
            circleRenderer.fillColor = UIColor.clear
            circleRenderer.lineWidth = 0
            return circleRenderer
        }else{
            let polygonView = MKPolygonRenderer(overlay: overlay)
            polygonView.strokeColor = UIColor(red: 71.0/255, green: 194.0/255, blue: 19.0/255, alpha: 1)
            polygonView.lineWidth = 2
            polygonView.fillColor = UIColor(red: 211.0/255, green: 211.0/255, blue: 211.0/255, alpha: 0.50)
            
            if isOverLapped == true {
                polygonView.fillColor = UIColor(red: 206.0/255, green: 38.0/255, blue: 35.0/255, alpha: 0.50)
            }
            return polygonView
        }
    }
        

    
    
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView){
        selectedAnnotationVw = view
        
        //Handle separate action
        if !((view.annotation?.isKind(of: MKUserLocation.self))!) {
            
            view.isSelected = true
            if (isDragToPoint == false && isLandingPointsToBeDeleted == false && isPinPointsToBeDeleted == false){
                if isCompleted == true {
                    if view.annotation!.isKind(of: AnnotationModal.self) {
                        
                        let annotation = view.annotation as? AnnotationModal
                        let arrTempDrawPolygon = self.dictMainEventList.object(forKey: (annotation?.info)!) as! NSArray
                        vwChooseAltitude.isHidden = true
                        let dictShowAltitude = (arrTempDrawPolygon[view.tag-1] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                        txtFldSeperateMin.text = dictShowAltitude.value(forKey: "min_alt") as? String
                        txtFldSeperateMax.text = dictShowAltitude.value(forKey: "max_alt") as? String
                        vwSeparateAltitude.isHidden = false
                        let mainScreenWidth = UIScreen.main.bounds.size.width
                        let mainScreenHeight = UIScreen.main.bounds.size.height
                        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
                        if UIDevice.current.orientation.isLandscape {
                            //  Landscape
                            if view.frame.origin.x >= mainScreenWidth-250 {
                                cnstVwSeparateOriginX.constant = view.frame.origin.x - 600
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }else{
                                cnstVwSeparateOriginX.constant = view.frame.origin.x-350
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }
                        } else if UIDevice.current.orientation.isPortrait  {
                            //Portrait
                            if view.frame.origin.x >= mainScreenWidth-250 {
                                cnstVwSeparateOriginX.constant = view.frame.origin.x-500
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-520
                                }
                            }else{
                                cnstVwSeparateOriginX.constant = abs(view.frame.origin.x)-250
                                
                                if view.frame.origin.y >= mainScreenHeight-100 {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-520
                                }
                            }
                        }else{
                            //  Landscape
                            if view.frame.origin.x >= mainScreenWidth-250 {
                                cnstVwSeparateOriginX.constant = view.frame.origin.x - 600
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }else{
                                cnstVwSeparateOriginX.constant = view.frame.origin.x-350
                                if view.frame.origin.y >= mainScreenHeight {
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-420
                                }else{
                                    cnstVwSeparateOriginY.constant = view.frame.origin.y-320
                                }
                            }
                        }
                        lblSeparateAltitudes.text = " Separate Altitudes(\(view.tag))"
                    }
                }
            }
        }
    }
    
    //MARK: - AUTOROTATION METHOD
    
    override var shouldAutorotate: Bool{
        return false;
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return [UIInterfaceOrientationMask.landscape]
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView){
        if view.annotation!.isKind(of: AnnotationModal.self) {
            let annotation = view.annotation as? AnnotationModal
            mapView.deselectAnnotation(annotation, animated: true)
        }
        
        if view.annotation!.isKind(of: LandingPointAnnotationModal.self) {
            let annotation = view.annotation as? LandingPointAnnotationModal
            mapView.selectAnnotation(annotation!, animated: true)
        }
        
    }
    
    // MARK: - Navigation
    
    //    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    //        if segue.identifier == "droneControl" {
    //            let arrTemp = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as? NSArray
    //            if arrTemp?.count > 0 {
    //            let droneVC = segue.destination as! DroneControlVC
    //            droneVC.arrFlyzone  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
    //            droneVC.zoneModal = zoneCreateModal
    //            }else{
    //                proxy.sharedProxy().displayStatusCodeAlert("Please create zone to fly drone ")
    //            }
    //        }
    //    }
    
    
    //MARK: - INITIAL UI SETUP
    func setUpManager() {
        virtualStickLeft.isHidden = false
        virtualStickRight.isHidden = false
        vwDataFromDrone.isHidden = false
        btnZonesList.isHidden = true
        vwEventsLists.isHidden = true
        btnSettingsZone.isHidden = true
        cnstVwSettings.constant = 0
        vwChooseAltitude.isHidden = true
        vwCollectiveAltitudes.isHidden = true
        vwSeparateAltitude.isHidden = true
       self.registerApp(isReigster: willRegisterApp)
    }
    
    
    func updateVirtualStick() {
        var ctrlData = DJIVirtualStickFlightControlData()
        ctrlData.pitch = self.mYVelocity
        ctrlData.roll = self.mXVelocity
        ctrlData.yaw = self.mYaw
        ctrlData.verticalThrottle = self.mThrottle
        let fc = DroneUtility.fetchFlightController()
        if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
            fc?.send(ctrlData, withCompletion: { (error) in
                if error?.localizedDescription.characters.count > 0
                {
                    proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                }
                
            })
        }
    }
    
    
    func setXVelocity(_ x: Float, andYVelocity y: Float) {
        self.mXVelocity = x * DJIVirtualStickRollPitchControlMaxVelocity
        self.mYVelocity = y * DJIVirtualStickRollPitchControlMaxVelocity
        let velocity_y = ((self.mYVelocity/15) * Float(39))
        if self.mYVelocity > 0 {
            cnstYPositiveStickRight.constant = CGFloat(velocity_y)
            cnstYNegativeStickRight.constant = 0
        }else{
            cnstYNegativeStickRight.constant = abs(CGFloat(velocity_y))
            cnstYPositiveStickRight.constant = 0
        }
        let velocity_x = ((self.mXVelocity/15) * Float(39))
        if self.mXVelocity > 0 {
            cnstXPositiveStickRight.constant = CGFloat(velocity_x)
            cnstXNegativeStickRight.constant = 0
        }else{
            cnstXNegativeStickRight.constant = abs( CGFloat(velocity_x))
            cnstXPositiveStickRight.constant = 0
        }
        
        debugPrint("xVelocity : \(self.mXVelocity) mYVelocity: \(self.mYVelocity)")
        self.updateVirtualStick()
    }
    func setThrottle(_ y: Float, andYaw x: Float) {
        self.mThrottle = y * -2
        self.mYaw = x * 30
        
        let yaw = x * 100
        let throttle = y * -4
        let position_x = ((yaw/100) * Float(36.5))
        if yaw > 0 {
            cnstXPositiveStickLeft.constant = CGFloat(position_x)
            cnstXNegativeStickLeft.constant = 0
        }else{
            cnstXPositiveStickLeft.constant = 0
            cnstXNegativeStickLeft.constant = abs(CGFloat(position_x))
        }
        let position_y = ((throttle/4) * Float(39))
        if throttle > 0{
            cnstYPositiveStickLeft.constant = CGFloat(position_y)
            cnstYNegativeStickLeft.constant = 0
        }else{
            cnstYPositiveStickLeft.constant = 0
            cnstYNegativeStickLeft.constant = abs(CGFloat(position_y))
        }
        self.updateVirtualStick()
    }
    
    //MARK: - DJI SDK DELEGATE
    
    func sdkManagerDidRegisterAppWithError(_ error: Error?) {
        if error == nil {
            #if (arch(i386) || arch(x86_64)) && os(iOS)
                //simulator
                DJISDKManager.enterDebugMode(withDebugId: "192.168.10.185")
            #else
                //device
                DJISDKManager.startConnectionToProduct()
            #endif
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Registration Error:\(error?.localizedDescription)")
        }
    }
    
    func sdkManagerProductDidChange(from oldProduct: DJIBaseProduct?, to newProduct: DJIBaseProduct?) {
        if newProduct != nil{
            self.product = newProduct!
            proxy.sharedProxy().displayStatusCodeAlert("\(self.product.model!) connected")
            if let flightController = DroneUtility.fetchFlightController(){
                flightController.simulator?.delegate = self
                flightController.delegate = self
                self.btnIsEnteredLandingRegion.isHidden = false
                self.lblTransmissionTime.text = "I/O Time: 0.0 sec"
                self.lblTransmissionTime.isHidden = false
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
            }
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Connection lost.")
            self.btnIsEnteredLandingRegion.isHidden = true
            self.imgTagRight.image = UIImage(named:"tag_right")
            self.lblTransmissionTime.text = "I/O Time: 0.0 sec"
            self.lblTransmissionTime.isHidden = true
            let annotationsToRemove = self.mapVw.annotations.filter { $0 !== self.mapVw.userLocation }
            //Delete home coordinates
            for someAnnotation in annotationsToRemove {
                let strId = "\(zoneCreateModal.id)"
                if someAnnotation.isKind(of: LandingPointAnnotationModal.self) {
                    let annotaion = someAnnotation as! LandingPointAnnotationModal
                    if annotaion.info == strId {
                        self.mapVw.removeAnnotation(someAnnotation)
                    }
                }
            }
        }
    }
    
    
    func simulator(_ simulator: DJISimulator, update state: DJISimulatorState) {
        if CLLocationCoordinate2DIsValid(CLLocationCoordinate2DMake(state.latitude, state.longitude)) {
            self.droneLocationCoordinate = CLLocationCoordinate2DMake(state.latitude, state.longitude)
            lblAltitudeX.text =  String(format: "Altitude X: %0.2f m",state.positionX)
            lblAltitudeY.text = String(format: "Altitude Y: %0.2f m",state.positionY)
            lblAltitudeZ.text = String(format: "Altitude Z: %0.2f m",state.positionZ)
        }
    }
    
    
    func flightController(_ fc: DJIFlightController, didUpdateSystemState state: DJIFlightControllerCurrentState) {
        
        let methodStart = NSDate()
        let methodFinish = NSDate()
        let executionTime = methodFinish.timeIntervalSince(methodStart as Date)
        
        self.lblTransmissionTime.text = "I/O Time: \(Float(executionTime)) sec"
        
        // Set latency signal
        UIView.animate(withDuration: 2.5 , delay: 0.5, options: UIViewAnimationOptions.curveEaseOut, animations: {
            self.imgTagRight.image = UIImage(named:"tag_right")
        }, completion: { (true) in
            self.imgTagRight.image = UIImage(named:"tag_right_blue")
            UIView.animate(withDuration: 2.5 , delay: 0.5, options: UIViewAnimationOptions.curveEaseOut, animations: {
                self.imgTagRight.image = UIImage(named:"tag_right")
            }, completion: { (true) in
                self.imgTagRight.image = UIImage(named:"tag_right_blue")
            })
        })
        
        if CLLocationCoordinate2DIsValid(state.aircraftLocation) {
            self.droneLocationCoordinate = state.aircraftLocation
            var isDroneInsideTheZone = Bool()
            let droneLocationPoint =   self.mapVw.convert(state.aircraftLocation, toPointTo: self.mapVw)
            lblGPSData.text = "GPS: \(state.aircraftLocation.latitude), \(state.aircraftLocation.longitude)"
            lblDistanceAboveGround.text = "Altitude: \(state.altitude)"
            heightOfDrone = state.altitude
            lblVelocityXStatus.text = String(format: "Velocity X: %0.1f m/s",state.velocityX)
            let velocity_x = ((state.velocityX/15) * Float(38.5))
            if state.velocityX > 0 {
                cnstXPositiveVelocity.constant = CGFloat(velocity_x)
                cnstXNegativeVelocity.constant = 0
            }else{
                cnstXPositiveVelocity.constant = 0
                cnstXNegativeVelocity.constant = abs(CGFloat(velocity_x))
            }
            lblVelocityYStatus.text = String(format: "Velocity Y: %0.1f m/s",state.velocityY)
            let velocity_y = ((state.velocityY/15) * Float(39))
            if state.velocityY > 0 {
                cnstYNegativeVelocity.constant = 0
                cnstYPositiveVelocity.constant = CGFloat(velocity_y)
            }else{
                cnstYNegativeVelocity.constant = abs(CGFloat(velocity_y))
                cnstYPositiveVelocity.constant = 0
                
            }
            
            lblVelocityZStatus.text = String(format: "Velocity Z: %0.1f m/s",state.velocityZ)
            let velocity_z = ((state.velocityZ/4) * Float(39))
            if state.velocityZ > 0 {
                cnstZPositive.constant = CGFloat(velocity_z)
                cnstZNegative.constant = 0
            }else{
                cnstZPositive.constant = 0
                cnstZNegative.constant =  abs(CGFloat(velocity_z))
                
            }
            
            let radianYaw: Double = Double(state.attitude.yaw).degreesToRadians
            if aircraftAnnotation != nil {
                UIView.animate(withDuration: 0.2, delay: 0.1, options: UIViewAnimationOptions.curveEaseOut, animations: {
                    self.aircraftAnnotation.setNewCoordinate(state.aircraftLocation)
                }, completion: { (true) in
                    self.aircraftAnnotation.updateHeading(Float(radianYaw))
                })
            }else{
                aircraftAnnotation = DroneAnnotation.init(coordiante: state.aircraftLocation,title: "drone_id_\(self.zoneCreateModal.id)" as NSString)
                self.mapVw.addAnnotation(aircraftAnnotation!)
                aircraftAnnotation.setNewCoordinate(state.aircraftLocation)
            }
            
            if let polygon = self.dictPolygon.object(forKey: "\(zoneCreateModal.id)") as? MKPolygon{
                if isInsideThePolygon(polygon,sampleLocation: CLLocationCoordinate2D(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)) == true{
                    lblStatusDroneIsInZone.text = "Drone in zone: YES"
                    isDroneInsideTheZone = true
                }else{
                    isDroneInsideTheZone = false
                    lblStatusDroneIsInZone.text = "Drone in zone: NO"
                }
                
                if CLLocationCoordinate2DIsValid(self.takeOffCoordinates) {
                    let coordinate₀ = CLLocation(latitude: self.droneLocationCoordinate
                        .latitude, longitude: self.droneLocationCoordinate.longitude)
                    let coordinate₁ = CLLocation(latitude: self.takeOffCoordinates.latitude, longitude: self.takeOffCoordinates.longitude)
                    let droneDistanceFromCenterOfDrone = coordinate₀.distance(from: coordinate₁)
                    if droneDistanceFromCenterOfDrone < 4 {
                        self.btnIsEnteredLandingRegion.setImage(UIImage(named:"ic_helipad_over_red"), for: .normal)
                    }else{
                        self.btnIsEnteredLandingRegion.setImage(UIImage(named:"ic_helipad_over"), for: .normal)
                    }
                }
                
                //IMPLEMENTING DISTANCE FROM EDGES
                //1.Draw lines and convert location to x-y coordinates
                let  arrTemp  = self.dictMainEventList.object(forKey: "\(zoneCreateModal.id)") as! NSArray
                let arrDroneLivePositionNearestEdges = NSMutableArray()
                if arrTemp.count > 0{
                    for i in 0..<arrTemp.count {
                        //GET LOCATION COORDINATES
                        if i < arrTemp.count-1 {
                            let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i] as! NSMutableDictionary)
                            let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[i+1] as! NSMutableDictionary)
                            let droneNearestEdgePoint = proxy.sharedProxy().distanceFromPoint(p: droneLocationPoint, toLineSegment: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosA, mapView: self.mapVw), and: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosB, mapView: self.mapVw))
                            arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                        }else{
                            let dronePosA = proxy.sharedProxy().getLocationFromDictionary(arrTemp[0] as! NSMutableDictionary)
                            let dronePosB = proxy.sharedProxy().getLocationFromDictionary(arrTemp[arrTemp.count - 1] as! NSMutableDictionary)
                            let droneNearestEdgePoint = proxy.sharedProxy().distanceFromPoint(p: droneLocationPoint, toLineSegment: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosA, mapView: self.mapVw), and: proxy.sharedProxy().convertLocationCoordinatesToXYPosition(dronePosB, mapView: self.mapVw))
                            arrDroneLivePositionNearestEdges.add(droneNearestEdgePoint)
                        }
                    }
                    
                    var minimum_edge_distance = (arrDroneLivePositionNearestEdges[0] as! NSDictionary).object(forKey: "minimum_distance") as! CGFloat
                    var indexPosition = 0
                    
                    //2.FIND MINIMUM COORDINATES DISTANCE EDGE
                    for i in 0..<arrDroneLivePositionNearestEdges.count{
                        let dictEdgeInfo = arrDroneLivePositionNearestEdges[i] as! NSDictionary
                        let edge_distance = dictEdgeInfo.object(forKey: "minimum_distance") as! CGFloat
                        if edge_distance <= minimum_edge_distance {
                            minimum_edge_distance = edge_distance
                            indexPosition = i
                        }
                    }
                    
                    //3.GET DISTANCE BETWEEN TWO LATITUDE AND LONGITUDE
                    let xPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "xPos") as! CGFloat
                    let yPosition =  (arrDroneLivePositionNearestEdges[indexPosition] as! NSDictionary).object(forKey: "yPos") as! CGFloat
                    let droneNearestPointInCoordinateSytem = CGPoint(x: xPosition, y: yPosition)
                    let locationCoordinate = mapVw.convert(droneNearestPointInCoordinateSytem,toCoordinateFrom: mapVw)
                    let coordinate₀ = CLLocation(latitude: self.droneLocationCoordinate.latitude, longitude: self.droneLocationCoordinate.longitude)
                    let coordinate₁ = CLLocation(latitude: locationCoordinate.latitude, longitude: locationCoordinate.longitude)
                    let distanceInMeters = Float(proxy.sharedProxy().getDistanceInm(coordinate₀, from: coordinate₁))
                    if isDroneInsideTheZone == false {
                        self.lblDistanceToNearestBoundary.text = String(format: "Distance to nearest boundary: %0.2f m",-distanceInMeters)
                    }else{
                        self.lblDistanceToNearestBoundary.text = String(format: "Distance to nearest boundary: %0.2f m",distanceInMeters)
                    }
                    
                    let locationHome = CLLocation(latitude: self.takeOffCoordinates.latitude, longitude: self.takeOffCoordinates.longitude)
                    var flightRadius = Float(proxy.sharedProxy().getDistanceInm(locationHome, from: coordinate₁))
                    if CLLocationCoordinate2DIsValid(locationCoordinate) {
                        if let flightController = DroneUtility.fetchFlightController(){
                            if isDroneInsideTheZone == false{
                                flightRadius = flightRadius - abs(distanceInMeters) - 4
                                fc.flightLimitation?.setMaxFlightRadius(Float((flightRadius)), withCompletion: { (error) in
                                    if error?.localizedDescription.characters.count > 0
                                    {
                                    }
                                })
                                var ctrlData = DJIVirtualStickFlightControlData()
                                ctrlData.pitch = 0.50
                                ctrlData.roll = 0.50
                                ctrlData.yaw = 0.50
                                let fc = DroneUtility.fetchFlightController()
                                if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                                    fc?.send(ctrlData, withCompletion: { (error) in
                                        if error?.localizedDescription.characters.count > 0
                                        {
                                            proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                        }
                                    })
                                }
                            }else{
                                if distanceInMeters < 25 {
                                    fc.flightLimitation?.setMaxFlightRadius(Float((flightRadius)), withCompletion: { (error) in
                                        if error?.localizedDescription.characters.count > 0
                                        {
                                        }
                                    })
                                    var ctrlData = DJIVirtualStickFlightControlData()
                                    ctrlData.pitch = 0.50
                                    ctrlData.roll = 0.50
                                    ctrlData.yaw = 0.50
                                    let fc = DroneUtility.fetchFlightController()
                                    if (fc != nil) && fc!.isVirtualStickControlModeAvailable() {
                                        fc?.send(ctrlData, withCompletion: { (error) in
                                            if error?.localizedDescription.characters.count > 0
                                            {
                                                proxy.sharedProxy().displayStatusCodeAlert("Error: \(error!.localizedDescription)")
                                            }
                                        })
                                    }
                                }else{
                                    let delay = 0.5 * Double(NSEC_PER_SEC)
                                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                                        self.setMaximumRadius(flightRadius: 500.0)
                                    }
                                }
                            }
                        }else{
                            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
                        }
                    }
                }
            }
        }
    }
    
    
    func setMaximumRadius(flightRadius:Float)  {
        if let flightController = DroneUtility.fetchFlightController(){
            flightController.flightLimitation?.setMaxFlightRadius(Float((flightRadius)), withCompletion: { (error) in
                if error?.localizedDescription.characters.count > 0{
                }
            })
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("Please connect drone")
        }
    }
    
    func remoteController(_ rc: DJIRemoteController, didUpdate gpsData: DJIRCGPSData) {
        
    }
    
}
    


