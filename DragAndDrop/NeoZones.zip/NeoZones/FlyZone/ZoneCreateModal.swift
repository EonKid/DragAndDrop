//
//  ZoneCreateModal.swift
//  FlyZone
//
//  Created by Dhruv Singh on 25/08/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Foundation

class ZoneCreateModal: NSObject {
    var id = Int32()
    var name = String()
    var zones = NSArray()
    var create_user_id = Int32()
    var create_user_name = String()
    override init() {
        super.init()
    }
}
