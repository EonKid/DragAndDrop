//
//  AppDelegate.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 27/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import Alamofire
import PKHUD
import Kingfisher
import IQKeyboardManagerSwift
import Fabric
import Crashlytics
import UserNotifications
import AVFoundation

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate , UITableViewDataSource, UITableViewDelegate{
   
    //MARK:- VARAIABLE
    var window: UIWindow?
    let splashView = UIImageView()
    var TransprntImg = UIImageView()
    var DrawerTable = UITableView()
    var tableView = UIView()
    var SideImageView = UIImageView()
    var sideView = UIView()
    var headerView = UIView()
    let drawerView = UIView()
    var sideViewBackView = UIView()
    var arrSideMenu=[String]()
    var imageIcon=[String]()
    var Draweropen:Bool = false
    var visibleNavController = UINavigationController()
    let locationManager = locationManagerClass.sharedLocationManager()
    var imgVwProfile = UIImageView()
    var lblName = UILabel()
    var btnProfile = UIButton()
    var lblLine = UILabel()
    var jID = String()
    var paymentRecieved = Bool()
    var  alertSound = AVAudioPlayer()
    
    // MARK: - CONTROLLER NAVIGATIONS
    var MainMenuNavController:UINavigationController = UINavigationController()
    var loginNavController:UINavigationController = UINavigationController()
    var SettingsNavController:UINavigationController = UINavigationController()
    var AboutNavController:UINavigationController = UINavigationController()
    var MyAccountNavController:UINavigationController = UINavigationController()
    var myGroupsNavigationController = UINavigationController()
    var aboutAppNavigationController = UINavigationController()
    let lblNotification = UILabel()
    let viewNotification = UIView()
    var viewIsAnimating = Bool()
    var notificationCheck = Bool()
    var navMain = UINavigationController()
    
    
    
    func StoryBoard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
    //MARK: - ALERT AND INDICATOR
    
    func displayDateCheckAlert()
    {
        let alert: UIAlertView = UIAlertView(title: "Demo Expired", message: "Please contact the team", delegate: nil, cancelButtonTitle: "OK")
        alert.show()
        
    }
    
    func showActivityIndicator()
    {
        DispatchQueue.main.async
        {
            HUD.show(.labeledProgress(title: nil, subtitle: "Please Wait.."))
        }
    }
    
    func hideActivityIndicator()
    {
        DispatchQueue.main.async {
            HUD.hide()
        }
    }
    
    func handleTap(_ sender: UITapGestureRecognizer) {
        openDrawerAction()
    }
    
    //MARK:- Open Drawer
    
    func openDrawerAction()	{
        
        if sideView.frame == CGRect(x: -(window?.bounds.width)!,y: 64,width: (window?.bounds.width)!,height: UIScreen.main.bounds.size.height)
        {
            DrawerTable.removeFromSuperview()
            headerView.removeFromSuperview()
            
            self.window!.addSubview(self.sideView)
          //  TransprntImg = UIImageView(frame: CGRect(x: 0, y: 0,width: self.window!.frame.size.width,height: self.window!.frame.size.height))
            
            TransprntImg.backgroundColor = UIColor(red: 10.0/255.0, green: 10.0/255.0, blue: 10.0/255.0, alpha: 0.57)
            TransprntImg = UIImageView(frame: CGRect(x: 250,y: 0,width: self.window!.frame.size.width,height: self.window!.frame.size.height))
            self.window?.addSubview(TransprntImg)
            let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:#selector(AppDelegate.handleTap(_:)))
            TransprntImg.isUserInteractionEnabled = true
            TransprntImg.addGestureRecognizer(tapGestureRecognizer)
            sideView.layer.borderColor = UIColor.gray.cgColor
            sideView.layer.borderWidth = 0
            
            //sideView.addSubview(drawerView)
            
            tableView.frame = CGRect(x: 0, y: 0, width: 250, height: UIScreen.main.bounds.size.height)
            DrawerTable = UITableView(frame: CGRect(x: 0, y: 0, width: 250, height: 1024), style: .plain)
            DrawerTable.backgroundColor = UIColor(red: 5.0/255.0, green: 5.0/255.0, blue: 5.0/255.0, alpha: 0.85)
            DrawerTable.isScrollEnabled = true
            
            //Add menu name
            arrSideMenu.removeAll()
            arrSideMenu.append("Main Menu")
            arrSideMenu.append("Settings")
            arrSideMenu.append("My Groups")
            arrSideMenu.append("My Account")
            arrSideMenu.append("About App")
            arrSideMenu.append("Logout")
            
            //Add image to name
            imageIcon.removeAll()
            imageIcon.append("drawerMain")
            imageIcon.append("drawerSettings")
            imageIcon.append("my_groups_draweer")
            imageIcon.append("drawerprofile")
            imageIcon.append("drawerAbout")
            imageIcon.append("ic_logout_draweer")
            
            DrawerTable.dataSource = self
            DrawerTable.delegate = self
            //tableView.addSubview(TransprntImg)
            tableView.addSubview(headerView)
            tableView.addSubview(DrawerTable)
            sideView.addSubview(tableView)
            DrawerTable.bounces = true
            Draweropen=true
            UIView.animate(withDuration: 0.30, animations:{self.sideView.frame = CGRect(x: 0,y: 64,width: (self.window?.bounds.width)!, height: UIScreen.main.bounds.size.height)})
        }
        else{
            TransprntImg.removeFromSuperview()
            UIView.animate(withDuration: 0.50, animations:{self.sideView.frame = CGRect(x: -(self.window?.bounds.width)!,y: 64,width: (self.window?.bounds.width)!,height: UIScreen.main.bounds.size.height)
            })
            Draweropen = false
        }
    }
    
    
    
    //MARK:- TableView Methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSideMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.value1, reuseIdentifier: "Cell")
        cell.backgroundColor = UIColor.clear
        let titleLabel: UILabel = UILabel()
        titleLabel.frame = CGRect(x: 45,y: 18, width: 160, height: 19)
        titleLabel.textColor = UIColor.white
        titleLabel.font = titleLabel.font.withSize(17)
        if (indexPath as NSIndexPath).row == 5 {
                if (UserDefaults.standard.object(forKey: "auth_code")) != nil{
                    titleLabel.text = arrSideMenu[(indexPath as NSIndexPath).row]
                }else{
                    titleLabel.text = "Login"
                }
            }else{
                titleLabel.text = arrSideMenu[(indexPath as NSIndexPath).row]
            }
            self.DrawerTable.separatorColor = UIColor.clear
            let lblLine: UILabel = UILabel()
       
        lblLine.frame = CGRect(x: 0,y: 57, width: 250, height: 1)
        lblLine.backgroundColor = UIColor.darkGray
        cell.contentView.addSubview(lblLine)
        cell.contentView.addSubview(titleLabel)
        DrawerTable.tableFooterView = UIView(frame: CGRect.zero)
        let imgTitle: UIImageView = UIImageView()
        imgTitle.frame = CGRect(x: 10, y: 18, width: 20, height: 20)
        imgTitle.image =  UIImage(named: imageIcon[(indexPath as NSIndexPath).row] )
        cell.contentView.addSubview(imgTitle)
        cell.selectionStyle = .none
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           return 58
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch (indexPath as NSIndexPath).row {
        case 0:
            openDrawerAction()
            gotoMainMenu()
            break
        case 1:
            openDrawerAction()
            gotoSettings()
            break
        case 2:
            openDrawerAction()
           gotoMyGroups()
            break
        case 3:
            openDrawerAction()
             gotoMyAccount()
            
            break
        case 4:
             openDrawerAction()
             gotoAbout()
            break
        case 5:
            if (UserDefaults.standard.object(forKey: "auth_code")) != nil{
                openDrawerAction()
                logOut()
            }else{
                 openDrawerAction()
                 goToLogin()
            }
            break
        default:
            break
        }
    }
    
    
    
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        let vc = self.window?.currentViewController()
        if vc?.isKind(of: CreateZoneOnlineVC.self) == true {
            return UIInterfaceOrientationMask.landscape;
        } else {
            return UIInterfaceOrientationMask.all ;
        }
    }
    
    //MARK:- Navigation
    func goToLogin(){
        let loginVc = StoryBoard().instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        loginNavController = UINavigationController.init(rootViewController: loginVc)
        self.window!.rootViewController = loginNavController
        visibleNavController = loginNavController
        self.window?.makeKeyAndVisible()
    }
    
    func gotoMainMenu() {
        let mainMenuVc = StoryBoard().instantiateViewController(withIdentifier: "FlightZonePlannerVC") as! FlightZonePlannerVC
        MainMenuNavController = UINavigationController.init(rootViewController: mainMenuVc)
        self.window!.rootViewController = MainMenuNavController
        visibleNavController = MainMenuNavController
        self.window?.makeKeyAndVisible()

    }
    
    func gotoSettings() {
        let settingVc = StoryBoard().instantiateViewController(withIdentifier: "SettingsVC") as! SettingsVC
        SettingsNavController = UINavigationController.init(rootViewController: settingVc)
        self.window!.rootViewController = SettingsNavController
        visibleNavController = SettingsNavController
        self.window?.makeKeyAndVisible()
        
    }
    func gotoMyAccount() {
        let myAccountVc = StoryBoard().instantiateViewController(withIdentifier: "MyAccountVC") as! MyAccountVC
        MyAccountNavController = UINavigationController.init(rootViewController: myAccountVc)
        self.window!.rootViewController = MyAccountNavController
        visibleNavController = MyAccountNavController
        self.window?.makeKeyAndVisible()
        
    }
    func gotoAbout() {
        let aboutVc = StoryBoard().instantiateViewController(withIdentifier: "AboutVC") as! AboutVC
        aboutAppNavigationController = UINavigationController.init(rootViewController: aboutVc)
        self.window!.rootViewController = aboutAppNavigationController
        visibleNavController = aboutAppNavigationController
        self.window?.makeKeyAndVisible()
        
    }
    func gotoMyGroups() {
        
        let mygroupVc = StoryBoard().instantiateViewController(withIdentifier: "MyGroupVC") as! MyGroupVC
        myGroupsNavigationController = UINavigationController.init(rootViewController: mygroupVc)
        self.window!.rootViewController = myGroupsNavigationController
        visibleNavController = myGroupsNavigationController
        self.window?.makeKeyAndVisible()
    }
    
    func logOut(){
        let logoutURL = "\(KServerUrl)"+"\(Klogout)?uid=\(UIDevice.current.identifierForVendor!.uuidString)"
        let reachability = Reachability()
        if  reachability?.isReachable  == true
        {
            showActivityIndicator()
            request(logoutURL, method: .post, parameters: nil, encoding: URLEncoding.httpBody,headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do  {
                        self.hideActivityIndicator()
                        if let JSON = response.result.value as? NSDictionary
                        {
                            if (JSON["status"]! as AnyObject).isEqual("OK")
                            {
                                UserDefaults.standard.removeObject(forKey: "auth_code")
                                UserDefaults.standard.removeObject(forKey: "full_name")
                                UserDefaults.standard.removeObject(forKey: "email")
                                UserDefaults.standard.removeObject(forKey: "id")
                                UserDefaults.standard.synchronize()
                                self.locationManager.stopStandardUpdate()
                                self.goToLogin()
                            }
                            else if (JSON["status"]! as AnyObject).isEqual("NOK")
                            {
                                proxy.sharedProxy().showAlert("Error!",message: "Logout Failed",buttonAction: "OK")
                                
                            }
                        }
                    }
            }
        }
        else {
            hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }

    
    //MARK: - iOS 10 NOTIFICATION METHODS
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (_ options: UNNotificationPresentationOptions) -> Void) {
        var userInfo = NSDictionary()
        userInfo = notification.request.content.userInfo as NSDictionary
        WebServiceRequest.printResponse(responseDictionary: userInfo)
        do {
            try alertSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: Bundle.main.path(forResource: "notification", ofType: "mp3")!) as URL, fileTypeHint:nil)
        } catch {
            //Handle the error
        }
        alertSound.play()
        WebServiceRequest.printResponse(responseDictionary: userInfo)
        
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        var userInfo = NSDictionary()
        userInfo = response.notification.request.content.userInfo as NSDictionary
        WebServiceRequest.printResponse(responseDictionary: userInfo)
        do {
            try alertSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: Bundle.main.path(forResource: "notification", ofType: "mp3")!) as URL, fileTypeHint:nil)
        } catch {
            //Handle the error
        }
        alertSound.play()
        WebServiceRequest.printResponse(responseDictionary: userInfo)
    }
    
    

    //MARK: - NOTIFICATION METHODS
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        UIApplication.shared.registerForRemoteNotifications()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let tokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        print("Got token data! \(tokenString)")
        UserDefaults.standard.set(tokenString, forKey: "device_token")
        UserDefaults.standard.synchronize()
       
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
      //  print("Couldn't register: \(error)")
        UserDefaults.standard.set("000000000000000000000000000000000000000000000000000000000000055", forKey: "device_token")
        UserDefaults.standard.synchronize()
    }
    
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
       
        do {
            try alertSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: Bundle.main.path(forResource: "notification", ofType: "mp3")!) as URL, fileTypeHint:nil)
        } catch {
            //Handle the error
        }
        alertSound.play()
        let userINFO = userInfo as NSDictionary
        WebServiceRequest.printResponse(responseDictionary: userINFO)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "userFound"), object: userINFO)
    }
    
    //MARK:- APPLICATION LIFECYCLE
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
       
        
        //Fabric configuration
        Fabric.with([Crashlytics.self])
        self.logUser()
        //Set IQKeyBoard
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().shouldResignOnTouchOutside = true
        self.window = UIWindow(frame: UIScreen.main.bounds)
        
        //Setup DataBase
        DBManager.createEditableCopyOfDatabaseIfNeeded()
        DBManager.sharedDatabase().openDatabaseConnection()
        
        //Dummy controller
        let dummyController:UIViewController = UIViewController()
        self.window!.rootViewController = dummyController
        self.window!.makeKeyAndVisible()
        splashView.frame = CGRect(x: 0, y: 0, width: (self.window?.frame.width)!, height: (self.window?.frame.height)!)
        
        if UIScreen.main.bounds.height > UIScreen.main.bounds.width {
            // do your portrait stuff
            splashView.image = UIImage(named: "splashPortrait")
            
        } else {    // in landscape
            splashView.image = UIImage(named: "splash")
        }
        
        dummyController.view.addSubview(splashView)
        self.window?.addSubview(splashView)
        sideView.frame = CGRect(x: -(window?.bounds.width)!,y: 64,width: (window?.bounds.width)!,height: UIScreen.main.bounds.size.height)
        UIApplication.shared.applicationIconBadgeNumber = 0
       // if proxy.sharedProxy().expiryDateCheckMethod("2016-12-30 23:59:59") == true
     //   {
            let locationManager = locationManagerClass.sharedLocationManager()
            locationManager.startStandardUpdates()
            let types:UIUserNotificationType = ([.alert, .sound, .badge])
            let settings:UIUserNotificationSettings = UIUserNotificationSettings(types: types, categories: nil)
            application.registerUserNotificationSettings(settings)
            if (UserDefaults.standard.object(forKey: "auth_code")) != nil
            {
                let authCode: String = proxy.sharedProxy().authNil()
                if((authCode == "" ))
                {
                    self.gotoMainMenu()
                }else{
                    let reachability = Reachability()
                    if  reachability?.isReachable  == true {
                        //   showActivityIndicator()
                        let apiURL = "\(KCheckUser)"+"\(authCode)"
                         request(apiURL, method: .get, parameters: nil, encoding: JSONEncoding.default,headers:nil)
                            .responseJSON { response in
                                if let JSON = response.result.value as? NSDictionary {
                                    if response.result.value != nil{
                                    WebServiceRequest.printResponse(responseDictionary: JSON)
                                    }
                                    if(response.response?.statusCode == 200)
                                    {
                                        if (JSON["status"]! as AnyObject).isEqual("OK") {
                                            self.gotoMainMenu()
                                        }else if (JSON["status"]! as AnyObject).isEqual("NOK") {
                                            self.goToLogin()
                                        }
                                    }
                                    else  {
                                        proxy.sharedProxy().stautsHandler(apiURL, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                                    }
                                }
                        }
                    } else {
                        proxy.sharedProxy().openSettingApp()
                    }
                }
            }else
            {
                (UserDefaults.standard.set("Yes", forKey:"First"))
                UserDefaults.standard.synchronize()
                self.gotoMainMenu()
            }
       // }
       // else
      //  {
       //     displayDateCheckAlert()
      //  }
        return true
    }
    
    //MARK: - Faric crashlogs
    func logUser() {
      
        if (UserDefaults.standard.object(forKey: "full_name")) != nil
        {
            let user_name = UserDefaults.standard.object(forKey: "full_name") as? String
            Crashlytics.sharedInstance().setUserName(user_name!)
        }else{
             Crashlytics.sharedInstance().setUserName("Offline User")
        }
        
        if (UserDefaults.standard.object(forKey: "email")) != nil
        {
            let email = UserDefaults.standard.object(forKey: "email") as? String
             Crashlytics.sharedInstance().setUserEmail(email!)
        }else{
             Crashlytics.sharedInstance().setUserEmail("dhruv.singh@toxsltech.com")
        }
        if (UserDefaults.standard.object(forKey: "id")) != nil{
            let userId  = UserDefaults.standard.object(forKey: "id") as! Int
            Crashlytics.sharedInstance().setUserIdentifier("\(userId)")
        }else{
            Crashlytics.sharedInstance().setUserIdentifier("\(0)")
        }
        
        
    }

    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        notificationCheck = true
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        application.applicationIconBadgeNumber = 0
        application.cancelAllLocalNotifications()
        let locationManager = locationManagerClass.sharedLocationManager()
        locationManager.startStandardUpdates()
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }
    
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
    
}

