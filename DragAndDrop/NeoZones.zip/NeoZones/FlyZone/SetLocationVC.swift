//
//  SetLocationVC.swift
//  FlyZone
//
//  Created by Ankit Chhabra on 28/07/16.
//  Copyright © 2016 toxsl. All rights reserved.
//

import UIKit
import MapKit
protocol setLocationDelegate {
    func setLocationOfEvent(_ dictEvent: NSDictionary)
}
var protocolObject: setLocationDelegate?
class SetLocationVC: UIViewController,UITextFieldDelegate,setChooseLocationPointDelegate {
    
    //MARK:- VARIABLE
    var isGroupSecret  = String()
    var datePicker1 = UIDatePicker()
    var datePicker2 = UIDatePicker()
    var dictLocationInfo = NSMutableDictionary()
    
    
    //MARK:- IBOUTLET
    
    @IBOutlet weak var txtFieldNameOfEvent: UITextField!
    
    @IBOutlet weak var txtFieldGroup: UITextField!
    
    @IBOutlet weak var txtStartDateOfEvent: UITextField!
    
    @IBOutlet weak var txtFieldEndDateOfEvent: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    
    @IBOutlet weak var txtFieldConfirnPwd: UITextField!
    
    @IBOutlet weak var btnIsGroupSecret: UIButton!
    
    @IBOutlet weak var lblEventLocation: UILabel!
    
    //MARK: - VIEWCONTROLLER LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.txtStartDateOfEvent.inputView = datePicker1
        self.txtFieldEndDateOfEvent.inputView = datePicker2
        datePicker1.minimumDate = datePicker1.date
        datePicker2.minimumDate = datePicker1.date
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"//this your string date format
        txtStartDateOfEvent.text = dateFormatter.string(from: datePicker1.date)
        datePicker1.minimumDate = datePicker1.date
        txtFieldEndDateOfEvent.text = dateFormatter.string(from: datePicker2.date)
        
        datePicker1.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged1(_:)), for: UIControlEvents.valueChanged)
        datePicker2.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged2(_:)), for: UIControlEvents.valueChanged)
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        isGroupSecret = "0"
    }
    
    //MARK: - ACTION
    
    
    @IBAction func btnPrssSetLocation(_ sender: AnyObject) {
        self.view.endEditing(true)
        if txtFieldGroup.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Group name")
        }else if txtFieldNameOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Event name")
        }else if txtStartDateOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter start date of event")
        }else if lblEventLocation.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter event location")
        }
        else if txtStartDateOfEvent.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter end date of event")
        }else if txtFldPassword.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter password")
        }else if txtFldPassword.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 0
        {
            if txtFldPassword.text == txtFieldConfirnPwd.text {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter correct password")
            }else{
                proxy.sharedProxy().displayStatusCodeAlert("Please enter confirm password")
                
            }
            
        }else{
            
            let createZoneUrl = "\(KServerUrl)"+"\(kCreateGroup)"
            let  strLat = dictLocationInfo["lat"] as! String
            let strLong = dictLocationInfo["longt"] as! String
            let lat  = strLat.trimmingCharacters(in: CharacterSet.whitespaces)
            let long  = strLong.trimmingCharacters(in: CharacterSet.whitespaces)
            
            let param = [
                "Group[name]" : "\(txtFieldGroup.text!)",
                "Event[password]" : "\(txtFldPassword.text!)",
                "Event[confirm_password]" : "\(txtFieldConfirnPwd.text!)",
                "Group[type_id]" : isGroupSecret,
                " Event[name]" : "\(txtFieldNameOfEvent.text!)",
                "Event[from_date]" : "\(txtStartDateOfEvent.text!)",
                "Event[to_date]" : "\(txtFieldEndDateOfEvent.text!)",
                "Event[lat]" :lat,
                "Event[longt]" : long,
                "Event[location]" : dictLocationInfo["location_name"] as! String
            ]
            
            createGroup(createZoneUrl, parameters: param as Dictionary<String, AnyObject>)
        }
        
        
    }
    
    
    @IBAction func btnPrssAddLocation(_ sender: AnyObject) {
        
        let chooseLacationVC = storyboard?.instantiateViewController(withIdentifier: "ChooseLocationVC") as! ChooseLocationVC
        protocolChooseLocation = self
        chooseLacationVC.modalTransitionStyle = .crossDissolve
        chooseLacationVC.modalPresentationStyle = .overCurrentContext
        self.providesPresentationContextTransitionStyle = true
        self.present(chooseLacationVC, animated: true, completion: nil)
        
    }
    
    
    func createGroup(_ url: String,parameters: Dictionary<String, AnyObject>) {
        WebServiceRequest.postNormalData(parameters, url: url, success: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual("OK"){
                let dictEvent = responseDict["detail"] as! NSDictionary
                proxy.sharedProxy().displayStatusCodeAlert("Group created successfully.")
                self.dismiss(animated: true, completion: {
                    protocolObject!.setLocationOfEvent(dictEvent)
                })
            }else{
                proxy.sharedProxy().displayStatusCodeAlert(String(describing: responseDict["error"]!))
            }
            
            }, failure: { (error) in
                KAppDelegate.hideActivityIndicator()
                if error.localizedDescription.characters.count > 0{
                    let errorMessage = "\(error.localizedDescription)"
                    let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
                    let retryAction = UIAlertAction(title: "Retry", style: .default, handler: {
                        action in
                        self.createGroup(url, parameters: parameters)
                    }
                    )
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: {
                        action in
                    }
                    )
                    alertController.addAction(retryAction)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            })
        
    }
    
    @IBAction func btnPrssIsGroupIsSecret(_ sender: AnyObject) {
        
        if btnIsGroupSecret.isSelected == true {
            btnIsGroupSecret.isSelected = false
            isGroupSecret = "0"
        }else{
            
            btnIsGroupSecret.isSelected = true
            isGroupSecret = "1"
        }
    }
    
    @IBAction func btnCancel(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:- UITEXTFIELD DELEGATE
    func textFieldDidBeginEditing(_ textField: UITextField){
        if txtStartDateOfEvent == textField {
            datePicker1.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged1(_:)), for: UIControlEvents.valueChanged)
        }
        if txtFieldEndDateOfEvent == textField {
            datePicker2.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged2(_:)), for: UIControlEvents.valueChanged)
        }
        
    }
    
    func datePickerValueChanged1(_ sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"//this your string date format
        txtStartDateOfEvent.text = dateFormatter.string(from: sender.date)
        datePicker2.minimumDate = sender.date
        txtFieldEndDateOfEvent.text = dateFormatter.string(from: sender.date)
        
        
    }
    func datePickerValueChanged2(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"//this your string date format
        txtFieldEndDateOfEvent.text = dateFormatter.string(from: sender.date)
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        if txtStartDateOfEvent == textField {
            datePicker1.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged1(_:)), for: UIControlEvents.valueChanged)
        }
        if txtFieldEndDateOfEvent == textField {
            datePicker2.addTarget(self, action: #selector(SetLocationVC.datePickerValueChanged2(_:)), for: UIControlEvents.valueChanged)
        }
        
        
    }
    
    //MARK:- DELEGATE CHOOSE LOCATION
    func getLocationFromMap(_ dictLocation:NSMutableDictionary)
    {
               if dictLocation["location_name"] as! String != "" {
            lblEventLocation.textColor = UIColor.black
            lblEventLocation.text = dictLocation["location_name"] as? String

        }
       // let txtHeight = lblEventLocation.text!.heightWithConstrainedWidth(lblEventLocation.frame.width, font: UIFont.systemFontOfSize(17))
       // lblEventLocation.frame.size.height = txtHeight
        dictLocationInfo = dictLocation
    }
    
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
